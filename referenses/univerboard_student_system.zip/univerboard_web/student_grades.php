<?php
/**
 * صفحة الدرجات للطالب في نظام UniverBoard
 * تعرض درجات الطالب في المقررات المختلفة والتقدير العام
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول الطالب
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات الطالب
$student_id = $_SESSION['user_id'];
$db = get_db_connection();
$student = get_student_info($db, $student_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// الحصول على درجات الطالب في الفصل الحالي
$current_semester_grades = get_student_current_semester_grades($db, $student_id);

// الحصول على درجات الطالب في جميع الفصول
$all_semesters_grades = get_student_all_semesters_grades($db, $student_id);

// الحصول على المعدل التراكمي للطالب
$gpa = get_student_gpa($db, $student_id);

// الحصول على المعدل الفصلي للطالب
$semester_gpa = get_student_semester_gpa($db, $student_id);

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('grades'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        .grade-card {
            border-radius: 0.5rem;
            overflow: hidden;
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
        }
        
        .grade-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .grade-header {
            padding: 1.5rem;
            color: white;
            position: relative;
        }
        
        .grade-header .course-code {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background-color: rgba(255, 255, 255, 0.2);
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.8rem;
        }
        
        [dir="rtl"] .grade-header .course-code {
            right: auto;
            left: 1rem;
        }
        
        .grade-body {
            padding: 1.5rem;
        }
        
        .grade-footer {
            padding: 1rem 1.5rem;
            background-color: rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .grade-meta {
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 1rem;
        }
        
        .grade-meta-item {
            display: flex;
            align-items: center;
            margin-right: 1rem;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            color: var(--gray-color);
        }
        
        [dir="rtl"] .grade-meta-item {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .grade-meta-item i {
            margin-right: 0.5rem;
            width: 16px;
            text-align: center;
        }
        
        [dir="rtl"] .grade-meta-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .grade-actions {
            display: flex;
            gap: 0.5rem;
        }
        
        .grade-badge {
            position: absolute;
            top: 1rem;
            left: 1rem;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.8rem;
            font-weight: 600;
            z-index: 1;
        }
        
        [dir="rtl"] .grade-badge {
            left: auto;
            right: 1rem;
        }
        
        .grade-circle {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            border: 8px solid;
        }
        
        .grade-circle.excellent {
            border-color: #28a745;
            color: #28a745;
        }
        
        .grade-circle.very-good {
            border-color: #17a2b8;
            color: #17a2b8;
        }
        
        .grade-circle.good {
            border-color: #6f42c1;
            color: #6f42c1;
        }
        
        .grade-circle.pass {
            border-color: #fd7e14;
            color: #fd7e14;
        }
        
        .grade-circle.fail {
            border-color: #dc3545;
            color: #dc3545;
        }
        
        .grade-circle .grade-value {
            font-size: 2rem;
            font-weight: 700;
            line-height: 1;
        }
        
        .grade-circle .grade-text {
            font-size: 0.9rem;
            margin-top: 0.25rem;
        }
        
        .grade-progress {
            height: 0.5rem;
            border-radius: 0.25rem;
            margin-bottom: 0.5rem;
        }
        
        .grade-filter {
            margin-bottom: 2rem;
        }
        
        .filter-btn {
            border-radius: 2rem;
            padding: 0.5rem 1.5rem;
            margin-right: 0.5rem;
            margin-bottom: 0.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        [dir="rtl"] .filter-btn {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .filter-btn.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .grade-search {
            position: relative;
            margin-bottom: 2rem;
        }
        
        .grade-search input {
            padding-left: 3rem;
            padding-right: 1rem;
            height: 50px;
            border-radius: 2rem;
        }
        
        [dir="rtl"] .grade-search input {
            padding-left: 1rem;
            padding-right: 3rem;
        }
        
        .grade-search i {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-color);
        }
        
        [dir="rtl"] .grade-search i {
            left: auto;
            right: 1rem;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .grade-empty {
            text-align: center;
            padding: 3rem;
            background-color: rgba(0, 0, 0, 0.02);
            border-radius: 0.5rem;
        }
        
        .grade-empty i {
            font-size: 4rem;
            color: var(--gray-color);
            margin-bottom: 1.5rem;
        }
        
        .grade-empty h4 {
            margin-bottom: 1rem;
        }
        
        .grade-empty p {
            color: var(--gray-color);
            margin-bottom: 1.5rem;
        }
        
        .gpa-card {
            border-radius: 0.5rem;
            overflow: hidden;
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
        }
        
        .gpa-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .gpa-header {
            padding: 1.5rem;
            color: white;
            background-color: var(--primary-color);
        }
        
        .gpa-body {
            padding: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .gpa-value {
            font-size: 3rem;
            font-weight: 700;
            line-height: 1;
            color: var(--primary-color);
        }
        
        .gpa-text {
            font-size: 1.2rem;
            color: var(--gray-color);
        }
        
        .gpa-scale {
            font-size: 0.9rem;
            color: var(--gray-color);
        }
        
        .gpa-info {
            flex: 1;
            padding-left: 1.5rem;
        }
        
        [dir="rtl"] .gpa-info {
            padding-left: 0;
            padding-right: 1.5rem;
        }
        
        .gpa-details {
            margin-top: 1rem;
        }
        
        .gpa-detail-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
        
        .gpa-detail-label {
            color: var(--gray-color);
        }
        
        .gpa-detail-value {
            font-weight: 600;
        }
        
        .semester-select {
            margin-bottom: 2rem;
        }
        
        .table-grades th, .table-grades td {
            vertical-align: middle;
        }
        
        .grade-letter {
            font-weight: 700;
            font-size: 1.2rem;
        }
        
        .grade-letter.excellent {
            color: #28a745;
        }
        
        .grade-letter.very-good {
            color: #17a2b8;
        }
        
        .grade-letter.good {
            color: #6f42c1;
        }
        
        .grade-letter.pass {
            color: #fd7e14;
        }
        
        .grade-letter.fail {
            color: #dc3545;
        }
        
        .grade-points {
            font-size: 0.9rem;
            color: var(--gray-color);
        }
        
        .nav-tabs .nav-link {
            border: none;
            border-bottom: 2px solid transparent;
            border-radius: 0;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            color: var(--text-color);
        }
        
        .nav-tabs .nav-link.active {
            border-bottom-color: var(--primary-color);
            color: var(--primary-color);
            background-color: transparent;
        }
        
        .nav-tabs .nav-link:hover {
            border-bottom-color: rgba(0, 48, 73, 0.5);
        }
        
        .chart-container {
            position: relative;
            height: 300px;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="student_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="student_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-book"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم إضافة محتوى جديد في مقرر برمجة الويب</p>
                                    <small class="text-muted">منذ 10 دقائق</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-tasks"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تذكير: موعد تسليم واجب قواعد البيانات غداً</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-success text-white rounded-circle">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تصحيح واجب البرمجة المتقدمة</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user1.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. محمد أحمد</p>
                                    <small class="text-muted">هل لديك استفسارات حول المشروع النهائي؟</small>
                                    <small class="text-muted d-block">منذ 15 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user2.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">أ. سارة خالد</p>
                                    <small class="text-muted">تم تحديد موعد المراجعة النهائية للاختبار</small>
                                    <small class="text-muted d-block">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $student['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $student['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $student['name']; ?></h6>
                            <small><?php echo $student['student_id']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="student_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="student_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <div>
                <h1 class="h3"><?php echo t('grades'); ?></h1>
                <p class="text-muted"><?php echo t('grades_subtitle'); ?></p>
            </div>
            <div>
                <a href="#" class="btn btn-outline-primary" id="printGrades">
                    <i class="fas fa-print me-1"></i> <?php echo t('print_grades'); ?>
                </a>
                <a href="#" class="btn btn-primary" id="downloadTranscript">
                    <i class="fas fa-download me-1"></i> <?php echo t('download_transcript'); ?>
                </a>
            </div>
        </div>
        
        <!-- بطاقات المعدل -->
        <div class="row mb-4">
            <div class="col-lg-6">
                <div class="gpa-card">
                    <div class="gpa-header">
                        <h5 class="mb-0"><?php echo t('cumulative_gpa'); ?></h5>
                    </div>
                    <div class="gpa-body">
                        <div class="gpa-value"><?php echo $gpa['value']; ?></div>
                        <div class="gpa-info">
                            <div class="gpa-text"><?php echo $gpa['text']; ?></div>
                            <div class="gpa-scale"><?php echo t('scale'); ?>: 4.0</div>
                            
                            <div class="gpa-details">
                                <div class="gpa-detail-item">
                                    <span class="gpa-detail-label"><?php echo t('total_credits'); ?>:</span>
                                    <span class="gpa-detail-value"><?php echo $gpa['total_credits']; ?></span>
                                </div>
                                <div class="gpa-detail-item">
                                    <span class="gpa-detail-label"><?php echo t('completed_credits'); ?>:</span>
                                    <span class="gpa-detail-value"><?php echo $gpa['completed_credits']; ?></span>
                                </div>
                                <div class="gpa-detail-item">
                                    <span class="gpa-detail-label"><?php echo t('remaining_credits'); ?>:</span>
                                    <span class="gpa-detail-value"><?php echo $gpa['remaining_credits']; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-6">
                <div class="gpa-card">
                    <div class="gpa-header">
                        <h5 class="mb-0"><?php echo t('semester_gpa'); ?></h5>
                    </div>
                    <div class="gpa-body">
                        <div class="gpa-value"><?php echo $semester_gpa['value']; ?></div>
                        <div class="gpa-info">
                            <div class="gpa-text"><?php echo $semester_gpa['text']; ?></div>
                            <div class="gpa-scale"><?php echo t('semester'); ?>: <?php echo $semester_gpa['semester']; ?></div>
                            
                            <div class="gpa-details">
                                <div class="gpa-detail-item">
                                    <span class="gpa-detail-label"><?php echo t('registered_courses'); ?>:</span>
                                    <span class="gpa-detail-value"><?php echo $semester_gpa['registered_courses']; ?></span>
                                </div>
                                <div class="gpa-detail-item">
                                    <span class="gpa-detail-label"><?php echo t('semester_credits'); ?>:</span>
                                    <span class="gpa-detail-value"><?php echo $semester_gpa['semester_credits']; ?></span>
                                </div>
                                <div class="gpa-detail-item">
                                    <span class="gpa-detail-label"><?php echo t('completed_courses'); ?>:</span>
                                    <span class="gpa-detail-value"><?php echo $semester_gpa['completed_courses']; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- الرسوم البيانية -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0"><?php echo t('grade_distribution'); ?></h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="chart-container">
                            <canvas id="gradeDistributionChart"></canvas>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="chart-container">
                            <canvas id="gpaProgressChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- علامات التبويب -->
        <ul class="nav nav-tabs mb-4" id="gradeTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="current-tab" data-bs-toggle="tab" data-bs-target="#current" type="button" role="tab" aria-controls="current" aria-selected="true">
                    <?php echo t('current_semester'); ?>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab" aria-controls="all" aria-selected="false">
                    <?php echo t('all_semesters'); ?>
                </button>
            </li>
        </ul>
        
        <!-- محتوى علامات التبويب -->
        <div class="tab-content" id="gradeTabsContent">
            <!-- الفصل الحالي -->
            <div class="tab-pane fade show active" id="current" role="tabpanel" aria-labelledby="current-tab">
                <?php if (count($current_semester_grades) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover table-grades">
                            <thead>
                                <tr>
                                    <th><?php echo t('course_code'); ?></th>
                                    <th><?php echo t('course_name'); ?></th>
                                    <th><?php echo t('credit_hours'); ?></th>
                                    <th><?php echo t('midterm'); ?></th>
                                    <th><?php echo t('assignments'); ?></th>
                                    <th><?php echo t('final'); ?></th>
                                    <th><?php echo t('total'); ?></th>
                                    <th><?php echo t('grade'); ?></th>
                                    <th><?php echo t('points'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($current_semester_grades as $grade): ?>
                                    <tr>
                                        <td><strong><?php echo $grade['course_code']; ?></strong></td>
                                        <td><?php echo $grade['course_name']; ?></td>
                                        <td><?php echo $grade['credit_hours']; ?></td>
                                        <td><?php echo $grade['midterm']; ?></td>
                                        <td><?php echo $grade['assignments']; ?></td>
                                        <td><?php echo $grade['final']; ?></td>
                                        <td><strong><?php echo $grade['total']; ?></strong></td>
                                        <td>
                                            <span class="grade-letter <?php echo $grade['grade_class']; ?>"><?php echo $grade['grade']; ?></span>
                                        </td>
                                        <td>
                                            <span class="grade-points"><?php echo $grade['points']; ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr class="table-light">
                                    <td colspan="2"><strong><?php echo t('semester_total'); ?></strong></td>
                                    <td><strong><?php echo $semester_gpa['semester_credits']; ?></strong></td>
                                    <td colspan="4"></td>
                                    <td><strong><?php echo t('gpa'); ?></strong></td>
                                    <td><strong><?php echo $semester_gpa['value']; ?></strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="grade-empty">
                        <i class="fas fa-chart-line"></i>
                        <h4><?php echo t('no_current_grades'); ?></h4>
                        <p><?php echo t('no_current_grades_message'); ?></p>
                        <a href="student_dashboard.php" class="btn btn-primary">
                            <i class="fas fa-home me-1"></i> <?php echo t('back_to_dashboard'); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- جميع الفصول -->
            <div class="tab-pane fade" id="all" role="tabpanel" aria-labelledby="all-tab">
                <?php if (count($all_semesters_grades) > 0): ?>
                    <!-- اختيار الفصل -->
                    <div class="semester-select">
                        <select class="form-select" id="semesterSelect">
                            <?php foreach ($all_semesters_grades as $semester => $grades): ?>
                                <option value="<?php echo $semester; ?>"><?php echo $semester; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <?php foreach ($all_semesters_grades as $semester => $grades): ?>
                        <div class="semester-grades" id="semester-<?php echo str_replace(' ', '-', $semester); ?>" style="display: <?php echo array_key_first($all_semesters_grades) === $semester ? 'block' : 'none'; ?>">
                            <div class="table-responsive">
                                <table class="table table-hover table-grades">
                                    <thead>
                                        <tr>
                                            <th><?php echo t('course_code'); ?></th>
                                            <th><?php echo t('course_name'); ?></th>
                                            <th><?php echo t('credit_hours'); ?></th>
                                            <th><?php echo t('midterm'); ?></th>
                                            <th><?php echo t('assignments'); ?></th>
                                            <th><?php echo t('final'); ?></th>
                                            <th><?php echo t('total'); ?></th>
                                            <th><?php echo t('grade'); ?></th>
                                            <th><?php echo t('points'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($grades['courses'] as $grade): ?>
                                            <tr>
                                                <td><strong><?php echo $grade['course_code']; ?></strong></td>
                                                <td><?php echo $grade['course_name']; ?></td>
                                                <td><?php echo $grade['credit_hours']; ?></td>
                                                <td><?php echo $grade['midterm']; ?></td>
                                                <td><?php echo $grade['assignments']; ?></td>
                                                <td><?php echo $grade['final']; ?></td>
                                                <td><strong><?php echo $grade['total']; ?></strong></td>
                                                <td>
                                                    <span class="grade-letter <?php echo $grade['grade_class']; ?>"><?php echo $grade['grade']; ?></span>
                                                </td>
                                                <td>
                                                    <span class="grade-points"><?php echo $grade['points']; ?></span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr class="table-light">
                                            <td colspan="2"><strong><?php echo t('semester_total'); ?></strong></td>
                                            <td><strong><?php echo $grades['semester_credits']; ?></strong></td>
                                            <td colspan="4"></td>
                                            <td><strong><?php echo t('gpa'); ?></strong></td>
                                            <td><strong><?php echo $grades['semester_gpa']; ?></strong></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="grade-empty">
                        <i class="fas fa-history"></i>
                        <h4><?php echo t('no_previous_grades'); ?></h4>
                        <p><?php echo t('no_previous_grades_message'); ?></p>
                        <a href="#current" class="btn btn-primary" data-bs-toggle="tab" data-bs-target="#current">
                            <i class="fas fa-chart-line me-1"></i> <?php echo t('view_current_semester'); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- نظام التقديرات -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="mb-0"><?php echo t('grading_system'); ?></h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th><?php echo t('percentage'); ?></th>
                                <th><?php echo t('grade'); ?></th>
                                <th><?php echo t('points'); ?></th>
                                <th><?php echo t('description'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>90-100</td>
                                <td><span class="grade-letter excellent">A+</span></td>
                                <td>4.0</td>
                                <td><?php echo t('excellent'); ?></td>
                            </tr>
                            <tr>
                                <td>85-89</td>
                                <td><span class="grade-letter excellent">A</span></td>
                                <td>3.7</td>
                                <td><?php echo t('excellent'); ?></td>
                            </tr>
                            <tr>
                                <td>80-84</td>
                                <td><span class="grade-letter very-good">B+</span></td>
                                <td>3.3</td>
                                <td><?php echo t('very_good'); ?></td>
                            </tr>
                            <tr>
                                <td>75-79</td>
                                <td><span class="grade-letter very-good">B</span></td>
                                <td>3.0</td>
                                <td><?php echo t('very_good'); ?></td>
                            </tr>
                            <tr>
                                <td>70-74</td>
                                <td><span class="grade-letter good">C+</span></td>
                                <td>2.7</td>
                                <td><?php echo t('good'); ?></td>
                            </tr>
                            <tr>
                                <td>65-69</td>
                                <td><span class="grade-letter good">C</span></td>
                                <td>2.3</td>
                                <td><?php echo t('good'); ?></td>
                            </tr>
                            <tr>
                                <td>60-64</td>
                                <td><span class="grade-letter pass">D+</span></td>
                                <td>2.0</td>
                                <td><?php echo t('pass'); ?></td>
                            </tr>
                            <tr>
                                <td>50-59</td>
                                <td><span class="grade-letter pass">D</span></td>
                                <td>1.7</td>
                                <td><?php echo t('pass'); ?></td>
                            </tr>
                            <tr>
                                <td>0-49</td>
                                <td><span class="grade-letter fail">F</span></td>
                                <td>0.0</td>
                                <td><?php echo t('fail'); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // اختيار الفصل
            const semesterSelect = document.getElementById('semesterSelect');
            if (semesterSelect) {
                semesterSelect.addEventListener('change', function() {
                    const selectedSemester = this.value;
                    
                    // إخفاء جميع الفصول
                    document.querySelectorAll('.semester-grades').forEach(semester => {
                        semester.style.display = 'none';
                    });
                    
                    // إظهار الفصل المحدد
                    const selectedSemesterElement = document.getElementById('semester-' + selectedSemester.replace(' ', '-'));
                    if (selectedSemesterElement) {
                        selectedSemesterElement.style.display = 'block';
                    }
                });
            }
            
            // طباعة الدرجات
            document.getElementById('printGrades').addEventListener('click', function(e) {
                e.preventDefault();
                window.print();
            });
            
            // تنزيل كشف الدرجات
            document.getElementById('downloadTranscript').addEventListener('click', function(e) {
                e.preventDefault();
                // هنا يمكن إضافة كود لتنزيل كشف الدرجات كملف PDF
                alert('سيتم تنزيل كشف الدرجات قريباً');
            });
            
            // رسم الرسوم البيانية
            // رسم بياني لتوزيع الدرجات
            const gradeDistributionCtx = document.getElementById('gradeDistributionChart').getContext('2d');
            const gradeDistributionChart = new Chart(gradeDistributionCtx, {
                type: 'pie',
                data: {
                    labels: ['A+', 'A', 'B+', 'B', 'C+', 'C', 'D+', 'D', 'F'],
                    datasets: [{
                        label: '<?php echo t('grade_distribution'); ?>',
                        data: [2, 3, 4, 2, 1, 0, 0, 0, 0],
                        backgroundColor: [
                            '#28a745',
                            '#20c997',
                            '#17a2b8',
                            '#0dcaf0',
                            '#6f42c1',
                            '#6610f2',
                            '#fd7e14',
                            '#ffc107',
                            '#dc3545'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right',
                        },
                        title: {
                            display: true,
                            text: '<?php echo t('grade_distribution'); ?>'
                        }
                    }
                }
            });
            
            // رسم بياني لتقدم المعدل التراكمي
            const gpaProgressCtx = document.getElementById('gpaProgressChart').getContext('2d');
            const gpaProgressChart = new Chart(gpaProgressCtx, {
                type: 'line',
                data: {
                    labels: ['الفصل الأول', 'الفصل الثاني', 'الفصل الثالث', 'الفصل الرابع', 'الفصل الحالي'],
                    datasets: [{
                        label: '<?php echo t('gpa_progress'); ?>',
                        data: [3.2, 3.4, 3.6, 3.7, 3.8],
                        fill: false,
                        borderColor: '#003049',
                        tension: 0.1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: false,
                            min: 2.0,
                            max: 4.0
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: '<?php echo t('gpa_progress'); ?>'
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>
