<?php
/**
 * صفحة الإشعارات للطالب في نظام UniverBoard
 * تعرض قائمة الإشعارات المستلمة وتتيح إدارتها
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول الطالب
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات الطالب
$student_id = $_SESSION['user_id'];
$db = get_db_connection();
$student = get_student_info($db, $student_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// الحصول على الإشعارات غير المقروءة
$unread_notifications = get_unread_notifications($db, $student_id);

// الحصول على الإشعارات المقروءة
$read_notifications = get_read_notifications($db, $student_id);

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('notifications'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .notification-item {
            padding: 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
            position: relative;
            border-left: 4px solid transparent;
        }
        
        [dir="rtl"] .notification-item {
            border-left: none;
            border-right: 4px solid transparent;
        }
        
        .notification-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .notification-item.unread {
            background-color: rgba(0, 48, 73, 0.05);
            border-left-color: var(--primary-color);
        }
        
        [dir="rtl"] .notification-item.unread {
            border-left: none;
            border-right-color: var(--primary-color);
        }
        
        .notification-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        
        [dir="rtl"] .notification-icon {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .notification-icon.primary {
            background-color: var(--primary-color);
        }
        
        .notification-icon.success {
            background-color: #28a745;
        }
        
        .notification-icon.warning {
            background-color: #ffc107;
        }
        
        .notification-icon.danger {
            background-color: #dc3545;
        }
        
        .notification-icon.info {
            background-color: #17a2b8;
        }
        
        .notification-content {
            flex: 1;
        }
        
        .notification-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .notification-text {
            color: var(--gray-color);
            margin-bottom: 0.5rem;
        }
        
        .notification-meta {
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 0.8rem;
            color: var(--gray-color);
        }
        
        .notification-time {
            display: flex;
            align-items: center;
        }
        
        .notification-time i {
            margin-right: 0.25rem;
            font-size: 0.9rem;
        }
        
        [dir="rtl"] .notification-time i {
            margin-right: 0;
            margin-left: 0.25rem;
        }
        
        .notification-source {
            display: flex;
            align-items: center;
        }
        
        .notification-source i {
            margin-right: 0.25rem;
            font-size: 0.9rem;
        }
        
        [dir="rtl"] .notification-source i {
            margin-right: 0;
            margin-left: 0.25rem;
        }
        
        .notification-actions {
            position: absolute;
            top: 1rem;
            right: 1rem;
            display: flex;
            gap: 0.5rem;
        }
        
        [dir="rtl"] .notification-actions {
            right: auto;
            left: 1rem;
        }
        
        .notification-actions button {
            background: none;
            border: none;
            font-size: 1rem;
            color: var(--gray-color);
            cursor: pointer;
            padding: 0.25rem;
            border-radius: 0.25rem;
            transition: all 0.2s ease;
        }
        
        .notification-actions button:hover {
            background-color: rgba(0, 0, 0, 0.05);
            color: var(--primary-color);
        }
        
        .notification-empty {
            text-align: center;
            padding: 3rem;
            background-color: rgba(0, 0, 0, 0.02);
            border-radius: 0.5rem;
        }
        
        .notification-empty i {
            font-size: 4rem;
            color: var(--gray-color);
            margin-bottom: 1.5rem;
        }
        
        .notification-empty h4 {
            margin-bottom: 1rem;
        }
        
        .notification-empty p {
            color: var(--gray-color);
            margin-bottom: 1.5rem;
        }
        
        .notification-filter {
            margin-bottom: 2rem;
        }
        
        .filter-btn {
            border-radius: 2rem;
            padding: 0.5rem 1.5rem;
            margin-right: 0.5rem;
            margin-bottom: 0.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        [dir="rtl"] .filter-btn {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .filter-btn.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .notification-search {
            position: relative;
            margin-bottom: 2rem;
        }
        
        .notification-search input {
            padding-left: 3rem;
            padding-right: 1rem;
            height: 50px;
            border-radius: 2rem;
        }
        
        [dir="rtl"] .notification-search input {
            padding-left: 1rem;
            padding-right: 3rem;
        }
        
        .notification-search i {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-color);
        }
        
        [dir="rtl"] .notification-search i {
            left: auto;
            right: 1rem;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .nav-tabs .nav-link {
            border: none;
            border-bottom: 2px solid transparent;
            border-radius: 0;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            color: var(--text-color);
        }
        
        .nav-tabs .nav-link.active {
            border-bottom-color: var(--primary-color);
            color: var(--primary-color);
            background-color: transparent;
        }
        
        .nav-tabs .nav-link:hover {
            border-bottom-color: rgba(0, 48, 73, 0.5);
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="student_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="student_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-book"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم إضافة محتوى جديد في مقرر برمجة الويب</p>
                                    <small class="text-muted">منذ 10 دقائق</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-tasks"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تذكير: موعد تسليم واجب قواعد البيانات غداً</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-success text-white rounded-circle">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تصحيح واجب البرمجة المتقدمة</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user1.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. محمد أحمد</p>
                                    <small class="text-muted">هل لديك استفسارات حول المشروع النهائي؟</small>
                                    <small class="text-muted d-block">منذ 15 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user2.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">أ. سارة خالد</p>
                                    <small class="text-muted">تم تحديد موعد المراجعة النهائية للاختبار</small>
                                    <small class="text-muted d-block">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $student['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $student['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $student['name']; ?></h6>
                            <small><?php echo $student['student_id']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="student_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="student_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <div>
                <h1 class="h3"><?php echo t('notifications'); ?></h1>
                <p class="text-muted"><?php echo t('notifications_subtitle'); ?></p>
            </div>
            <div>
                <button class="btn btn-outline-primary" id="markAllAsRead">
                    <i class="fas fa-check-double me-1"></i> <?php echo t('mark_all_as_read'); ?>
                </button>
                <div class="dropdown d-inline-block">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="notificationSettings" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-cog me-1"></i> <?php echo t('settings'); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationSettings">
                        <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#notificationPreferencesModal"><i class="fas fa-sliders-h me-2"></i> <?php echo t('notification_preferences'); ?></a></li>
                        <li><a class="dropdown-item" href="#" id="enablePushNotifications"><i class="fas fa-bell me-2"></i> <?php echo t('enable_push_notifications'); ?></a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="#" id="clearAllNotifications"><i class="fas fa-trash-alt me-2"></i> <?php echo t('clear_all_notifications'); ?></a></li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- البحث والتصفية -->
        <div class="row mb-4">
            <div class="col-md-8">
                <div class="notification-search">
                    <i class="fas fa-search"></i>
                    <input type="text" class="form-control" id="notificationSearch" placeholder="<?php echo t('search_notifications'); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="d-flex justify-content-md-end">
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-filter me-1"></i> <?php echo t('filter_by_type'); ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="filterDropdown">
                            <li><a class="dropdown-item" href="#" data-filter="all"><?php echo t('all_notifications'); ?></a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#" data-filter="course"><?php echo t('courses'); ?></a></li>
                            <li><a class="dropdown-item" href="#" data-filter="assignment"><?php echo t('assignments'); ?></a></li>
                            <li><a class="dropdown-item" href="#" data-filter="exam"><?php echo t('exams'); ?></a></li>
                            <li><a class="dropdown-item" href="#" data-filter="grade"><?php echo t('grades'); ?></a></li>
                            <li><a class="dropdown-item" href="#" data-filter="announcement"><?php echo t('announcements'); ?></a></li>
                            <li><a class="dropdown-item" href="#" data-filter="message"><?php echo t('messages'); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- علامات التبويب -->
        <ul class="nav nav-tabs mb-4" id="notificationTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="unread-tab" data-bs-toggle="tab" data-bs-target="#unread" type="button" role="tab" aria-controls="unread" aria-selected="true">
                    <?php echo t('unread'); ?> <span class="badge bg-primary ms-1"><?php echo count($unread_notifications); ?></span>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab" aria-controls="all" aria-selected="false">
                    <?php echo t('all_notifications'); ?>
                </button>
            </li>
        </ul>
        
        <!-- محتوى علامات التبويب -->
        <div class="tab-content" id="notificationTabsContent">
            <!-- الإشعارات غير المقروءة -->
            <div class="tab-pane fade show active" id="unread" role="tabpanel" aria-labelledby="unread-tab">
                <?php if (count($unread_notifications) > 0): ?>
                    <div id="unreadNotifications">
                        <?php foreach ($unread_notifications as $notification): ?>
                            <div class="notification-item unread d-flex" data-type="<?php echo $notification['type']; ?>">
                                <div class="notification-icon <?php echo $notification['icon_class']; ?>">
                                    <i class="fas <?php echo $notification['icon']; ?>"></i>
                                </div>
                                <div class="notification-content">
                                    <h5 class="notification-title"><?php echo $notification['title']; ?></h5>
                                    <p class="notification-text"><?php echo $notification['message']; ?></p>
                                    <div class="notification-meta">
                                        <div class="notification-time">
                                            <i class="far fa-clock"></i>
                                            <span><?php echo $notification['time']; ?></span>
                                        </div>
                                        <div class="notification-source">
                                            <i class="fas fa-tag"></i>
                                            <span><?php echo $notification['source']; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="notification-actions">
                                    <button class="mark-as-read" data-id="<?php echo $notification['id']; ?>" title="<?php echo t('mark_as_read'); ?>">
                                        <i class="fas fa-check"></i>
                                    </button>
                                    <button class="delete-notification" data-id="<?php echo $notification['id']; ?>" title="<?php echo t('delete'); ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="notification-empty">
                        <i class="fas fa-bell-slash"></i>
                        <h4><?php echo t('no_unread_notifications'); ?></h4>
                        <p><?php echo t('no_unread_notifications_message'); ?></p>
                        <a href="#all" class="btn btn-primary" data-bs-toggle="tab" data-bs-target="#all">
                            <i class="fas fa-bell me-1"></i> <?php echo t('view_all_notifications'); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- جميع الإشعارات -->
            <div class="tab-pane fade" id="all" role="tabpanel" aria-labelledby="all-tab">
                <?php if (count($unread_notifications) > 0 || count($read_notifications) > 0): ?>
                    <div id="allNotifications">
                        <?php foreach ($unread_notifications as $notification): ?>
                            <div class="notification-item unread d-flex" data-type="<?php echo $notification['type']; ?>">
                                <div class="notification-icon <?php echo $notification['icon_class']; ?>">
                                    <i class="fas <?php echo $notification['icon']; ?>"></i>
                                </div>
                                <div class="notification-content">
                                    <h5 class="notification-title"><?php echo $notification['title']; ?></h5>
                                    <p class="notification-text"><?php echo $notification['message']; ?></p>
                                    <div class="notification-meta">
                                        <div class="notification-time">
                                            <i class="far fa-clock"></i>
                                            <span><?php echo $notification['time']; ?></span>
                                        </div>
                                        <div class="notification-source">
                                            <i class="fas fa-tag"></i>
                                            <span><?php echo $notification['source']; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="notification-actions">
                                    <button class="mark-as-read" data-id="<?php echo $notification['id']; ?>" title="<?php echo t('mark_as_read'); ?>">
                                        <i class="fas fa-check"></i>
                                    </button>
                                    <button class="delete-notification" data-id="<?php echo $notification['id']; ?>" title="<?php echo t('delete'); ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <?php foreach ($read_notifications as $notification): ?>
                            <div class="notification-item d-flex" data-type="<?php echo $notification['type']; ?>">
                                <div class="notification-icon <?php echo $notification['icon_class']; ?>">
                                    <i class="fas <?php echo $notification['icon']; ?>"></i>
                                </div>
                                <div class="notification-content">
                                    <h5 class="notification-title"><?php echo $notification['title']; ?></h5>
                                    <p class="notification-text"><?php echo $notification['message']; ?></p>
                                    <div class="notification-meta">
                                        <div class="notification-time">
                                            <i class="far fa-clock"></i>
                                            <span><?php echo $notification['time']; ?></span>
                                        </div>
                                        <div class="notification-source">
                                            <i class="fas fa-tag"></i>
                                            <span><?php echo $notification['source']; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="notification-actions">
                                    <button class="delete-notification" data-id="<?php echo $notification['id']; ?>" title="<?php echo t('delete'); ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="notification-empty">
                        <i class="fas fa-bell-slash"></i>
                        <h4><?php echo t('no_notifications'); ?></h4>
                        <p><?php echo t('no_notifications_message'); ?></p>
                        <a href="student_dashboard.php" class="btn btn-primary">
                            <i class="fas fa-home me-1"></i> <?php echo t('back_to_dashboard'); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- مودال تفضيلات الإشعارات -->
    <div class="modal fade" id="notificationPreferencesModal" tabindex="-1" aria-labelledby="notificationPreferencesModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="notificationPreferencesModalLabel"><?php echo t('notification_preferences'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="notificationPreferencesForm">
                        <div class="mb-3">
                            <label class="form-label"><?php echo t('receive_notifications_for'); ?>:</label>
                            
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="courseNotifications" checked>
                                <label class="form-check-label" for="courseNotifications"><?php echo t('course_updates'); ?></label>
                            </div>
                            
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="assignmentNotifications" checked>
                                <label class="form-check-label" for="assignmentNotifications"><?php echo t('assignment_updates'); ?></label>
                            </div>
                            
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="examNotifications" checked>
                                <label class="form-check-label" for="examNotifications"><?php echo t('exam_updates'); ?></label>
                            </div>
                            
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="gradeNotifications" checked>
                                <label class="form-check-label" for="gradeNotifications"><?php echo t('grade_updates'); ?></label>
                            </div>
                            
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="announcementNotifications" checked>
                                <label class="form-check-label" for="announcementNotifications"><?php echo t('announcements'); ?></label>
                            </div>
                            
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="messageNotifications" checked>
                                <label class="form-check-label" for="messageNotifications"><?php echo t('messages'); ?></label>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label"><?php echo t('notification_methods'); ?>:</label>
                            
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="emailNotifications" checked>
                                <label class="form-check-label" for="emailNotifications"><?php echo t('email'); ?></label>
                            </div>
                            
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="smsNotifications">
                                <label class="form-check-label" for="smsNotifications"><?php echo t('sms'); ?></label>
                            </div>
                            
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="pushNotifications" checked>
                                <label class="form-check-label" for="pushNotifications"><?php echo t('push_notifications'); ?></label>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="button" class="btn btn-primary" id="saveNotificationPreferences"><?php echo t('save_preferences'); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // البحث في الإشعارات
            const searchInput = document.getElementById('notificationSearch');
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                
                // البحث في الإشعارات غير المقروءة
                const unreadNotifications = document.querySelectorAll('#unreadNotifications .notification-item');
                unreadNotifications.forEach(notification => {
                    const notificationTitle = notification.querySelector('.notification-title').textContent.toLowerCase();
                    const notificationText = notification.querySelector('.notification-text').textContent.toLowerCase();
                    const notificationSource = notification.querySelector('.notification-source span').textContent.toLowerCase();
                    
                    if (notificationTitle.includes(searchTerm) || notificationText.includes(searchTerm) || notificationSource.includes(searchTerm)) {
                        notification.style.display = 'flex';
                    } else {
                        notification.style.display = 'none';
                    }
                });
                
                // البحث في جميع الإشعارات
                const allNotifications = document.querySelectorAll('#allNotifications .notification-item');
                allNotifications.forEach(notification => {
                    const notificationTitle = notification.querySelector('.notification-title').textContent.toLowerCase();
                    const notificationText = notification.querySelector('.notification-text').textContent.toLowerCase();
                    const notificationSource = notification.querySelector('.notification-source span').textContent.toLowerCase();
                    
                    if (notificationTitle.includes(searchTerm) || notificationText.includes(searchTerm) || notificationSource.includes(searchTerm)) {
                        notification.style.display = 'flex';
                    } else {
                        notification.style.display = 'none';
                    }
                });
            });
            
            // تصفية الإشعارات حسب النوع
            const filterLinks = document.querySelectorAll('[data-filter]');
            filterLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // الحصول على فئة التصفية
                    const filter = this.getAttribute('data-filter');
                    
                    // تصفية الإشعارات غير المقروءة
                    const unreadNotifications = document.querySelectorAll('#unreadNotifications .notification-item');
                    unreadNotifications.forEach(notification => {
                        if (filter === 'all' || notification.getAttribute('data-type') === filter) {
                            notification.style.display = 'flex';
                        } else {
                            notification.style.display = 'none';
                        }
                    });
                    
                    // تصفية جميع الإشعارات
                    const allNotifications = document.querySelectorAll('#allNotifications .notification-item');
                    allNotifications.forEach(notification => {
                        if (filter === 'all' || notification.getAttribute('data-type') === filter) {
                            notification.style.display = 'flex';
                        } else {
                            notification.style.display = 'none';
                        }
                    });
                    
                    // تحديث نص زر التصفية
                    document.getElementById('filterDropdown').innerHTML = `<i class="fas fa-filter me-1"></i> ${this.textContent}`;
                });
            });
            
            // تعليم الإشعار كمقروء
            const markAsReadButtons = document.querySelectorAll('.mark-as-read');
            markAsReadButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const notificationId = this.getAttribute('data-id');
                    const notificationItem = this.closest('.notification-item');
                    
                    // إرسال طلب AJAX لتعليم الإشعار كمقروء
                    // هنا يمكن إضافة كود لإرسال طلب AJAX
                    
                    // إزالة فئة "unread" من الإشعار
                    notificationItem.classList.remove('unread');
                    
                    // إزالة زر "تعليم كمقروء"
                    this.remove();
                    
                    // تحديث عدد الإشعارات غير المقروءة
                    const unreadCount = document.querySelectorAll('#unreadNotifications .notification-item.unread').length;
                    document.querySelector('#unread-tab .badge').textContent = unreadCount;
                    
                    // إذا كان عدد الإشعارات غير المقروءة صفر، عرض رسالة "لا توجد إشعارات غير مقروءة"
                    if (unreadCount === 0) {
                        const emptyMessage = `
                            <div class="notification-empty">
                                <i class="fas fa-bell-slash"></i>
                                <h4>${t('no_unread_notifications')}</h4>
                                <p>${t('no_unread_notifications_message')}</p>
                                <a href="#all" class="btn btn-primary" data-bs-toggle="tab" data-bs-target="#all">
                                    <i class="fas fa-bell me-1"></i> ${t('view_all_notifications')}
                                </a>
                            </div>
                        `;
                        document.getElementById('unreadNotifications').innerHTML = emptyMessage;
                    }
                });
            });
            
            // حذف الإشعار
            const deleteButtons = document.querySelectorAll('.delete-notification');
            deleteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const notificationId = this.getAttribute('data-id');
                    const notificationItem = this.closest('.notification-item');
                    
                    // إرسال طلب AJAX لحذف الإشعار
                    // هنا يمكن إضافة كود لإرسال طلب AJAX
                    
                    // إزالة الإشعار من العرض
                    notificationItem.remove();
                    
                    // تحديث عدد الإشعارات غير المقروءة
                    const unreadCount = document.querySelectorAll('#unreadNotifications .notification-item.unread').length;
                    document.querySelector('#unread-tab .badge').textContent = unreadCount;
                    
                    // إذا كان عدد الإشعارات غير المقروءة صفر، عرض رسالة "لا توجد إشعارات غير مقروءة"
                    if (unreadCount === 0) {
                        const emptyMessage = `
                            <div class="notification-empty">
                                <i class="fas fa-bell-slash"></i>
                                <h4>${t('no_unread_notifications')}</h4>
                                <p>${t('no_unread_notifications_message')}</p>
                                <a href="#all" class="btn btn-primary" data-bs-toggle="tab" data-bs-target="#all">
                                    <i class="fas fa-bell me-1"></i> ${t('view_all_notifications')}
                                </a>
                            </div>
                        `;
                        document.getElementById('unreadNotifications').innerHTML = emptyMessage;
                    }
                    
                    // إذا كان عدد جميع الإشعارات صفر، عرض رسالة "لا توجد إشعارات"
                    const allCount = document.querySelectorAll('#allNotifications .notification-item').length;
                    if (allCount === 0) {
                        const emptyMessage = `
                            <div class="notification-empty">
                                <i class="fas fa-bell-slash"></i>
                                <h4>${t('no_notifications')}</h4>
                                <p>${t('no_notifications_message')}</p>
                                <a href="student_dashboard.php" class="btn btn-primary">
                                    <i class="fas fa-home me-1"></i> ${t('back_to_dashboard')}
                                </a>
                            </div>
                        `;
                        document.getElementById('allNotifications').innerHTML = emptyMessage;
                    }
                });
            });
            
            // تعليم جميع الإشعارات كمقروءة
            document.getElementById('markAllAsRead').addEventListener('click', function() {
                // إرسال طلب AJAX لتعليم جميع الإشعارات كمقروءة
                // هنا يمكن إضافة كود لإرسال طلب AJAX
                
                // إزالة فئة "unread" من جميع الإشعارات
                const unreadNotifications = document.querySelectorAll('.notification-item.unread');
                unreadNotifications.forEach(notification => {
                    notification.classList.remove('unread');
                    notification.querySelector('.mark-as-read').remove();
                });
                
                // تحديث عدد الإشعارات غير المقروءة
                document.querySelector('#unread-tab .badge').textContent = '0';
                
                // عرض رسالة "لا توجد إشعارات غير مقروءة"
                const emptyMessage = `
                    <div class="notification-empty">
                        <i class="fas fa-bell-slash"></i>
                        <h4>${t('no_unread_notifications')}</h4>
                        <p>${t('no_unread_notifications_message')}</p>
                        <a href="#all" class="btn btn-primary" data-bs-toggle="tab" data-bs-target="#all">
                            <i class="fas fa-bell me-1"></i> ${t('view_all_notifications')}
                        </a>
                    </div>
                `;
                document.getElementById('unreadNotifications').innerHTML = emptyMessage;
            });
            
            // حذف جميع الإشعارات
            document.getElementById('clearAllNotifications').addEventListener('click', function() {
                if (confirm(t('confirm_clear_all_notifications'))) {
                    // إرسال طلب AJAX لحذف جميع الإشعارات
                    // هنا يمكن إضافة كود لإرسال طلب AJAX
                    
                    // إزالة جميع الإشعارات من العرض
                    document.querySelectorAll('.notification-item').forEach(notification => {
                        notification.remove();
                    });
                    
                    // تحديث عدد الإشعارات غير المقروءة
                    document.querySelector('#unread-tab .badge').textContent = '0';
                    
                    // عرض رسالة "لا توجد إشعارات غير مقروءة"
                    const emptyUnreadMessage = `
                        <div class="notification-empty">
                            <i class="fas fa-bell-slash"></i>
                            <h4>${t('no_unread_notifications')}</h4>
                            <p>${t('no_unread_notifications_message')}</p>
                            <a href="#all" class="btn btn-primary" data-bs-toggle="tab" data-bs-target="#all">
                                <i class="fas fa-bell me-1"></i> ${t('view_all_notifications')}
                            </a>
                        </div>
                    `;
                    document.getElementById('unreadNotifications').innerHTML = emptyUnreadMessage;
                    
                    // عرض رسالة "لا توجد إشعارات"
                    const emptyAllMessage = `
                        <div class="notification-empty">
                            <i class="fas fa-bell-slash"></i>
                            <h4>${t('no_notifications')}</h4>
                            <p>${t('no_notifications_message')}</p>
                            <a href="student_dashboard.php" class="btn btn-primary">
                                <i class="fas fa-home me-1"></i> ${t('back_to_dashboard')}
                            </a>
                        </div>
                    `;
                    document.getElementById('allNotifications').innerHTML = emptyAllMessage;
                }
            });
            
            // تمكين إشعارات الدفع
            document.getElementById('enablePushNotifications').addEventListener('click', function(e) {
                e.preventDefault();
                
                // التحقق من دعم إشعارات الدفع
                if ('Notification' in window) {
                    Notification.requestPermission().then(function(permission) {
                        if (permission === 'granted') {
                            alert(t('push_notifications_enabled'));
                        }
                    });
                } else {
                    alert(t('push_notifications_not_supported'));
                }
            });
            
            // حفظ تفضيلات الإشعارات
            document.getElementById('saveNotificationPreferences').addEventListener('click', function() {
                // إرسال طلب AJAX لحفظ تفضيلات الإشعارات
                // هنا يمكن إضافة كود لإرسال طلب AJAX
                
                // إغلاق المودال
                const modal = bootstrap.Modal.getInstance(document.getElementById('notificationPreferencesModal'));
                modal.hide();
                
                // عرض رسالة نجاح
                alert(t('notification_preferences_saved'));
            });
            
            // دالة ترجمة النصوص
            function t(key) {
                // هذه الدالة تستخدم للترجمة في JavaScript
                // في التطبيق الحقيقي، يمكن استخدام كائن ترجمة مخزن في متغير عام
                const translations = {
                    'no_unread_notifications': 'لا توجد إشعارات غير مقروءة',
                    'no_unread_notifications_message': 'لقد قمت بقراءة جميع الإشعارات الخاصة بك.',
                    'view_all_notifications': 'عرض جميع الإشعارات',
                    'no_notifications': 'لا توجد إشعارات',
                    'no_notifications_message': 'ليس لديك أي إشعارات في الوقت الحالي.',
                    'back_to_dashboard': 'العودة إلى لوحة التحكم',
                    'confirm_clear_all_notifications': 'هل أنت متأكد من رغبتك في حذف جميع الإشعارات؟',
                    'push_notifications_enabled': 'تم تمكين إشعارات الدفع بنجاح!',
                    'push_notifications_not_supported': 'متصفحك لا يدعم إشعارات الدفع.',
                    'notification_preferences_saved': 'تم حفظ تفضيلات الإشعارات بنجاح!'
                };
                
                return translations[key] || key;
            }
        });
    </script>
</body>
</html>
