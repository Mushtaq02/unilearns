<?php
/**
 * صفحة الواجبات للطالب في نظام UniverBoard
 * تعرض قائمة الواجبات المطلوبة والمقدمة وتتيح تقديم الواجبات الجديدة
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول الطالب
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات الطالب
$student_id = $_SESSION['user_id'];
$db = get_db_connection();
$student = get_student_info($db, $student_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// الحصول على الواجبات المطلوبة
$pending_assignments = get_pending_assignments($db, $student_id);

// الحصول على الواجبات المقدمة
$submitted_assignments = get_submitted_assignments($db, $student_id);

// الحصول على الواجبات المصححة
$graded_assignments = get_graded_assignments($db, $student_id);

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('assignments'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .assignment-card {
            border-radius: 0.5rem;
            overflow: hidden;
            transition: all 0.3s ease;
            margin-bottom: 1.5rem;
            height: 100%;
        }
        
        .assignment-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .assignment-header {
            padding: 1.5rem;
            color: white;
            position: relative;
        }
        
        .assignment-body {
            padding: 1.5rem;
        }
        
        .assignment-footer {
            padding: 1rem 1.5rem;
            background-color: rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .assignment-meta {
            display: flex;
            flex-wrap: wrap;
            margin-bottom: 1rem;
        }
        
        .assignment-meta-item {
            display: flex;
            align-items: center;
            margin-right: 1rem;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            color: var(--gray-color);
        }
        
        [dir="rtl"] .assignment-meta-item {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .assignment-meta-item i {
            margin-right: 0.5rem;
            width: 16px;
            text-align: center;
        }
        
        [dir="rtl"] .assignment-meta-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .assignment-actions {
            display: flex;
            gap: 0.5rem;
        }
        
        .assignment-badge {
            position: absolute;
            top: 1rem;
            left: 1rem;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.8rem;
            font-weight: 600;
            z-index: 1;
        }
        
        [dir="rtl"] .assignment-badge {
            left: auto;
            right: 1rem;
        }
        
        .assignment-course {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background-color: rgba(255, 255, 255, 0.2);
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.8rem;
        }
        
        [dir="rtl"] .assignment-course {
            right: auto;
            left: 1rem;
        }
        
        .assignment-progress {
            height: 0.5rem;
            border-radius: 0.25rem;
            margin-bottom: 1rem;
        }
        
        .assignment-filter {
            margin-bottom: 2rem;
        }
        
        .filter-btn {
            border-radius: 2rem;
            padding: 0.5rem 1.5rem;
            margin-right: 0.5rem;
            margin-bottom: 0.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        [dir="rtl"] .filter-btn {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .filter-btn.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .assignment-search {
            position: relative;
            margin-bottom: 2rem;
        }
        
        .assignment-search input {
            padding-left: 3rem;
            padding-right: 1rem;
            height: 50px;
            border-radius: 2rem;
        }
        
        [dir="rtl"] .assignment-search input {
            padding-left: 1rem;
            padding-right: 3rem;
        }
        
        .assignment-search i {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-color);
        }
        
        [dir="rtl"] .assignment-search i {
            left: auto;
            right: 1rem;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .assignment-empty {
            text-align: center;
            padding: 3rem;
            background-color: rgba(0, 0, 0, 0.02);
            border-radius: 0.5rem;
        }
        
        .assignment-empty i {
            font-size: 4rem;
            color: var(--gray-color);
            margin-bottom: 1.5rem;
        }
        
        .assignment-empty h4 {
            margin-bottom: 1rem;
        }
        
        .assignment-empty p {
            color: var(--gray-color);
            margin-bottom: 1.5rem;
        }
        
        .file-upload {
            border: 2px dashed rgba(0, 0, 0, 0.1);
            border-radius: 0.5rem;
            padding: 2rem;
            text-align: center;
            margin-bottom: 1.5rem;
            transition: all 0.3s ease;
        }
        
        .file-upload:hover {
            border-color: var(--primary-color);
        }
        
        .file-upload i {
            font-size: 3rem;
            color: var(--gray-color);
            margin-bottom: 1rem;
        }
        
        .file-upload p {
            margin-bottom: 1rem;
        }
        
        .file-upload input {
            display: none;
        }
        
        .file-list {
            margin-top: 1.5rem;
        }
        
        .file-item {
            display: flex;
            align-items: center;
            padding: 0.75rem;
            background-color: rgba(0, 0, 0, 0.02);
            border-radius: 0.5rem;
            margin-bottom: 0.5rem;
        }
        
        .file-item i {
            font-size: 1.5rem;
            margin-right: 0.75rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .file-item i {
            margin-right: 0;
            margin-left: 0.75rem;
        }
        
        .file-item-info {
            flex: 1;
        }
        
        .file-item-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .file-item-size {
            font-size: 0.8rem;
            color: var(--gray-color);
        }
        
        .file-item-actions {
            display: flex;
            gap: 0.5rem;
        }
        
        .file-item-actions button {
            padding: 0.25rem 0.5rem;
            font-size: 0.8rem;
        }
        
        .nav-tabs .nav-link {
            border: none;
            border-bottom: 2px solid transparent;
            border-radius: 0;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            color: var(--text-color);
        }
        
        .nav-tabs .nav-link.active {
            border-bottom-color: var(--primary-color);
            color: var(--primary-color);
            background-color: transparent;
        }
        
        .nav-tabs .nav-link:hover {
            border-bottom-color: rgba(0, 48, 73, 0.5);
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="student_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="student_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-book"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم إضافة محتوى جديد في مقرر برمجة الويب</p>
                                    <small class="text-muted">منذ 10 دقائق</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-tasks"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تذكير: موعد تسليم واجب قواعد البيانات غداً</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-success text-white rounded-circle">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تصحيح واجب البرمجة المتقدمة</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user1.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. محمد أحمد</p>
                                    <small class="text-muted">هل لديك استفسارات حول المشروع النهائي؟</small>
                                    <small class="text-muted d-block">منذ 15 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user2.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">أ. سارة خالد</p>
                                    <small class="text-muted">تم تحديد موعد المراجعة النهائية للاختبار</small>
                                    <small class="text-muted d-block">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $student['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $student['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $student['name']; ?></h6>
                            <small><?php echo $student['student_id']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="student_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="student_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <div>
                <h1 class="h3"><?php echo t('assignments'); ?></h1>
                <p class="text-muted"><?php echo t('assignments_subtitle'); ?></p>
            </div>
            <div>
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="sortDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-sort me-1"></i> <?php echo t('sort_by'); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="sortDropdown">
                        <li><a class="dropdown-item" href="#" data-sort="due-date"><?php echo t('due_date'); ?></a></li>
                        <li><a class="dropdown-item" href="#" data-sort="course"><?php echo t('course'); ?></a></li>
                        <li><a class="dropdown-item" href="#" data-sort="title"><?php echo t('title'); ?></a></li>
                        <li><a class="dropdown-item" href="#" data-sort="status"><?php echo t('status'); ?></a></li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- البحث والتصفية -->
        <div class="row mb-4">
            <div class="col-md-8">
                <div class="assignment-search">
                    <i class="fas fa-search"></i>
                    <input type="text" class="form-control" id="assignmentSearch" placeholder="<?php echo t('search_assignments'); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <div class="d-flex justify-content-md-end">
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-filter me-1"></i> <?php echo t('filter_by_course'); ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="filterDropdown">
                            <li><a class="dropdown-item" href="#" data-filter="all"><?php echo t('all_courses'); ?></a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#" data-filter="CS101">CS101 - مقدمة في علوم الحاسب</a></li>
                            <li><a class="dropdown-item" href="#" data-filter="CS205">CS205 - برمجة الويب</a></li>
                            <li><a class="dropdown-item" href="#" data-filter="CS301">CS301 - قواعد البيانات</a></li>
                            <li><a class="dropdown-item" href="#" data-filter="CS401">CS401 - الذكاء الاصطناعي</a></li>
                            <li><a class="dropdown-item" href="#" data-filter="MATH201">MATH201 - الجبر الخطي</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- علامات التبويب -->
        <ul class="nav nav-tabs mb-4" id="assignmentTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="pending-tab" data-bs-toggle="tab" data-bs-target="#pending" type="button" role="tab" aria-controls="pending" aria-selected="true">
                    <?php echo t('pending_assignments'); ?> <span class="badge bg-primary ms-1"><?php echo count($pending_assignments); ?></span>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="submitted-tab" data-bs-toggle="tab" data-bs-target="#submitted" type="button" role="tab" aria-controls="submitted" aria-selected="false">
                    <?php echo t('submitted_assignments'); ?> <span class="badge bg-success ms-1"><?php echo count($submitted_assignments); ?></span>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="graded-tab" data-bs-toggle="tab" data-bs-target="#graded" type="button" role="tab" aria-controls="graded" aria-selected="false">
                    <?php echo t('graded_assignments'); ?> <span class="badge bg-info ms-1"><?php echo count($graded_assignments); ?></span>
                </button>
            </li>
        </ul>
        
        <!-- محتوى علامات التبويب -->
        <div class="tab-content" id="assignmentTabsContent">
            <!-- الواجبات المطلوبة -->
            <div class="tab-pane fade show active" id="pending" role="tabpanel" aria-labelledby="pending-tab">
                <?php if (count($pending_assignments) > 0): ?>
                    <div class="row" id="pendingAssignments">
                        <?php foreach ($pending_assignments as $assignment): ?>
                            <div class="col-lg-4 col-md-6 mb-4" data-course="<?php echo $assignment['course_code']; ?>">
                                <div class="assignment-card">
                                    <div class="assignment-header" style="background-color: <?php echo $assignment['course_color']; ?>">
                                        <span class="assignment-course"><?php echo $assignment['course_code']; ?></span>
                                        <h5 class="mb-1"><?php echo $assignment['title']; ?></h5>
                                        <p class="mb-0"><?php echo $assignment['course_name']; ?></p>
                                    </div>
                                    <div class="assignment-body">
                                        <div class="assignment-meta">
                                            <div class="assignment-meta-item">
                                                <i class="fas fa-calendar-alt"></i>
                                                <span><?php echo t('due_date'); ?>: <?php echo $assignment['due_date']; ?></span>
                                            </div>
                                            <div class="assignment-meta-item">
                                                <i class="fas fa-clock"></i>
                                                <span><?php echo t('time_left'); ?>: <?php echo $assignment['time_left']; ?></span>
                                            </div>
                                            <div class="assignment-meta-item">
                                                <i class="fas fa-star"></i>
                                                <span><?php echo t('points'); ?>: <?php echo $assignment['points']; ?></span>
                                            </div>
                                        </div>
                                        
                                        <p class="mb-3"><?php echo substr($assignment['description'], 0, 100); ?>...</p>
                                        
                                        <?php if ($assignment['status'] === 'in_progress'): ?>
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <small class="text-muted"><?php echo t('progress'); ?>:</small>
                                                <small class="text-muted"><?php echo $assignment['progress']; ?>%</small>
                                            </div>
                                            <div class="progress assignment-progress">
                                                <div class="progress-bar" role="progressbar" style="width: <?php echo $assignment['progress']; ?>%; background-color: <?php echo $assignment['course_color']; ?>" aria-valuenow="<?php echo $assignment['progress']; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="assignment-footer">
                                        <span class="badge bg-<?php echo $assignment['status_color']; ?>"><?php echo $assignment['status_text']; ?></span>
                                        <div class="assignment-actions">
                                            <a href="student_assignment_details.php?id=<?php echo $assignment['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye me-1"></i> <?php echo t('view'); ?>
                                            </a>
                                            <a href="student_assignment_submit.php?id=<?php echo $assignment['id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-upload me-1"></i> <?php echo t('submit'); ?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="assignment-empty">
                        <i class="fas fa-tasks"></i>
                        <h4><?php echo t('no_pending_assignments'); ?></h4>
                        <p><?php echo t('no_pending_assignments_message'); ?></p>
                        <a href="student_dashboard.php" class="btn btn-primary">
                            <i class="fas fa-home me-1"></i> <?php echo t('back_to_dashboard'); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- الواجبات المقدمة -->
            <div class="tab-pane fade" id="submitted" role="tabpanel" aria-labelledby="submitted-tab">
                <?php if (count($submitted_assignments) > 0): ?>
                    <div class="row" id="submittedAssignments">
                        <?php foreach ($submitted_assignments as $assignment): ?>
                            <div class="col-lg-4 col-md-6 mb-4" data-course="<?php echo $assignment['course_code']; ?>">
                                <div class="assignment-card">
                                    <div class="assignment-header" style="background-color: <?php echo $assignment['course_color']; ?>">
                                        <span class="assignment-course"><?php echo $assignment['course_code']; ?></span>
                                        <h5 class="mb-1"><?php echo $assignment['title']; ?></h5>
                                        <p class="mb-0"><?php echo $assignment['course_name']; ?></p>
                                    </div>
                                    <div class="assignment-body">
                                        <div class="assignment-meta">
                                            <div class="assignment-meta-item">
                                                <i class="fas fa-calendar-alt"></i>
                                                <span><?php echo t('due_date'); ?>: <?php echo $assignment['due_date']; ?></span>
                                            </div>
                                            <div class="assignment-meta-item">
                                                <i class="fas fa-calendar-check"></i>
                                                <span><?php echo t('submitted_date'); ?>: <?php echo $assignment['submitted_date']; ?></span>
                                            </div>
                                            <div class="assignment-meta-item">
                                                <i class="fas fa-star"></i>
                                                <span><?php echo t('points'); ?>: <?php echo $assignment['points']; ?></span>
                                            </div>
                                        </div>
                                        
                                        <p class="mb-3"><?php echo substr($assignment['description'], 0, 100); ?>...</p>
                                        
                                        <div class="file-item">
                                            <i class="fas fa-file-<?php echo $assignment['file_icon']; ?>"></i>
                                            <div class="file-item-info">
                                                <div class="file-item-name"><?php echo $assignment['file_name']; ?></div>
                                                <div class="file-item-size"><?php echo $assignment['file_size']; ?></div>
                                            </div>
                                            <div class="file-item-actions">
                                                <a href="<?php echo $assignment['file_url']; ?>" class="btn btn-sm btn-outline-primary" download>
                                                    <i class="fas fa-download"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="assignment-footer">
                                        <span class="badge bg-<?php echo $assignment['status_color']; ?>"><?php echo $assignment['status_text']; ?></span>
                                        <div class="assignment-actions">
                                            <a href="student_assignment_details.php?id=<?php echo $assignment['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye me-1"></i> <?php echo t('view'); ?>
                                            </a>
                                            <a href="student_assignment_submit.php?id=<?php echo $assignment['id']; ?>&edit=1" class="btn btn-sm btn-warning">
                                                <i class="fas fa-edit me-1"></i> <?php echo t('edit'); ?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="assignment-empty">
                        <i class="fas fa-upload"></i>
                        <h4><?php echo t('no_submitted_assignments'); ?></h4>
                        <p><?php echo t('no_submitted_assignments_message'); ?></p>
                        <a href="#pending" class="btn btn-primary" data-bs-toggle="tab" data-bs-target="#pending">
                            <i class="fas fa-tasks me-1"></i> <?php echo t('view_pending_assignments'); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- الواجبات المصححة -->
            <div class="tab-pane fade" id="graded" role="tabpanel" aria-labelledby="graded-tab">
                <?php if (count($graded_assignments) > 0): ?>
                    <div class="row" id="gradedAssignments">
                        <?php foreach ($graded_assignments as $assignment): ?>
                            <div class="col-lg-4 col-md-6 mb-4" data-course="<?php echo $assignment['course_code']; ?>">
                                <div class="assignment-card">
                                    <div class="assignment-header" style="background-color: <?php echo $assignment['course_color']; ?>">
                                        <span class="assignment-course"><?php echo $assignment['course_code']; ?></span>
                                        <h5 class="mb-1"><?php echo $assignment['title']; ?></h5>
                                        <p class="mb-0"><?php echo $assignment['course_name']; ?></p>
                                    </div>
                                    <div class="assignment-body">
                                        <div class="assignment-meta">
                                            <div class="assignment-meta-item">
                                                <i class="fas fa-calendar-check"></i>
                                                <span><?php echo t('submitted_date'); ?>: <?php echo $assignment['submitted_date']; ?></span>
                                            </div>
                                            <div class="assignment-meta-item">
                                                <i class="fas fa-calendar-alt"></i>
                                                <span><?php echo t('graded_date'); ?>: <?php echo $assignment['graded_date']; ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <h5 class="mb-0"><?php echo t('grade'); ?>:</h5>
                                            <h5 class="mb-0 text-<?php echo $assignment['grade_color']; ?>"><?php echo $assignment['grade']; ?> / <?php echo $assignment['points']; ?></h5>
                                        </div>
                                        
                                        <div class="card mb-3">
                                            <div class="card-header">
                                                <h6 class="mb-0"><?php echo t('instructor_feedback'); ?></h6>
                                            </div>
                                            <div class="card-body">
                                                <p class="mb-0"><?php echo $assignment['feedback']; ?></p>
                                            </div>
                                        </div>
                                        
                                        <div class="file-item">
                                            <i class="fas fa-file-<?php echo $assignment['file_icon']; ?>"></i>
                                            <div class="file-item-info">
                                                <div class="file-item-name"><?php echo $assignment['file_name']; ?></div>
                                                <div class="file-item-size"><?php echo $assignment['file_size']; ?></div>
                                            </div>
                                            <div class="file-item-actions">
                                                <a href="<?php echo $assignment['file_url']; ?>" class="btn btn-sm btn-outline-primary" download>
                                                    <i class="fas fa-download"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="assignment-footer">
                                        <span class="badge bg-<?php echo $assignment['status_color']; ?>"><?php echo $assignment['status_text']; ?></span>
                                        <div class="assignment-actions">
                                            <a href="student_assignment_details.php?id=<?php echo $assignment['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-eye me-1"></i> <?php echo t('view'); ?>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="assignment-empty">
                        <i class="fas fa-check-circle"></i>
                        <h4><?php echo t('no_graded_assignments'); ?></h4>
                        <p><?php echo t('no_graded_assignments_message'); ?></p>
                        <a href="#pending" class="btn btn-primary" data-bs-toggle="tab" data-bs-target="#pending">
                            <i class="fas fa-tasks me-1"></i> <?php echo t('view_pending_assignments'); ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // البحث في الواجبات
            const searchInput = document.getElementById('assignmentSearch');
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                
                // البحث في الواجبات المطلوبة
                const pendingAssignments = document.querySelectorAll('#pendingAssignments .assignment-card');
                pendingAssignments.forEach(assignment => {
                    const assignmentTitle = assignment.querySelector('h5').textContent.toLowerCase();
                    const assignmentCourse = assignment.querySelector('.assignment-course').textContent.toLowerCase();
                    const assignmentDescription = assignment.querySelector('p:nth-of-type(2)').textContent.toLowerCase();
                    
                    if (assignmentTitle.includes(searchTerm) || assignmentCourse.includes(searchTerm) || assignmentDescription.includes(searchTerm)) {
                        assignment.closest('.col-lg-4').style.display = 'block';
                    } else {
                        assignment.closest('.col-lg-4').style.display = 'none';
                    }
                });
                
                // البحث في الواجبات المقدمة
                const submittedAssignments = document.querySelectorAll('#submittedAssignments .assignment-card');
                submittedAssignments.forEach(assignment => {
                    const assignmentTitle = assignment.querySelector('h5').textContent.toLowerCase();
                    const assignmentCourse = assignment.querySelector('.assignment-course').textContent.toLowerCase();
                    const assignmentDescription = assignment.querySelector('p:nth-of-type(2)').textContent.toLowerCase();
                    
                    if (assignmentTitle.includes(searchTerm) || assignmentCourse.includes(searchTerm) || assignmentDescription.includes(searchTerm)) {
                        assignment.closest('.col-lg-4').style.display = 'block';
                    } else {
                        assignment.closest('.col-lg-4').style.display = 'none';
                    }
                });
                
                // البحث في الواجبات المصححة
                const gradedAssignments = document.querySelectorAll('#gradedAssignments .assignment-card');
                gradedAssignments.forEach(assignment => {
                    const assignmentTitle = assignment.querySelector('h5').textContent.toLowerCase();
                    const assignmentCourse = assignment.querySelector('.assignment-course').textContent.toLowerCase();
                    
                    if (assignmentTitle.includes(searchTerm) || assignmentCourse.includes(searchTerm)) {
                        assignment.closest('.col-lg-4').style.display = 'block';
                    } else {
                        assignment.closest('.col-lg-4').style.display = 'none';
                    }
                });
            });
            
            // تصفية الواجبات حسب المقرر
            const filterLinks = document.querySelectorAll('[data-filter]');
            filterLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // الحصول على فئة التصفية
                    const filter = this.getAttribute('data-filter');
                    
                    // تصفية الواجبات المطلوبة
                    const pendingAssignments = document.querySelectorAll('#pendingAssignments > div');
                    pendingAssignments.forEach(assignment => {
                        if (filter === 'all' || assignment.getAttribute('data-course') === filter) {
                            assignment.style.display = 'block';
                        } else {
                            assignment.style.display = 'none';
                        }
                    });
                    
                    // تصفية الواجبات المقدمة
                    const submittedAssignments = document.querySelectorAll('#submittedAssignments > div');
                    submittedAssignments.forEach(assignment => {
                        if (filter === 'all' || assignment.getAttribute('data-course') === filter) {
                            assignment.style.display = 'block';
                        } else {
                            assignment.style.display = 'none';
                        }
                    });
                    
                    // تصفية الواجبات المصححة
                    const gradedAssignments = document.querySelectorAll('#gradedAssignments > div');
                    gradedAssignments.forEach(assignment => {
                        if (filter === 'all' || assignment.getAttribute('data-course') === filter) {
                            assignment.style.display = 'block';
                        } else {
                            assignment.style.display = 'none';
                        }
                    });
                    
                    // تحديث نص زر التصفية
                    document.getElementById('filterDropdown').innerHTML = `<i class="fas fa-filter me-1"></i> ${this.textContent}`;
                });
            });
            
            // ترتيب الواجبات
            const sortLinks = document.querySelectorAll('[data-sort]');
            sortLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // الحصول على نوع الترتيب
                    const sortType = this.getAttribute('data-sort');
                    
                    // ترتيب الواجبات المطلوبة
                    const pendingAssignments = Array.from(document.querySelectorAll('#pendingAssignments > div'));
                    pendingAssignments.sort((a, b) => {
                        let valueA, valueB;
                        
                        switch (sortType) {
                            case 'due-date':
                                valueA = a.querySelector('.assignment-meta-item:first-child span').textContent;
                                valueB = b.querySelector('.assignment-meta-item:first-child span').textContent;
                                return valueA.localeCompare(valueB);
                            
                            case 'course':
                                valueA = a.querySelector('.assignment-course').textContent;
                                valueB = b.querySelector('.assignment-course').textContent;
                                return valueA.localeCompare(valueB);
                            
                            case 'title':
                                valueA = a.querySelector('h5').textContent;
                                valueB = b.querySelector('h5').textContent;
                                return valueA.localeCompare(valueB);
                            
                            case 'status':
                                valueA = a.querySelector('.badge').textContent;
                                valueB = b.querySelector('.badge').textContent;
                                return valueA.localeCompare(valueB);
                            
                            default:
                                return 0;
                        }
                    });
                    
                    // إعادة ترتيب العناصر في DOM
                    const pendingAssignmentsContainer = document.getElementById('pendingAssignments');
                    pendingAssignments.forEach(assignment => {
                        pendingAssignmentsContainer.appendChild(assignment);
                    });
                    
                    // ترتيب الواجبات المقدمة
                    const submittedAssignments = Array.from(document.querySelectorAll('#submittedAssignments > div'));
                    submittedAssignments.sort((a, b) => {
                        let valueA, valueB;
                        
                        switch (sortType) {
                            case 'due-date':
                                valueA = a.querySelector('.assignment-meta-item:first-child span').textContent;
                                valueB = b.querySelector('.assignment-meta-item:first-child span').textContent;
                                return valueA.localeCompare(valueB);
                            
                            case 'course':
                                valueA = a.querySelector('.assignment-course').textContent;
                                valueB = b.querySelector('.assignment-course').textContent;
                                return valueA.localeCompare(valueB);
                            
                            case 'title':
                                valueA = a.querySelector('h5').textContent;
                                valueB = b.querySelector('h5').textContent;
                                return valueA.localeCompare(valueB);
                            
                            case 'status':
                                valueA = a.querySelector('.badge').textContent;
                                valueB = b.querySelector('.badge').textContent;
                                return valueA.localeCompare(valueB);
                            
                            default:
                                return 0;
                        }
                    });
                    
                    // إعادة ترتيب العناصر في DOM
                    const submittedAssignmentsContainer = document.getElementById('submittedAssignments');
                    submittedAssignments.forEach(assignment => {
                        submittedAssignmentsContainer.appendChild(assignment);
                    });
                    
                    // ترتيب الواجبات المصححة
                    const gradedAssignments = Array.from(document.querySelectorAll('#gradedAssignments > div'));
                    gradedAssignments.sort((a, b) => {
                        let valueA, valueB;
                        
                        switch (sortType) {
                            case 'due-date':
                                valueA = a.querySelector('.assignment-meta-item:first-child span').textContent;
                                valueB = b.querySelector('.assignment-meta-item:first-child span').textContent;
                                return valueA.localeCompare(valueB);
                            
                            case 'course':
                                valueA = a.querySelector('.assignment-course').textContent;
                                valueB = b.querySelector('.assignment-course').textContent;
                                return valueA.localeCompare(valueB);
                            
                            case 'title':
                                valueA = a.querySelector('h5').textContent;
                                valueB = b.querySelector('h5').textContent;
                                return valueA.localeCompare(valueB);
                            
                            case 'status':
                                valueA = a.querySelector('.badge').textContent;
                                valueB = b.querySelector('.badge').textContent;
                                return valueA.localeCompare(valueB);
                            
                            default:
                                return 0;
                        }
                    });
                    
                    // إعادة ترتيب العناصر في DOM
                    const gradedAssignmentsContainer = document.getElementById('gradedAssignments');
                    gradedAssignments.forEach(assignment => {
                        gradedAssignmentsContainer.appendChild(assignment);
                    });
                    
                    // تحديث نص زر الترتيب
                    document.getElementById('sortDropdown').innerHTML = `<i class="fas fa-sort me-1"></i> ${this.textContent}`;
                });
            });
        });
    </script>
</body>
</html>
