<?php
/**
 * ملف الإعدادات الرئيسي لنظام UniverBoard
 * يحتوي على إعدادات الاتصال بقاعدة البيانات والثوابت العامة للنظام
 */

// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'univerboard');
define('DB_CHARSET', 'utf8mb4');

// إعدادات المسارات
define('BASE_URL', 'http://localhost/univerboard_web');
define('ROOT_PATH', dirname(__DIR__));
define('UPLOADS_PATH', ROOT_PATH . '/uploads');
define('PROFILE_PICTURES_PATH', UPLOADS_PATH . '/profile_pictures');
define('COURSE_MATERIALS_PATH', UPLOADS_PATH . '/course_materials');
define('ASSIGNMENTS_PATH', UPLOADS_PATH . '/assignments');

// إعدادات الجلسة
define('SESSION_NAME', 'univerboard_session');
define('SESSION_LIFETIME', 86400); // 24 ساعة

// إعدادات الأمان
define('HASH_COST', 12); // تكلفة تشفير كلمة المرور
define('JWT_SECRET', 'univerboard_secret_key'); // مفتاح JWT (يجب تغييره في الإنتاج)
define('JWT_EXPIRY', 3600); // مدة صلاحية JWT بالثواني (ساعة واحدة)

// إعدادات Firebase (يجب تحديثها بمعلومات المشروع الفعلية)
define('FIREBASE_API_KEY', 'YOUR_API_KEY');
define('FIREBASE_AUTH_DOMAIN', 'YOUR_PROJECT_ID.firebaseapp.com');
define('FIREBASE_PROJECT_ID', 'YOUR_PROJECT_ID');
define('FIREBASE_STORAGE_BUCKET', 'YOUR_PROJECT_ID.appspot.com');
define('FIREBASE_MESSAGING_SENDER_ID', 'YOUR_MESSAGING_SENDER_ID');
define('FIREBASE_APP_ID', 'YOUR_APP_ID');

// إعدادات عامة
define('SITE_NAME', 'UniverBoard');
define('SITE_DESCRIPTION', 'نظام تعليمي متكامل للجامعات والكليات');
define('SITE_LANG', 'ar'); // اللغة الافتراضية
define('SITE_THEME', 'light'); // المظهر الافتراضي
define('SITE_VERSION', '1.0.0');

// إعدادات البريد الإلكتروني
define('MAIL_HOST', 'smtp.example.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'noreply@example.com');
define('MAIL_PASSWORD', 'your_password');
define('MAIL_FROM_NAME', 'UniverBoard');

// دالة الاتصال بقاعدة البيانات
function getDbConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (PDOException $e) {
        // في بيئة الإنتاج، يجب تسجيل الخطأ بدلاً من عرضه
        die("خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage());
    }
}
