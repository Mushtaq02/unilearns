<?php
/**
 * صفحة الملف الشخصي للمعلم في نظام UniverBoard
 * تتيح للمعلم عرض وتعديل معلوماته الشخصية
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول المعلم
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'teacher') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات المعلم
$teacher_id = $_SESSION['user_id'];
$db = get_db_connection();
$teacher = get_teacher_info($db, $teacher_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// معالجة تحديث الملف الشخصي
if (isset($_POST['update_profile'])) {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
    $bio = filter_input(INPUT_POST, 'bio', FILTER_SANITIZE_STRING);
    $office_hours = filter_input(INPUT_POST, 'office_hours', FILTER_SANITIZE_STRING);
    $office_location = filter_input(INPUT_POST, 'office_location', FILTER_SANITIZE_STRING);
    
    // التحقق من صحة البيانات
    if (!empty($name) && !empty($email)) {
        // تحديث معلومات المعلم
        $result = update_teacher_profile($db, $teacher_id, $name, $email, $phone, $title, $bio, $office_hours, $office_location);
        
        if ($result) {
            $success_message = t('profile_updated_successfully');
            // تحديث معلومات المعلم
            $teacher = get_teacher_info($db, $teacher_id);
        } else {
            $error_message = t('failed_to_update_profile');
        }
    } else {
        $error_message = t('name_and_email_required');
    }
}

// معالجة تحديث صورة الملف الشخصي
if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    $max_size = 2 * 1024 * 1024; // 2 ميجابايت
    
    if (in_array($_FILES['profile_image']['type'], $allowed_types) && $_FILES['profile_image']['size'] <= $max_size) {
        $upload_dir = 'uploads/profile_images/';
        
        // إنشاء مجلد التحميل إذا لم يكن موجودًا
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_name = $teacher_id . '_' . time() . '_' . basename($_FILES['profile_image']['name']);
        $upload_path = $upload_dir . $file_name;
        
        if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $upload_path)) {
            // تحديث مسار الصورة في قاعدة البيانات
            $result = update_teacher_profile_image($db, $teacher_id, $upload_path);
            
            if ($result) {
                $success_message = t('profile_image_updated_successfully');
                // تحديث معلومات المعلم
                $teacher = get_teacher_info($db, $teacher_id);
            } else {
                $error_message = t('failed_to_update_profile_image');
            }
        } else {
            $error_message = t('failed_to_upload_image');
        }
    } else {
        $error_message = t('invalid_image_format_or_size');
    }
}

// معالجة تغيير كلمة المرور
if (isset($_POST['change_password'])) {
    $current_password = filter_input(INPUT_POST, 'current_password', FILTER_SANITIZE_STRING);
    $new_password = filter_input(INPUT_POST, 'new_password', FILTER_SANITIZE_STRING);
    $confirm_password = filter_input(INPUT_POST, 'confirm_password', FILTER_SANITIZE_STRING);
    
    // التحقق من صحة البيانات
    if (!empty($current_password) && !empty($new_password) && !empty($confirm_password)) {
        if ($new_password === $confirm_password) {
            // التحقق من كلمة المرور الحالية
            $result = verify_password($db, $teacher_id, $current_password);
            
            if ($result) {
                // تحديث كلمة المرور
                $result = update_password($db, $teacher_id, $new_password);
                
                if ($result) {
                    $success_message = t('password_updated_successfully');
                } else {
                    $error_message = t('failed_to_update_password');
                }
            } else {
                $error_message = t('current_password_incorrect');
            }
        } else {
            $error_message = t('passwords_do_not_match');
        }
    } else {
        $error_message = t('all_password_fields_required');
    }
}

// الحصول على المقررات التي يدرسها المعلم
$courses = get_teacher_courses($db, $teacher_id);

// الحصول على المنشورات العلمية للمعلم
$publications = get_teacher_publications($db, $teacher_id);

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('profile'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .profile-header {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            margin-bottom: 2rem;
            position: relative;
        }
        
        .theme-dark .profile-header {
            background-color: var(--dark-bg);
        }
        
        .profile-cover {
            height: 200px;
            background-color: var(--primary-color);
            background-image: linear-gradient(135deg, #003049 0%, #669bbc 100%);
            border-radius: 0.5rem;
            margin-bottom: 4rem;
            position: relative;
        }
        
        .profile-avatar {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 5px solid white;
            position: absolute;
            bottom: -75px;
            left: 50%;
            transform: translateX(-50%);
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .profile-avatar {
            border-color: var(--dark-bg);
        }
        
        .profile-info {
            text-align: center;
            margin-top: 1rem;
        }
        
        .profile-name {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .profile-title {
            color: var(--gray-color);
            margin-bottom: 1rem;
        }
        
        .profile-stats {
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin-top: 1.5rem;
        }
        
        .profile-stat {
            text-align: center;
        }
        
        .profile-stat-value {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .profile-stat-label {
            font-size: 0.85rem;
            color: var(--gray-color);
        }
        
        .profile-actions {
            margin-top: 1.5rem;
            display: flex;
            justify-content: center;
            gap: 1rem;
        }
        
        .profile-content {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .theme-dark .profile-content {
            background-color: var(--dark-bg);
        }
        
        .profile-tabs {
            display: flex;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .profile-tabs {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .profile-tab {
            padding: 1rem 1.5rem;
            cursor: pointer;
            transition: all 0.2s ease;
            font-weight: 500;
            color: var(--gray-color);
            border-bottom: 3px solid transparent;
        }
        
        .profile-tab:hover {
            color: var(--text-color);
        }
        
        .profile-tab.active {
            color: var(--primary-color);
            border-bottom-color: var(--primary-color);
        }
        
        .profile-tab-content {
            padding: 2rem;
            display: none;
        }
        
        .profile-tab-content.active {
            display: block;
        }
        
        .profile-section {
            margin-bottom: 2rem;
        }
        
        .profile-section:last-child {
            margin-bottom: 0;
        }
        
        .profile-section-title {
            font-weight: 600;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .profile-section-title {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .profile-bio {
            margin-bottom: 1.5rem;
            line-height: 1.6;
        }
        
        .profile-info-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .profile-info-item {
            display: flex;
            margin-bottom: 1rem;
        }
        
        .profile-info-item:last-child {
            margin-bottom: 0;
        }
        
        .profile-info-label {
            font-weight: 500;
            width: 150px;
            flex-shrink: 0;
        }
        
        .profile-info-value {
            color: var(--gray-color);
        }
        
        .profile-courses {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 1.5rem;
        }
        
        .profile-course {
            background-color: rgba(0, 0, 0, 0.02);
            border-radius: 0.5rem;
            padding: 1.5rem;
            transition: all 0.2s ease;
        }
        
        .theme-dark .profile-course {
            background-color: rgba(255, 255, 255, 0.02);
        }
        
        .profile-course:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .profile-course:hover {
            box-shadow: 0 5px 15px rgba(255, 255, 255, 0.05);
        }
        
        .profile-course-name {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .profile-course-code {
            font-size: 0.85rem;
            color: var(--gray-color);
            margin-bottom: 1rem;
        }
        
        .profile-course-details {
            font-size: 0.85rem;
            color: var(--gray-color);
        }
        
        .profile-course-detail {
            display: flex;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        
        .profile-course-detail:last-child {
            margin-bottom: 0;
        }
        
        .profile-course-detail i {
            margin-right: 0.5rem;
            width: 16px;
            text-align: center;
            opacity: 0.7;
        }
        
        [dir="rtl"] .profile-course-detail i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .profile-publications {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .profile-publication {
            margin-bottom: 1.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .profile-publication {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .profile-publication:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }
        
        .profile-publication-title {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .profile-publication-authors {
            font-size: 0.85rem;
            color: var(--gray-color);
            margin-bottom: 0.5rem;
        }
        
        .profile-publication-journal {
            font-size: 0.85rem;
            font-style: italic;
            margin-bottom: 0.5rem;
        }
        
        .profile-publication-year {
            font-size: 0.85rem;
            color: var(--gray-color);
        }
        
        .profile-form-group {
            margin-bottom: 1.5rem;
        }
        
        .profile-form-label {
            font-weight: 500;
            margin-bottom: 0.5rem;
        }
        
        .profile-form-input {
            width: 100%;
            padding: 0.75rem;
            border-radius: 0.5rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .profile-form-input {
            border-color: rgba(255, 255, 255, 0.1);
            background-color: var(--dark-bg);
            color: white;
        }
        
        .profile-form-input:focus {
            outline: none;
            border-color: var(--primary-color);
        }
        
        .profile-form-textarea {
            width: 100%;
            padding: 0.75rem;
            border-radius: 0.5rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
            min-height: 100px;
        }
        
        .theme-dark .profile-form-textarea {
            border-color: rgba(255, 255, 255, 0.1);
            background-color: var(--dark-bg);
            color: white;
        }
        
        .profile-form-textarea:focus {
            outline: none;
            border-color: var(--primary-color);
        }
        
        .profile-form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 1rem;
        }
        
        .profile-image-upload {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 2rem;
        }
        
        .profile-image-preview {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 1rem;
            border: 5px solid white;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .profile-image-preview {
            border-color: var(--dark-bg);
        }
        
        .profile-image-upload-btn {
            position: relative;
            overflow: hidden;
        }
        
        .profile-image-upload-btn input[type="file"] {
            position: absolute;
            top: 0;
            right: 0;
            min-width: 100%;
            min-height: 100%;
            font-size: 100px;
            text-align: right;
            filter: alpha(opacity=0);
            opacity: 0;
            outline: none;
            cursor: pointer;
            display: block;
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="teacher_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_students.php">
                        <i class="fas fa-user-graduate"></i> <?php echo t('students'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="teacher_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link active" href="teacher_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-user-graduate"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">قام الطالب أحمد محمد بتسليم واجب جديد</p>
                                    <small class="text-muted">منذ 10 دقائق</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-calendar-alt"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تذكير: موعد محاضرة برمجة الويب غداً</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-info text-white rounded-circle">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">رسالة جديدة من رئيس القسم</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="teacher_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/student1.jpg" alt="Student" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">سارة أحمد</p>
                                    <small class="text-muted">هل يمكنني الحصول على مساعدة في المشروع النهائي؟</small>
                                    <small class="text-muted d-block">منذ 15 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/student2.jpg" alt="Student" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">محمد علي</p>
                                    <small class="text-muted">أستاذ، هل يمكنني تأجيل موعد تسليم الواجب؟</small>
                                    <small class="text-muted d-block">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="teacher_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $teacher['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $teacher['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $teacher['name']; ?></h6>
                            <small><?php echo $teacher['title']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="teacher_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="teacher_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- رسائل النجاح والخطأ -->
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success alert-dismissible fade show mt-4" role="alert">
                <?php echo $success_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger alert-dismissible fade show mt-4" role="alert">
                <?php echo $error_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <!-- رأس الملف الشخصي -->
        <div class="profile-header">
            <div class="profile-cover"></div>
            <img src="<?php echo $teacher['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $teacher['name']; ?>" class="profile-avatar">
            <div class="profile-info">
                <h1 class="profile-name"><?php echo $teacher['name']; ?></h1>
                <div class="profile-title"><?php echo $teacher['title']; ?></div>
                <div class="profile-stats">
                    <div class="profile-stat">
                        <div class="profile-stat-value"><?php echo count($courses); ?></div>
                        <div class="profile-stat-label"><?php echo t('courses'); ?></div>
                    </div>
                    <div class="profile-stat">
                        <div class="profile-stat-value"><?php echo count($publications); ?></div>
                        <div class="profile-stat-label"><?php echo t('publications'); ?></div>
                    </div>
                    <div class="profile-stat">
                        <div class="profile-stat-value"><?php echo $teacher['students_count'] ?: 0; ?></div>
                        <div class="profile-stat-label"><?php echo t('students'); ?></div>
                    </div>
                </div>
                <div class="profile-actions">
                    <a href="teacher_settings.php" class="btn btn-outline-primary">
                        <i class="fas fa-cog me-1"></i> <?php echo t('settings'); ?>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- محتوى الملف الشخصي -->
        <div class="profile-content">
            <div class="profile-tabs">
                <div class="profile-tab active" data-tab="about"><?php echo t('about'); ?></div>
                <div class="profile-tab" data-tab="courses"><?php echo t('courses'); ?></div>
                <div class="profile-tab" data-tab="publications"><?php echo t('publications'); ?></div>
                <div class="profile-tab" data-tab="edit"><?php echo t('edit_profile'); ?></div>
            </div>
            
            <!-- علامة التبويب: نبذة عني -->
            <div class="profile-tab-content active" id="aboutTab">
                <div class="profile-section">
                    <h3 class="profile-section-title"><?php echo t('bio'); ?></h3>
                    <div class="profile-bio">
                        <?php echo $teacher['bio'] ?: t('no_bio_provided'); ?>
                    </div>
                </div>
                
                <div class="profile-section">
                    <h3 class="profile-section-title"><?php echo t('contact_information'); ?></h3>
                    <ul class="profile-info-list">
                        <li class="profile-info-item">
                            <div class="profile-info-label"><?php echo t('email'); ?>:</div>
                            <div class="profile-info-value"><?php echo $teacher['email']; ?></div>
                        </li>
                        <li class="profile-info-item">
                            <div class="profile-info-label"><?php echo t('phone'); ?>:</div>
                            <div class="profile-info-value"><?php echo $teacher['phone'] ?: t('not_provided'); ?></div>
                        </li>
                        <li class="profile-info-item">
                            <div class="profile-info-label"><?php echo t('office_hours'); ?>:</div>
                            <div class="profile-info-value"><?php echo $teacher['office_hours'] ?: t('not_provided'); ?></div>
                        </li>
                        <li class="profile-info-item">
                            <div class="profile-info-label"><?php echo t('office_location'); ?>:</div>
                            <div class="profile-info-value"><?php echo $teacher['office_location'] ?: t('not_provided'); ?></div>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- علامة التبويب: المقررات -->
            <div class="profile-tab-content" id="coursesTab">
                <div class="profile-section">
                    <h3 class="profile-section-title"><?php echo t('my_courses'); ?></h3>
                    <?php if (count($courses) > 0): ?>
                        <div class="profile-courses">
                            <?php foreach ($courses as $course): ?>
                                <div class="profile-course">
                                    <div class="profile-course-name"><?php echo $course['name']; ?></div>
                                    <div class="profile-course-code"><?php echo $course['code']; ?></div>
                                    <div class="profile-course-details">
                                        <div class="profile-course-detail">
                                            <i class="fas fa-users"></i> <?php echo $course['students_count']; ?> <?php echo t('students'); ?>
                                        </div>
                                        <div class="profile-course-detail">
                                            <i class="fas fa-clock"></i> <?php echo $course['credit_hours']; ?> <?php echo t('credit_hours'); ?>
                                        </div>
                                        <div class="profile-course-detail">
                                            <i class="fas fa-calendar-alt"></i> <?php echo $course['semester']; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <?php echo t('no_courses_assigned'); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- علامة التبويب: المنشورات العلمية -->
            <div class="profile-tab-content" id="publicationsTab">
                <div class="profile-section">
                    <h3 class="profile-section-title"><?php echo t('publications'); ?></h3>
                    <?php if (count($publications) > 0): ?>
                        <ul class="profile-publications">
                            <?php foreach ($publications as $publication): ?>
                                <li class="profile-publication">
                                    <div class="profile-publication-title"><?php echo $publication['title']; ?></div>
                                    <div class="profile-publication-authors"><?php echo $publication['authors']; ?></div>
                                    <div class="profile-publication-journal"><?php echo $publication['journal']; ?></div>
                                    <div class="profile-publication-year"><?php echo $publication['year']; ?></div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <?php echo t('no_publications_found'); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- علامة التبويب: تعديل الملف الشخصي -->
            <div class="profile-tab-content" id="editTab">
                <div class="profile-section">
                    <h3 class="profile-section-title"><?php echo t('profile_image'); ?></h3>
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="profile-image-upload">
                            <img src="<?php echo $teacher['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $teacher['name']; ?>" class="profile-image-preview" id="profileImagePreview">
                            <div class="profile-image-upload-btn">
                                <button type="button" class="btn btn-outline-primary">
                                    <i class="fas fa-camera me-1"></i> <?php echo t('change_profile_image'); ?>
                                </button>
                                <input type="file" name="profile_image" id="profileImageInput" accept="image/*">
                            </div>
                        </div>
                        <div class="profile-form-actions">
                            <button type="submit" class="btn btn-primary"><?php echo t('upload_image'); ?></button>
                        </div>
                    </form>
                </div>
                
                <div class="profile-section">
                    <h3 class="profile-section-title"><?php echo t('personal_information'); ?></h3>
                    <form action="" method="post">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="profile-form-group">
                                    <label for="name" class="profile-form-label"><?php echo t('full_name'); ?>:</label>
                                    <input type="text" name="name" id="name" class="profile-form-input" value="<?php echo $teacher['name']; ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="profile-form-group">
                                    <label for="email" class="profile-form-label"><?php echo t('email'); ?>:</label>
                                    <input type="email" name="email" id="email" class="profile-form-input" value="<?php echo $teacher['email']; ?>" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="profile-form-group">
                                    <label for="phone" class="profile-form-label"><?php echo t('phone'); ?>:</label>
                                    <input type="tel" name="phone" id="phone" class="profile-form-input" value="<?php echo $teacher['phone']; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="profile-form-group">
                                    <label for="title" class="profile-form-label"><?php echo t('title'); ?>:</label>
                                    <input type="text" name="title" id="title" class="profile-form-input" value="<?php echo $teacher['title']; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="profile-form-group">
                            <label for="bio" class="profile-form-label"><?php echo t('bio'); ?>:</label>
                            <textarea name="bio" id="bio" class="profile-form-textarea" rows="5"><?php echo $teacher['bio']; ?></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="profile-form-group">
                                    <label for="office_hours" class="profile-form-label"><?php echo t('office_hours'); ?>:</label>
                                    <input type="text" name="office_hours" id="office_hours" class="profile-form-input" value="<?php echo $teacher['office_hours']; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="profile-form-group">
                                    <label for="office_location" class="profile-form-label"><?php echo t('office_location'); ?>:</label>
                                    <input type="text" name="office_location" id="office_location" class="profile-form-input" value="<?php echo $teacher['office_location']; ?>">
                                </div>
                            </div>
                        </div>
                        <div class="profile-form-actions">
                            <button type="submit" name="update_profile" class="btn btn-primary"><?php echo t('save_changes'); ?></button>
                        </div>
                    </form>
                </div>
                
                <div class="profile-section">
                    <h3 class="profile-section-title"><?php echo t('change_password'); ?></h3>
                    <form action="" method="post">
                        <div class="profile-form-group">
                            <label for="current_password" class="profile-form-label"><?php echo t('current_password'); ?>:</label>
                            <input type="password" name="current_password" id="current_password" class="profile-form-input" required>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="profile-form-group">
                                    <label for="new_password" class="profile-form-label"><?php echo t('new_password'); ?>:</label>
                                    <input type="password" name="new_password" id="new_password" class="profile-form-input" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="profile-form-group">
                                    <label for="confirm_password" class="profile-form-label"><?php echo t('confirm_password'); ?>:</label>
                                    <input type="password" name="confirm_password" id="confirm_password" class="profile-form-input" required>
                                </div>
                            </div>
                        </div>
                        <div class="profile-form-actions">
                            <button type="submit" name="change_password" class="btn btn-primary"><?php echo t('change_password'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // زر تبديل المظهر
            document.getElementById('themeToggle').addEventListener('click', function() {
                const currentTheme = document.body.className.includes('theme-dark') ? 'dark' : 'light';
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.cookie = `theme=${newTheme}; path=/; max-age=31536000`;
                document.body.className = `theme-${newTheme}`;
                
                this.innerHTML = `<i class="fas fa-${newTheme === 'dark' ? 'sun' : 'moon'}"></i>`;
            });
            
            // تبديل علامات التبويب
            const profileTabs = document.querySelectorAll('.profile-tab');
            const profileTabContents = document.querySelectorAll('.profile-tab-content');
            
            profileTabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    // إزالة الفئة النشطة من جميع علامات التبويب
                    profileTabs.forEach(t => t.classList.remove('active'));
                    
                    // إضافة الفئة النشطة إلى علامة التبويب المحددة
                    this.classList.add('active');
                    
                    // إخفاء جميع محتويات علامات التبويب
                    profileTabContents.forEach(content => content.classList.remove('active'));
                    
                    // إظهار محتوى علامة التبويب المناسبة
                    const tabName = this.getAttribute('data-tab');
                    document.getElementById(`${tabName}Tab`).classList.add('active');
                });
            });
            
            // معاينة صورة الملف الشخصي قبل التحميل
            const profileImageInput = document.getElementById('profileImageInput');
            const profileImagePreview = document.getElementById('profileImagePreview');
            
            profileImageInput.addEventListener('change', function() {
                if (this.files && this.files[0]) {
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        profileImagePreview.src = e.target.result;
                    };
                    
                    reader.readAsDataURL(this.files[0]);
                }
            });
            
            // التحقق من تطابق كلمة المرور
            const newPasswordInput = document.getElementById('new_password');
            const confirmPasswordInput = document.getElementById('confirm_password');
            
            confirmPasswordInput.addEventListener('input', function() {
                if (newPasswordInput.value !== this.value) {
                    this.setCustomValidity('<?php echo t("passwords_do_not_match"); ?>');
                } else {
                    this.setCustomValidity('');
                }
            });
            
            newPasswordInput.addEventListener('input', function() {
                if (confirmPasswordInput.value !== '') {
                    if (confirmPasswordInput.value !== this.value) {
                        confirmPasswordInput.setCustomValidity('<?php echo t("passwords_do_not_match"); ?>');
                    } else {
                        confirmPasswordInput.setCustomValidity('');
                    }
                }
            });
        });
    </script>
</body>
</html>
