<?php
/**
 * صفحة إدارة المعلمين في نظام UniverBoard
 * تتيح لمسؤول الكلية إدارة المعلمين
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول مسؤول الكلية
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'college_admin') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات مسؤول الكلية
$admin_id = $_SESSION['user_id'];
$db = get_db_connection();
$admin = get_college_admin_info($db, $admin_id);
$college_id = $admin['college_id'];
$college = get_college_info($db, $college_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// تحديد القسم المحدد (إذا تم تمرير معرف القسم في الرابط)
$selected_department_id = isset($_GET['department_id']) ? filter_input(INPUT_GET, 'department_id', FILTER_SANITIZE_NUMBER_INT) : null;

// معالجة إضافة معلم جديد
if (isset($_POST['add_teacher'])) {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    $department_id = filter_input(INPUT_POST, 'department_id', FILTER_SANITIZE_NUMBER_INT);
    $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
    $specialization = filter_input(INPUT_POST, 'specialization', FILTER_SANITIZE_STRING);
    $office_hours = filter_input(INPUT_POST, 'office_hours', FILTER_SANITIZE_STRING);
    $office_location = filter_input(INPUT_POST, 'office_location', FILTER_SANITIZE_STRING);
    $bio = filter_input(INPUT_POST, 'bio', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
    
    // التحقق من صحة البريد الإلكتروني
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = t('invalid_email_format');
    } else {
        // التحقق من عدم وجود بريد إلكتروني مكرر
        $email_exists = check_email_exists($db, $email);
        
        if ($email_exists) {
            $error_message = t('email_already_exists');
        } else {
            // إضافة المعلم الجديد
            $result = add_teacher($db, $college_id, $name, $email, $phone, $department_id, $title, $specialization, $office_hours, $office_location, $bio, $password);
            
            if ($result) {
                $success_message = t('teacher_added_successfully');
                
                // معالجة تحميل الصورة الشخصية
                if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
                    $teacher_id = $result;
                    $upload_result = upload_profile_image($teacher_id, 'teacher', $_FILES['profile_image']);
                    
                    if (!$upload_result['success']) {
                        $warning_message = $upload_result['message'];
                    }
                }
            } else {
                $error_message = t('failed_to_add_teacher');
            }
        }
    }
}

// معالجة تحديث معلم
if (isset($_POST['update_teacher'])) {
    $teacher_id = filter_input(INPUT_POST, 'teacher_id', FILTER_SANITIZE_NUMBER_INT);
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    $department_id = filter_input(INPUT_POST, 'department_id', FILTER_SANITIZE_NUMBER_INT);
    $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
    $specialization = filter_input(INPUT_POST, 'specialization', FILTER_SANITIZE_STRING);
    $office_hours = filter_input(INPUT_POST, 'office_hours', FILTER_SANITIZE_STRING);
    $office_location = filter_input(INPUT_POST, 'office_location', FILTER_SANITIZE_STRING);
    $bio = filter_input(INPUT_POST, 'bio', FILTER_SANITIZE_STRING);
    $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_NUMBER_INT);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
    
    // التحقق من صحة البريد الإلكتروني
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = t('invalid_email_format');
    } else {
        // التحقق من عدم وجود بريد إلكتروني مكرر (باستثناء البريد الإلكتروني الحالي للمعلم)
        $email_exists = check_email_exists($db, $email, $teacher_id);
        
        if ($email_exists) {
            $error_message = t('email_already_exists');
        } else {
            // تحديث بيانات المعلم
            $result = update_teacher($db, $teacher_id, $name, $email, $phone, $department_id, $title, $specialization, $office_hours, $office_location, $bio, $status, $password);
            
            if ($result) {
                $success_message = t('teacher_updated_successfully');
                
                // معالجة تحميل الصورة الشخصية
                if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
                    $upload_result = upload_profile_image($teacher_id, 'teacher', $_FILES['profile_image']);
                    
                    if (!$upload_result['success']) {
                        $warning_message = $upload_result['message'];
                    }
                }
            } else {
                $error_message = t('failed_to_update_teacher');
            }
        }
    }
}

// معالجة حذف معلم
if (isset($_POST['delete_teacher'])) {
    $teacher_id = filter_input(INPUT_POST, 'teacher_id', FILTER_SANITIZE_NUMBER_INT);
    
    // التحقق من عدم وجود مقررات مرتبطة بالمعلم
    $courses_count = get_teacher_courses_count($db, $teacher_id);
    
    if ($courses_count > 0) {
        $error_message = t('cannot_delete_teacher_with_courses');
    } else {
        $result = delete_teacher($db, $teacher_id);
        
        if ($result) {
            $success_message = t('teacher_deleted_successfully');
        } else {
            $error_message = t('failed_to_delete_teacher');
        }
    }
}

// الحصول على قائمة الأقسام في الكلية
$departments = get_college_departments($db, $college_id);

// الحصول على قائمة المعلمين في الكلية
if ($selected_department_id) {
    $teachers = get_department_teachers($db, $selected_department_id);
} else {
    $teachers = get_college_teachers($db, $college_id);
}

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('teachers'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            width: 250px;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .page-header {
            margin-bottom: 2rem;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .page-subtitle {
            color: var(--gray-color);
        }
        
        .card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
            border: none;
        }
        
        .theme-dark .card {
            background-color: var(--dark-bg);
        }
        
        .card-header {
            background-color: transparent;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1.25rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .theme-dark .card-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin: 0;
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #002135;
            border-color: #002135;
        }
        
        .btn-secondary {
            background-color: #669bbc;
            border-color: #669bbc;
        }
        
        .btn-secondary:hover {
            background-color: #5589a7;
            border-color: #5589a7;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            margin-bottom: 0;
        }
        
        .table th {
            font-weight: 600;
            border-top: none;
        }
        
        .table td, .table th {
            padding: 0.75rem;
            vertical-align: middle;
        }
        
        .table-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .table-avatar {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .badge-department {
            background-color: rgba(0, 48, 73, 0.1);
            color: var(--primary-color);
            font-weight: 500;
            padding: 0.35rem 0.65rem;
            border-radius: 0.25rem;
        }
        
        .theme-dark .badge-department {
            background-color: rgba(0, 48, 73, 0.3);
        }
        
        .badge-title {
            background-color: rgba(102, 155, 188, 0.1);
            color: #669bbc;
            font-weight: 500;
            padding: 0.35rem 0.65rem;
            border-radius: 0.25rem;
        }
        
        .theme-dark .badge-title {
            background-color: rgba(102, 155, 188, 0.3);
        }
        
        .badge-status-active {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
            font-weight: 500;
            padding: 0.35rem 0.65rem;
            border-radius: 0.25rem;
        }
        
        .theme-dark .badge-status-active {
            background-color: rgba(40, 167, 69, 0.3);
        }
        
        .badge-status-inactive {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            font-weight: 500;
            padding: 0.35rem 0.65rem;
            border-radius: 0.25rem;
        }
        
        .theme-dark .badge-status-inactive {
            background-color: rgba(220, 53, 69, 0.3);
        }
        
        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }
        
        .action-button {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .action-button:hover {
            transform: translateY(-2px);
        }
        
        .action-button-view {
            background-color: #17a2b8;
        }
        
        .action-button-edit {
            background-color: #ffc107;
        }
        
        .action-button-delete {
            background-color: #dc3545;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            font-weight: 500;
            margin-bottom: 0.5rem;
        }
        
        .form-control {
            padding: 0.75rem;
            border-radius: 0.5rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .form-control {
            background-color: var(--dark-bg);
            border-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .form-control:focus {
            box-shadow: 0 0 0 0.25rem rgba(0, 48, 73, 0.25);
            border-color: var(--primary-color);
        }
        
        .form-text {
            font-size: 0.85rem;
            color: var(--gray-color);
        }
        
        .modal-content {
            border-radius: 0.5rem;
            border: none;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .modal-content {
            background-color: var(--dark-bg);
        }
        
        .modal-header {
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1.25rem 1.5rem;
        }
        
        .theme-dark .modal-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .modal-title {
            font-weight: 600;
        }
        
        .modal-body {
            padding: 1.5rem;
        }
        
        .modal-footer {
            border-top: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1.25rem 1.5rem;
        }
        
        .theme-dark .modal-footer {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .teacher-stats {
            display: flex;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .teacher-stat {
            flex: 1;
            background-color: rgba(0, 0, 0, 0.02);
            border-radius: 0.5rem;
            padding: 1.25rem;
            text-align: center;
        }
        
        .theme-dark .teacher-stat {
            background-color: rgba(255, 255, 255, 0.02);
        }
        
        .teacher-stat-value {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
            color: var(--primary-color);
        }
        
        .teacher-stat-label {
            font-size: 0.85rem;
            color: var(--gray-color);
        }
        
        .teacher-info {
            margin-bottom: 1.5rem;
        }
        
        .teacher-info-item {
            display: flex;
            margin-bottom: 0.75rem;
        }
        
        .teacher-info-label {
            font-weight: 500;
            width: 150px;
            flex-shrink: 0;
        }
        
        .teacher-info-value {
            color: var(--gray-color);
        }
        
        .teacher-profile {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
            padding: 1.25rem;
            background-color: rgba(0, 0, 0, 0.02);
            border-radius: 0.5rem;
        }
        
        .theme-dark .teacher-profile {
            background-color: rgba(255, 255, 255, 0.02);
        }
        
        .teacher-profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 1.5rem;
        }
        
        [dir="rtl"] .teacher-profile-avatar {
            margin-right: 0;
            margin-left: 1.5rem;
        }
        
        .teacher-profile-info {
            flex-grow: 1;
        }
        
        .teacher-profile-name {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .teacher-profile-title {
            font-size: 1rem;
            color: var(--gray-color);
            margin-bottom: 0.5rem;
        }
        
        .teacher-profile-contact {
            display: flex;
            gap: 1rem;
            margin-top: 0.5rem;
        }
        
        .teacher-profile-contact a {
            color: var(--primary-color);
            text-decoration: none;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
        }
        
        .teacher-profile-contact a i {
            margin-right: 0.25rem;
        }
        
        [dir="rtl"] .teacher-profile-contact a i {
            margin-right: 0;
            margin-left: 0.25rem;
        }
        
        .filter-container {
            margin-bottom: 1.5rem;
        }
        
        .teacher-courses {
            margin-top: 1.5rem;
        }
        
        .teacher-courses-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .teacher-courses-list {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        
        .teacher-courses-list li {
            background-color: rgba(0, 0, 0, 0.02);
            padding: 0.5rem 0.75rem;
            border-radius: 0.25rem;
            font-size: 0.9rem;
        }
        
        .theme-dark .teacher-courses-list li {
            background-color: rgba(255, 255, 255, 0.02);
        }
        
        .profile-image-preview {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 1rem;
            border: 2px solid var(--primary-color);
        }
        
        .custom-file-upload {
            display: inline-block;
            padding: 0.375rem 0.75rem;
            cursor: pointer;
            background-color: #f8f9fa;
            border: 1px solid #ced4da;
            border-radius: 0.25rem;
            font-size: 0.875rem;
        }
        
        .theme-dark .custom-file-upload {
            background-color: var(--dark-bg);
            border-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .custom-file-upload i {
            margin-right: 0.25rem;
        }
        
        [dir="rtl"] .custom-file-upload i {
            margin-right: 0;
            margin-left: 0.25rem;
        }
        
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: var(--gray-color);
        }
        
        [dir="rtl"] .password-toggle {
            right: auto;
            left: 10px;
        }
        
        .password-container {
            position: relative;
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="college_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_departments.php">
                        <i class="fas fa-building"></i> <?php echo t('departments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_programs.php">
                        <i class="fas fa-graduation-cap"></i> <?php echo t('academic_programs'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="college_teachers.php">
                        <i class="fas fa-chalkboard-teacher"></i> <?php echo t('teachers'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_students.php">
                        <i class="fas fa-user-graduate"></i> <?php echo t('students'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('reports'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="college_reports_academic.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('academic_reports'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_reports_attendance.php">
                        <i class="fas fa-clipboard-check"></i> <?php echo t('attendance_reports'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_reports_performance.php">
                        <i class="fas fa-chart-bar"></i> <?php echo t('performance_reports'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="college_announcements.php">
                        <i class="fas fa-bullhorn"></i> <?php echo t('announcements'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('settings'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="college_profile.php">
                        <i class="fas fa-university"></i> <?php echo t('college_profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">5</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-user-graduate"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تسجيل 15 طالب جديد في قسم علوم الحاسب</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-calendar-alt"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تحديث جدول الامتحانات النهائية</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-info text-white rounded-circle">
                                        <i class="fas fa-chalkboard-teacher"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تعيين د. محمد أحمد كرئيس لقسم الهندسة المدنية</p>
                                    <small class="text-muted">منذ 3 ساعات</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="college_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/dean.jpg" alt="Dean" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. عبدالله العمري</p>
                                    <small class="text-muted">نرجو مراجعة الميزانية المقترحة للعام القادم</small>
                                    <small class="text-muted d-block">منذ 20 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/department_head.jpg" alt="Department Head" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. سارة الأحمد</p>
                                    <small class="text-muted">هل يمكننا مناقشة توزيع المقررات للفصل القادم؟</small>
                                    <small class="text-muted d-block">منذ ساعتين</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="college_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $admin['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $admin['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $admin['name']; ?></h6>
                            <small><?php echo t('college_admin'); ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="college_profile.php">
                            <i class="fas fa-university"></i> <?php echo t('college_profile'); ?>
                        </a>
                        <a class="dropdown-item" href="college_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="page-header mt-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="page-title"><?php echo t('teachers'); ?></h1>
                    <p class="page-subtitle"><?php echo t('manage_college_teachers'); ?></p>
                </div>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTeacherModal">
                    <i class="fas fa-plus me-1"></i> <?php echo t('add_teacher'); ?>
                </button>
            </div>
        </div>
        
        <!-- رسائل النجاح والخطأ -->
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $success_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $error_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($warning_message)): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <?php echo $warning_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <!-- فلتر الأقسام -->
        <div class="filter-container">
            <div class="card">
                <div class="card-body">
                    <form action="" method="get" class="row g-3">
                        <div class="col-md-8">
                            <label for="department_filter" class="form-label"><?php echo t('filter_by_department'); ?></label>
                            <select class="form-select" id="department_filter" name="department_id">
                                <option value=""><?php echo t('all_departments'); ?></option>
                                <?php foreach ($departments as $department): ?>
                                    <option value="<?php echo $department['id']; ?>" <?php echo $selected_department_id == $department['id'] ? 'selected' : ''; ?>>
                                        <?php echo $department['name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-filter me-1"></i> <?php echo t('filter'); ?>
                            </button>
                            <a href="college_teachers.php" class="btn btn-secondary">
                                <i class="fas fa-sync-alt me-1"></i> <?php echo t('reset'); ?>
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- جدول المعلمين -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><?php echo t('teachers_list'); ?></h3>
                <div class="d-flex gap-2">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" id="teacherSearch" class="form-control" placeholder="<?php echo t('search_teachers'); ?>">
                    </div>
                    <button type="button" class="btn btn-outline-primary" id="refreshTable">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover" id="teachersTable">
                        <thead>
                            <tr>
                                <th><?php echo t('name'); ?></th>
                                <th><?php echo t('email'); ?></th>
                                <th><?php echo t('phone'); ?></th>
                                <th><?php echo t('department'); ?></th>
                                <th><?php echo t('title'); ?></th>
                                <th><?php echo t('courses_count'); ?></th>
                                <th><?php echo t('status'); ?></th>
                                <th><?php echo t('actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($teachers as $teacher): ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo $teacher['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $teacher['name']; ?>" class="table-avatar">
                                            <span><?php echo $teacher['name']; ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo $teacher['email']; ?></td>
                                    <td><?php echo $teacher['phone'] ?: '-'; ?></td>
                                    <td>
                                        <span class="badge-department"><?php echo $teacher['department_name']; ?></span>
                                    </td>
                                    <td>
                                        <span class="badge-title"><?php echo $teacher['title'] ?: t('teacher'); ?></span>
                                    </td>
                                    <td><?php echo $teacher['courses_count'] ?: 0; ?></td>
                                    <td>
                                        <?php if ($teacher['status'] == 1): ?>
                                            <span class="badge-status-active"><?php echo t('active'); ?></span>
                                        <?php else: ?>
                                            <span class="badge-status-inactive"><?php echo t('inactive'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="#" class="action-button action-button-view" data-bs-toggle="modal" data-bs-target="#viewTeacherModal" data-teacher-id="<?php echo $teacher['id']; ?>">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="#" class="action-button action-button-edit" data-bs-toggle="modal" data-bs-target="#editTeacherModal" data-teacher-id="<?php echo $teacher['id']; ?>">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="#" class="action-button action-button-delete" data-bs-toggle="modal" data-bs-target="#deleteTeacherModal" data-teacher-id="<?php echo $teacher['id']; ?>" data-teacher-name="<?php echo $teacher['name']; ?>" data-courses-count="<?php echo $teacher['courses_count']; ?>">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال إضافة معلم جديد -->
    <div class="modal fade" id="addTeacherModal" tabindex="-1" aria-labelledby="addTeacherModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addTeacherModalLabel"><?php echo t('add_new_teacher'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-4 text-center">
                                <img src="assets/images/default-user.png" alt="Profile Image" class="profile-image-preview" id="profileImagePreview">
                                <div class="mb-3">
                                    <label for="profile_image" class="custom-file-upload">
                                        <i class="fas fa-upload"></i> <?php echo t('upload_image'); ?>
                                    </label>
                                    <input type="file" id="profile_image" name="profile_image" class="d-none" accept="image/*">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="name" class="form-label"><?php echo t('full_name'); ?> <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="email" class="form-label"><?php echo t('email'); ?> <span class="text-danger">*</span></label>
                                            <input type="email" class="form-control" id="email" name="email" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="phone" class="form-label"><?php echo t('phone'); ?></label>
                                            <input type="text" class="form-control" id="phone" name="phone">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="department_id" class="form-label"><?php echo t('department'); ?> <span class="text-danger">*</span></label>
                                            <select class="form-select" id="department_id" name="department_id" required>
                                                <option value=""><?php echo t('select_department'); ?></option>
                                                <?php foreach ($departments as $department): ?>
                                                    <option value="<?php echo $department['id']; ?>" <?php echo $selected_department_id == $department['id'] ? 'selected' : ''; ?>>
                                                        <?php echo $department['name']; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="title" class="form-label"><?php echo t('title'); ?></label>
                                            <select class="form-select" id="title" name="title">
                                                <option value="أستاذ"><?php echo t('professor'); ?></option>
                                                <option value="أستاذ مشارك"><?php echo t('associate_professor'); ?></option>
                                                <option value="أستاذ مساعد"><?php echo t('assistant_professor'); ?></option>
                                                <option value="محاضر"><?php echo t('lecturer'); ?></option>
                                                <option value="معيد"><?php echo t('teaching_assistant'); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="specialization" class="form-label"><?php echo t('specialization'); ?></label>
                                    <input type="text" class="form-control" id="specialization" name="specialization">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="office_hours" class="form-label"><?php echo t('office_hours'); ?></label>
                                    <input type="text" class="form-control" id="office_hours" name="office_hours">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="office_location" class="form-label"><?php echo t('office_location'); ?></label>
                            <input type="text" class="form-control" id="office_location" name="office_location">
                        </div>
                        
                        <div class="form-group">
                            <label for="bio" class="form-label"><?php echo t('bio'); ?></label>
                            <textarea class="form-control" id="bio" name="bio" rows="3"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="password" class="form-label"><?php echo t('password'); ?> <span class="text-danger">*</span></label>
                            <div class="password-container">
                                <input type="password" class="form-control" id="password" name="password" required>
                                <span class="password-toggle" onclick="togglePasswordVisibility('password')">
                                    <i class="fas fa-eye"></i>
                                </span>
                            </div>
                            <div class="form-text"><?php echo t('password_requirements'); ?></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                        <button type="submit" name="add_teacher" class="btn btn-primary"><?php echo t('add_teacher'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- مودال عرض تفاصيل المعلم -->
    <div class="modal fade" id="viewTeacherModal" tabindex="-1" aria-labelledby="viewTeacherModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewTeacherModalLabel"><?php echo t('teacher_details'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="teacher-stats">
                        <div class="teacher-stat">
                            <div class="teacher-stat-value" id="viewCoursesCount">0</div>
                            <div class="teacher-stat-label"><?php echo t('courses'); ?></div>
                        </div>
                        <div class="teacher-stat">
                            <div class="teacher-stat-value" id="viewStudentsCount">0</div>
                            <div class="teacher-stat-label"><?php echo t('students'); ?></div>
                        </div>
                        <div class="teacher-stat">
                            <div class="teacher-stat-value" id="viewExperienceYears">0</div>
                            <div class="teacher-stat-label"><?php echo t('experience_years'); ?></div>
                        </div>
                        <div class="teacher-stat">
                            <div class="teacher-stat-value" id="viewPublicationsCount">0</div>
                            <div class="teacher-stat-label"><?php echo t('publications'); ?></div>
                        </div>
                    </div>
                    
                    <div class="teacher-profile">
                        <img src="assets/images/default-user.png" alt="Teacher Profile" class="teacher-profile-avatar" id="viewProfileImage">
                        <div class="teacher-profile-info">
                            <div class="teacher-profile-name" id="viewName">-</div>
                            <div class="teacher-profile-title" id="viewTitle">-</div>
                            <div class="teacher-profile-contact">
                                <a href="#" id="viewEmailLink"><i class="fas fa-envelope"></i> <span id="viewEmail">-</span></a>
                                <a href="#" id="viewPhoneLink"><i class="fas fa-phone"></i> <span id="viewPhone">-</span></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="teacher-info">
                        <div class="teacher-info-item">
                            <div class="teacher-info-label"><?php echo t('department'); ?>:</div>
                            <div class="teacher-info-value" id="viewDepartment">-</div>
                        </div>
                        <div class="teacher-info-item">
                            <div class="teacher-info-label"><?php echo t('specialization'); ?>:</div>
                            <div class="teacher-info-value" id="viewSpecialization">-</div>
                        </div>
                        <div class="teacher-info-item">
                            <div class="teacher-info-label"><?php echo t('office_hours'); ?>:</div>
                            <div class="teacher-info-value" id="viewOfficeHours">-</div>
                        </div>
                        <div class="teacher-info-item">
                            <div class="teacher-info-label"><?php echo t('office_location'); ?>:</div>
                            <div class="teacher-info-value" id="viewOfficeLocation">-</div>
                        </div>
                        <div class="teacher-info-item">
                            <div class="teacher-info-label"><?php echo t('bio'); ?>:</div>
                            <div class="teacher-info-value" id="viewBio">-</div>
                        </div>
                        <div class="teacher-info-item">
                            <div class="teacher-info-label"><?php echo t('status'); ?>:</div>
                            <div class="teacher-info-value" id="viewStatus">-</div>
                        </div>
                        <div class="teacher-info-item">
                            <div class="teacher-info-label"><?php echo t('join_date'); ?>:</div>
                            <div class="teacher-info-value" id="viewJoinDate">-</div>
                        </div>
                        <div class="teacher-info-item">
                            <div class="teacher-info-label"><?php echo t('last_login'); ?>:</div>
                            <div class="teacher-info-value" id="viewLastLogin">-</div>
                        </div>
                    </div>
                    
                    <div class="teacher-courses">
                        <h4 class="teacher-courses-title"><?php echo t('assigned_courses'); ?></h4>
                        <ul class="teacher-courses-list" id="viewCoursesList"></ul>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('close'); ?></button>
                    <a href="#" class="btn btn-primary" id="viewCoursesBtn"><?php echo t('view_teacher_courses'); ?></a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال تعديل المعلم -->
    <div class="modal fade" id="editTeacherModal" tabindex="-1" aria-labelledby="editTeacherModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editTeacherModalLabel"><?php echo t('edit_teacher'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" id="editTeacherId" name="teacher_id">
                        
                        <div class="row">
                            <div class="col-md-4 text-center">
                                <img src="assets/images/default-user.png" alt="Profile Image" class="profile-image-preview" id="editProfileImagePreview">
                                <div class="mb-3">
                                    <label for="edit_profile_image" class="custom-file-upload">
                                        <i class="fas fa-upload"></i> <?php echo t('change_image'); ?>
                                    </label>
                                    <input type="file" id="edit_profile_image" name="profile_image" class="d-none" accept="image/*">
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label for="editName" class="form-label"><?php echo t('full_name'); ?> <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="editName" name="name" required>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="editEmail" class="form-label"><?php echo t('email'); ?> <span class="text-danger">*</span></label>
                                            <input type="email" class="form-control" id="editEmail" name="email" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="editPhone" class="form-label"><?php echo t('phone'); ?></label>
                                            <input type="text" class="form-control" id="editPhone" name="phone">
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="editDepartmentId" class="form-label"><?php echo t('department'); ?> <span class="text-danger">*</span></label>
                                            <select class="form-select" id="editDepartmentId" name="department_id" required>
                                                <option value=""><?php echo t('select_department'); ?></option>
                                                <?php foreach ($departments as $department): ?>
                                                    <option value="<?php echo $department['id']; ?>">
                                                        <?php echo $department['name']; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="editTitle" class="form-label"><?php echo t('title'); ?></label>
                                            <select class="form-select" id="editTitle" name="title">
                                                <option value="أستاذ"><?php echo t('professor'); ?></option>
                                                <option value="أستاذ مشارك"><?php echo t('associate_professor'); ?></option>
                                                <option value="أستاذ مساعد"><?php echo t('assistant_professor'); ?></option>
                                                <option value="محاضر"><?php echo t('lecturer'); ?></option>
                                                <option value="معيد"><?php echo t('teaching_assistant'); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="editSpecialization" class="form-label"><?php echo t('specialization'); ?></label>
                                    <input type="text" class="form-control" id="editSpecialization" name="specialization">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="editOfficeHours" class="form-label"><?php echo t('office_hours'); ?></label>
                                    <input type="text" class="form-control" id="editOfficeHours" name="office_hours">
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="editOfficeLocation" class="form-label"><?php echo t('office_location'); ?></label>
                            <input type="text" class="form-control" id="editOfficeLocation" name="office_location">
                        </div>
                        
                        <div class="form-group">
                            <label for="editBio" class="form-label"><?php echo t('bio'); ?></label>
                            <textarea class="form-control" id="editBio" name="bio" rows="3"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="editStatus" class="form-label"><?php echo t('status'); ?></label>
                            <select class="form-select" id="editStatus" name="status">
                                <option value="1"><?php echo t('active'); ?></option>
                                <option value="0"><?php echo t('inactive'); ?></option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="editPassword" class="form-label"><?php echo t('password'); ?></label>
                            <div class="password-container">
                                <input type="password" class="form-control" id="editPassword" name="password">
                                <span class="password-toggle" onclick="togglePasswordVisibility('editPassword')">
                                    <i class="fas fa-eye"></i>
                                </span>
                            </div>
                            <div class="form-text"><?php echo t('leave_empty_to_keep_current_password'); ?></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                        <button type="submit" name="update_teacher" class="btn btn-primary"><?php echo t('save_changes'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- مودال حذف المعلم -->
    <div class="modal fade" id="deleteTeacherModal" tabindex="-1" aria-labelledby="deleteTeacherModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteTeacherModalLabel"><?php echo t('delete_teacher'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p><?php echo t('delete_teacher_confirmation'); ?> <strong id="deleteTeacherName"></strong>؟</p>
                    <div class="alert alert-warning" id="deleteTeacherWarning">
                        <i class="fas fa-exclamation-triangle me-2"></i> <?php echo t('delete_teacher_warning'); ?>
                    </div>
                </div>
                <form action="" method="post">
                    <input type="hidden" id="deleteTeacherId" name="teacher_id">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                        <button type="submit" name="delete_teacher" class="btn btn-danger" id="deleteTeacherBtn"><?php echo t('delete'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // زر تبديل المظهر
            document.getElementById('themeToggle').addEventListener('click', function() {
                const currentTheme = document.body.className.includes('theme-dark') ? 'dark' : 'light';
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.cookie = `theme=${newTheme}; path=/; max-age=31536000`;
                document.body.className = `theme-${newTheme}`;
                
                this.innerHTML = `<i class="fas fa-${newTheme === 'dark' ? 'sun' : 'moon'}"></i>`;
            });
            
            // تهيئة جدول البيانات
            const teachersTable = $('#teachersTable').DataTable({
                language: {
                    url: '<?php echo $lang === 'ar' ? 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/ar.json' : 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/en-GB.json'; ?>'
                },
                responsive: true,
                dom: 'lrtip',
                pageLength: 10,
                lengthMenu: [5, 10, 25, 50, 100],
                order: [[0, 'asc']]
            });
            
            // البحث في الجدول
            $('#teacherSearch').on('keyup', function() {
                teachersTable.search(this.value).draw();
            });
            
            // تحديث الجدول
            $('#refreshTable').on('click', function() {
                location.reload();
            });
            
            // معاينة الصورة الشخصية عند التحميل (إضافة معلم جديد)
            document.getElementById('profile_image').addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        document.getElementById('profileImagePreview').src = e.target.result;
                    };
                    reader.readAsDataURL(file);
                }
            });
            
            // معاينة الصورة الشخصية عند التحميل (تعديل معلم)
            document.getElementById('edit_profile_image').addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        document.getElementById('editProfileImagePreview').src = e.target.result;
                    };
                    reader.readAsDataURL(file);
                }
            });
            
            // مودال عرض تفاصيل المعلم
            $('#viewTeacherModal').on('show.bs.modal', function(event) {
                const button = $(event.relatedTarget);
                const teacherId = button.data('teacher-id');
                
                // هنا يمكن إضافة طلب AJAX للحصول على بيانات المعلم
                // لأغراض العرض، سنستخدم بيانات وهمية
                
                const teachers = <?php echo json_encode($teachers); ?>;
                const teacher = teachers.find(t => t.id == teacherId);
                
                if (teacher) {
                    $('#viewName').text(teacher.name);
                    $('#viewTitle').text(teacher.title || '<?php echo t('teacher'); ?>');
                    $('#viewEmail').text(teacher.email);
                    $('#viewEmailLink').attr('href', 'mailto:' + teacher.email);
                    $('#viewPhone').text(teacher.phone || '-');
                    $('#viewPhoneLink').attr('href', 'tel:' + (teacher.phone || '#'));
                    $('#viewDepartment').text(teacher.department_name);
                    $('#viewSpecialization').text(teacher.specialization || '-');
                    $('#viewOfficeHours').text(teacher.office_hours || '-');
                    $('#viewOfficeLocation').text(teacher.office_location || '-');
                    $('#viewBio').text(teacher.bio || '-');
                    $('#viewStatus').html(teacher.status == 1 ? 
                        '<span class="badge-status-active"><?php echo t('active'); ?></span>' : 
                        '<span class="badge-status-inactive"><?php echo t('inactive'); ?></span>');
                    $('#viewJoinDate').text(teacher.created_at || '-');
                    $('#viewLastLogin').text(teacher.last_login || '-');
                    $('#viewProfileImage').attr('src', teacher.profile_image || 'assets/images/default-user.png');
                    
                    $('#viewCoursesCount').text(teacher.courses_count || 0);
                    $('#viewStudentsCount').text(teacher.students_count || 0);
                    $('#viewExperienceYears').text(teacher.experience_years || 0);
                    $('#viewPublicationsCount').text(teacher.publications_count || 0);
                    
                    // عرض المقررات المسندة للمعلم
                    const coursesList = $('#viewCoursesList');
                    coursesList.empty();
                    
                    if (teacher.courses && teacher.courses.length > 0) {
                        teacher.courses.forEach(course => {
                            coursesList.append(`<li>${course.name} (${course.code})</li>`);
                        });
                    } else {
                        coursesList.append(`<li class="text-muted"><?php echo t('no_assigned_courses'); ?></li>`);
                    }
                    
                    $('#viewCoursesBtn').attr('href', 'college_teacher_courses.php?teacher_id=' + teacherId);
                }
            });
            
            // مودال تعديل المعلم
            $('#editTeacherModal').on('show.bs.modal', function(event) {
                const button = $(event.relatedTarget);
                const teacherId = button.data('teacher-id');
                
                // هنا يمكن إضافة طلب AJAX للحصول على بيانات المعلم
                // لأغراض العرض، سنستخدم بيانات وهمية
                
                const teachers = <?php echo json_encode($teachers); ?>;
                const teacher = teachers.find(t => t.id == teacherId);
                
                if (teacher) {
                    $('#editTeacherId').val(teacher.id);
                    $('#editName').val(teacher.name);
                    $('#editEmail').val(teacher.email);
                    $('#editPhone').val(teacher.phone || '');
                    $('#editDepartmentId').val(teacher.department_id);
                    $('#editTitle').val(teacher.title || 'محاضر');
                    $('#editSpecialization').val(teacher.specialization || '');
                    $('#editOfficeHours').val(teacher.office_hours || '');
                    $('#editOfficeLocation').val(teacher.office_location || '');
                    $('#editBio').val(teacher.bio || '');
                    $('#editStatus').val(teacher.status);
                    $('#editPassword').val('');
                    $('#editProfileImagePreview').attr('src', teacher.profile_image || 'assets/images/default-user.png');
                }
            });
            
            // مودال حذف المعلم
            $('#deleteTeacherModal').on('show.bs.modal', function(event) {
                const button = $(event.relatedTarget);
                const teacherId = button.data('teacher-id');
                const teacherName = button.data('teacher-name');
                const coursesCount = button.data('courses-count');
                
                $('#deleteTeacherId').val(teacherId);
                $('#deleteTeacherName').text(teacherName);
                
                // التحقق من وجود مقررات مرتبطة بالمعلم
                if (coursesCount > 0) {
                    $('#deleteTeacherWarning').html(`
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo t('cannot_delete_teacher_with_courses_warning'); ?> (${coursesCount} <?php echo t('courses'); ?>)
                    `);
                    $('#deleteTeacherBtn').prop('disabled', true);
                } else {
                    $('#deleteTeacherWarning').html(`
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo t('delete_teacher_warning'); ?>
                    `);
                    $('#deleteTeacherBtn').prop('disabled', false);
                }
            });
        });
        
        // دالة لإظهار/إخفاء كلمة المرور
        function togglePasswordVisibility(inputId) {
            const passwordInput = document.getElementById(inputId);
            const passwordToggle = passwordInput.nextElementSibling.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                passwordToggle.classList.remove('fa-eye');
                passwordToggle.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                passwordToggle.classList.remove('fa-eye-slash');
                passwordToggle.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
