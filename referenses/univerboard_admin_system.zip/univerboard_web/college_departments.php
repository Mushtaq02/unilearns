<?php
/**
 * صفحة إدارة الأقسام في نظام UniverBoard
 * تتيح لمسؤول الكلية إدارة الأقسام الأكاديمية
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول مسؤول الكلية
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'college_admin') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات مسؤول الكلية
$admin_id = $_SESSION['user_id'];
$db = get_db_connection();
$admin = get_college_admin_info($db, $admin_id);
$college_id = $admin['college_id'];
$college = get_college_info($db, $college_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// معالجة إضافة قسم جديد
if (isset($_POST['add_department'])) {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $code = filter_input(INPUT_POST, 'code', FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
    $head_id = filter_input(INPUT_POST, 'head_id', FILTER_SANITIZE_NUMBER_INT);
    
    if (!empty($name) && !empty($code)) {
        $result = add_department($db, $college_id, $name, $code, $description, $head_id);
        
        if ($result) {
            $success_message = t('department_added_successfully');
        } else {
            $error_message = t('failed_to_add_department');
        }
    } else {
        $error_message = t('name_and_code_required');
    }
}

// معالجة تحديث قسم
if (isset($_POST['update_department'])) {
    $department_id = filter_input(INPUT_POST, 'department_id', FILTER_SANITIZE_NUMBER_INT);
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $code = filter_input(INPUT_POST, 'code', FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
    $head_id = filter_input(INPUT_POST, 'head_id', FILTER_SANITIZE_NUMBER_INT);
    $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_NUMBER_INT);
    
    if (!empty($department_id) && !empty($name) && !empty($code)) {
        $result = update_department($db, $department_id, $name, $code, $description, $head_id, $status);
        
        if ($result) {
            $success_message = t('department_updated_successfully');
        } else {
            $error_message = t('failed_to_update_department');
        }
    } else {
        $error_message = t('name_and_code_required');
    }
}

// معالجة حذف قسم
if (isset($_POST['delete_department'])) {
    $department_id = filter_input(INPUT_POST, 'department_id', FILTER_SANITIZE_NUMBER_INT);
    
    if (!empty($department_id)) {
        $result = delete_department($db, $department_id);
        
        if ($result) {
            $success_message = t('department_deleted_successfully');
        } else {
            $error_message = t('failed_to_delete_department');
        }
    } else {
        $error_message = t('department_id_required');
    }
}

// الحصول على قائمة الأقسام في الكلية
$departments = get_college_departments($db, $college_id);

// الحصول على قائمة المعلمين في الكلية للاختيار من بينهم كرؤساء أقسام
$teachers = get_college_teachers($db, $college_id);

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('departments'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            width: 250px;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .page-header {
            margin-bottom: 2rem;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .page-subtitle {
            color: var(--gray-color);
        }
        
        .card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
            border: none;
        }
        
        .theme-dark .card {
            background-color: var(--dark-bg);
        }
        
        .card-header {
            background-color: transparent;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1.25rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .theme-dark .card-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin: 0;
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #002135;
            border-color: #002135;
        }
        
        .btn-secondary {
            background-color: #669bbc;
            border-color: #669bbc;
        }
        
        .btn-secondary:hover {
            background-color: #5589a7;
            border-color: #5589a7;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            margin-bottom: 0;
        }
        
        .table th {
            font-weight: 600;
            border-top: none;
        }
        
        .table td, .table th {
            padding: 0.75rem;
            vertical-align: middle;
        }
        
        .table-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .table-avatar {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .badge-department {
            background-color: rgba(0, 48, 73, 0.1);
            color: var(--primary-color);
            font-weight: 500;
            padding: 0.35rem 0.65rem;
            border-radius: 0.25rem;
        }
        
        .theme-dark .badge-department {
            background-color: rgba(0, 48, 73, 0.3);
        }
        
        .badge-status-active {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
            font-weight: 500;
            padding: 0.35rem 0.65rem;
            border-radius: 0.25rem;
        }
        
        .theme-dark .badge-status-active {
            background-color: rgba(40, 167, 69, 0.3);
        }
        
        .badge-status-inactive {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            font-weight: 500;
            padding: 0.35rem 0.65rem;
            border-radius: 0.25rem;
        }
        
        .theme-dark .badge-status-inactive {
            background-color: rgba(220, 53, 69, 0.3);
        }
        
        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }
        
        .action-button {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .action-button:hover {
            transform: translateY(-2px);
        }
        
        .action-button-view {
            background-color: #17a2b8;
        }
        
        .action-button-edit {
            background-color: #ffc107;
        }
        
        .action-button-delete {
            background-color: #dc3545;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            font-weight: 500;
            margin-bottom: 0.5rem;
        }
        
        .form-control {
            padding: 0.75rem;
            border-radius: 0.5rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .form-control {
            background-color: var(--dark-bg);
            border-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .form-control:focus {
            box-shadow: 0 0 0 0.25rem rgba(0, 48, 73, 0.25);
            border-color: var(--primary-color);
        }
        
        .form-text {
            font-size: 0.85rem;
            color: var(--gray-color);
        }
        
        .modal-content {
            border-radius: 0.5rem;
            border: none;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .modal-content {
            background-color: var(--dark-bg);
        }
        
        .modal-header {
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1.25rem 1.5rem;
        }
        
        .theme-dark .modal-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .modal-title {
            font-weight: 600;
        }
        
        .modal-body {
            padding: 1.5rem;
        }
        
        .modal-footer {
            border-top: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1.25rem 1.5rem;
        }
        
        .theme-dark .modal-footer {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .department-stats {
            display: flex;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }
        
        .department-stat {
            flex: 1;
            background-color: rgba(0, 0, 0, 0.02);
            border-radius: 0.5rem;
            padding: 1.25rem;
            text-align: center;
        }
        
        .theme-dark .department-stat {
            background-color: rgba(255, 255, 255, 0.02);
        }
        
        .department-stat-value {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
            color: var(--primary-color);
        }
        
        .department-stat-label {
            font-size: 0.85rem;
            color: var(--gray-color);
        }
        
        .department-info {
            margin-bottom: 1.5rem;
        }
        
        .department-info-item {
            display: flex;
            margin-bottom: 0.75rem;
        }
        
        .department-info-label {
            font-weight: 500;
            width: 150px;
            flex-shrink: 0;
        }
        
        .department-info-value {
            color: var(--gray-color);
        }
        
        .department-head {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
            padding: 1.25rem;
            background-color: rgba(0, 0, 0, 0.02);
            border-radius: 0.5rem;
        }
        
        .theme-dark .department-head {
            background-color: rgba(255, 255, 255, 0.02);
        }
        
        .department-head-avatar {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 1rem;
        }
        
        [dir="rtl"] .department-head-avatar {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .department-head-info {
            flex-grow: 1;
        }
        
        .department-head-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .department-head-title {
            font-size: 0.85rem;
            color: var(--gray-color);
        }
        
        .department-head-contact {
            display: flex;
            gap: 1rem;
            margin-top: 0.5rem;
        }
        
        .department-head-contact a {
            color: var(--primary-color);
            text-decoration: none;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
        }
        
        .department-head-contact a i {
            margin-right: 0.25rem;
        }
        
        [dir="rtl"] .department-head-contact a i {
            margin-right: 0;
            margin-left: 0.25rem;
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="college_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="college_departments.php">
                        <i class="fas fa-building"></i> <?php echo t('departments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_programs.php">
                        <i class="fas fa-graduation-cap"></i> <?php echo t('academic_programs'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_teachers.php">
                        <i class="fas fa-chalkboard-teacher"></i> <?php echo t('teachers'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_students.php">
                        <i class="fas fa-user-graduate"></i> <?php echo t('students'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('reports'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="college_reports_academic.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('academic_reports'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_reports_attendance.php">
                        <i class="fas fa-clipboard-check"></i> <?php echo t('attendance_reports'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_reports_performance.php">
                        <i class="fas fa-chart-bar"></i> <?php echo t('performance_reports'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="college_announcements.php">
                        <i class="fas fa-bullhorn"></i> <?php echo t('announcements'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('settings'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="college_profile.php">
                        <i class="fas fa-university"></i> <?php echo t('college_profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">5</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-user-graduate"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تسجيل 15 طالب جديد في قسم علوم الحاسب</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-calendar-alt"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تحديث جدول الامتحانات النهائية</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-info text-white rounded-circle">
                                        <i class="fas fa-chalkboard-teacher"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تعيين د. محمد أحمد كرئيس لقسم الهندسة المدنية</p>
                                    <small class="text-muted">منذ 3 ساعات</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="college_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/dean.jpg" alt="Dean" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. عبدالله العمري</p>
                                    <small class="text-muted">نرجو مراجعة الميزانية المقترحة للعام القادم</small>
                                    <small class="text-muted d-block">منذ 20 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/department_head.jpg" alt="Department Head" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. سارة الأحمد</p>
                                    <small class="text-muted">هل يمكننا مناقشة توزيع المقررات للفصل القادم؟</small>
                                    <small class="text-muted d-block">منذ ساعتين</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="college_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $admin['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $admin['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $admin['name']; ?></h6>
                            <small><?php echo t('college_admin'); ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="college_profile.php">
                            <i class="fas fa-university"></i> <?php echo t('college_profile'); ?>
                        </a>
                        <a class="dropdown-item" href="college_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="page-header mt-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="page-title"><?php echo t('departments'); ?></h1>
                    <p class="page-subtitle"><?php echo t('manage_academic_departments'); ?></p>
                </div>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addDepartmentModal">
                    <i class="fas fa-plus me-1"></i> <?php echo t('add_department'); ?>
                </button>
            </div>
        </div>
        
        <!-- رسائل النجاح والخطأ -->
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $success_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $error_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <!-- جدول الأقسام -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title"><?php echo t('departments_list'); ?></h3>
                <div class="d-flex gap-2">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" id="departmentSearch" class="form-control" placeholder="<?php echo t('search_departments'); ?>">
                    </div>
                    <button type="button" class="btn btn-outline-primary" id="refreshTable">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover" id="departmentsTable">
                        <thead>
                            <tr>
                                <th><?php echo t('name'); ?></th>
                                <th><?php echo t('code'); ?></th>
                                <th><?php echo t('head'); ?></th>
                                <th><?php echo t('students'); ?></th>
                                <th><?php echo t('programs'); ?></th>
                                <th><?php echo t('status'); ?></th>
                                <th><?php echo t('actions'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($departments as $department): ?>
                                <tr>
                                    <td>
                                        <span class="badge-department"><?php echo $department['name']; ?></span>
                                    </td>
                                    <td><?php echo $department['code']; ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo $department['head_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $department['head_name']; ?>" class="table-avatar">
                                            <span><?php echo $department['head_name']; ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo number_format($department['students_count']); ?></td>
                                    <td><?php echo number_format($department['programs_count']); ?></td>
                                    <td>
                                        <?php if ($department['status'] == 1): ?>
                                            <span class="badge-status-active"><?php echo t('active'); ?></span>
                                        <?php else: ?>
                                            <span class="badge-status-inactive"><?php echo t('inactive'); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="#" class="action-button action-button-view" data-bs-toggle="modal" data-bs-target="#viewDepartmentModal" data-department-id="<?php echo $department['id']; ?>">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="#" class="action-button action-button-edit" data-bs-toggle="modal" data-bs-target="#editDepartmentModal" data-department-id="<?php echo $department['id']; ?>">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="#" class="action-button action-button-delete" data-bs-toggle="modal" data-bs-target="#deleteDepartmentModal" data-department-id="<?php echo $department['id']; ?>" data-department-name="<?php echo $department['name']; ?>">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال إضافة قسم جديد -->
    <div class="modal fade" id="addDepartmentModal" tabindex="-1" aria-labelledby="addDepartmentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addDepartmentModalLabel"><?php echo t('add_new_department'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="post">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="name" class="form-label"><?php echo t('department_name'); ?> <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="code" class="form-label"><?php echo t('department_code'); ?> <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="code" name="code" required>
                            <div class="form-text"><?php echo t('department_code_help'); ?></div>
                        </div>
                        <div class="form-group">
                            <label for="description" class="form-label"><?php echo t('description'); ?></label>
                            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="head_id" class="form-label"><?php echo t('department_head'); ?></label>
                            <select class="form-select" id="head_id" name="head_id">
                                <option value=""><?php echo t('select_department_head'); ?></option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?php echo $teacher['id']; ?>"><?php echo $teacher['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                        <button type="submit" name="add_department" class="btn btn-primary"><?php echo t('add_department'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- مودال عرض تفاصيل القسم -->
    <div class="modal fade" id="viewDepartmentModal" tabindex="-1" aria-labelledby="viewDepartmentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewDepartmentModalLabel"><?php echo t('department_details'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="department-stats">
                        <div class="department-stat">
                            <div class="department-stat-value" id="viewStudentsCount">0</div>
                            <div class="department-stat-label"><?php echo t('students'); ?></div>
                        </div>
                        <div class="department-stat">
                            <div class="department-stat-value" id="viewTeachersCount">0</div>
                            <div class="department-stat-label"><?php echo t('teachers'); ?></div>
                        </div>
                        <div class="department-stat">
                            <div class="department-stat-value" id="viewProgramsCount">0</div>
                            <div class="department-stat-label"><?php echo t('programs'); ?></div>
                        </div>
                        <div class="department-stat">
                            <div class="department-stat-value" id="viewCoursesCount">0</div>
                            <div class="department-stat-label"><?php echo t('courses'); ?></div>
                        </div>
                    </div>
                    
                    <div class="department-head" id="departmentHeadContainer">
                        <img src="assets/images/default-user.png" alt="Department Head" class="department-head-avatar" id="viewHeadImage">
                        <div class="department-head-info">
                            <div class="department-head-name" id="viewHeadName">-</div>
                            <div class="department-head-title" id="viewHeadTitle">-</div>
                            <div class="department-head-contact">
                                <a href="#" id="viewHeadEmail"><i class="fas fa-envelope"></i> <span>-</span></a>
                                <a href="#" id="viewHeadPhone"><i class="fas fa-phone"></i> <span>-</span></a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="department-info">
                        <div class="department-info-item">
                            <div class="department-info-label"><?php echo t('department_name'); ?>:</div>
                            <div class="department-info-value" id="viewName">-</div>
                        </div>
                        <div class="department-info-item">
                            <div class="department-info-label"><?php echo t('department_code'); ?>:</div>
                            <div class="department-info-value" id="viewCode">-</div>
                        </div>
                        <div class="department-info-item">
                            <div class="department-info-label"><?php echo t('status'); ?>:</div>
                            <div class="department-info-value" id="viewStatus">-</div>
                        </div>
                        <div class="department-info-item">
                            <div class="department-info-label"><?php echo t('description'); ?>:</div>
                            <div class="department-info-value" id="viewDescription">-</div>
                        </div>
                        <div class="department-info-item">
                            <div class="department-info-label"><?php echo t('created_at'); ?>:</div>
                            <div class="department-info-value" id="viewCreatedAt">-</div>
                        </div>
                        <div class="department-info-item">
                            <div class="department-info-label"><?php echo t('last_updated'); ?>:</div>
                            <div class="department-info-value" id="viewUpdatedAt">-</div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('close'); ?></button>
                    <a href="#" class="btn btn-primary" id="viewProgramsBtn"><?php echo t('view_programs'); ?></a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال تعديل القسم -->
    <div class="modal fade" id="editDepartmentModal" tabindex="-1" aria-labelledby="editDepartmentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editDepartmentModalLabel"><?php echo t('edit_department'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="post">
                    <div class="modal-body">
                        <input type="hidden" id="editDepartmentId" name="department_id">
                        <div class="form-group">
                            <label for="editName" class="form-label"><?php echo t('department_name'); ?> <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="editName" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="editCode" class="form-label"><?php echo t('department_code'); ?> <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="editCode" name="code" required>
                            <div class="form-text"><?php echo t('department_code_help'); ?></div>
                        </div>
                        <div class="form-group">
                            <label for="editDescription" class="form-label"><?php echo t('description'); ?></label>
                            <textarea class="form-control" id="editDescription" name="description" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="editHeadId" class="form-label"><?php echo t('department_head'); ?></label>
                            <select class="form-select" id="editHeadId" name="head_id">
                                <option value=""><?php echo t('select_department_head'); ?></option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?php echo $teacher['id']; ?>"><?php echo $teacher['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="editStatus" class="form-label"><?php echo t('status'); ?></label>
                            <select class="form-select" id="editStatus" name="status">
                                <option value="1"><?php echo t('active'); ?></option>
                                <option value="0"><?php echo t('inactive'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                        <button type="submit" name="update_department" class="btn btn-primary"><?php echo t('save_changes'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- مودال حذف القسم -->
    <div class="modal fade" id="deleteDepartmentModal" tabindex="-1" aria-labelledby="deleteDepartmentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteDepartmentModalLabel"><?php echo t('delete_department'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p><?php echo t('delete_department_confirmation'); ?> <strong id="deleteDepartmentName"></strong>؟</p>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i> <?php echo t('delete_department_warning'); ?>
                    </div>
                </div>
                <form action="" method="post">
                    <input type="hidden" id="deleteDepartmentId" name="department_id">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                        <button type="submit" name="delete_department" class="btn btn-danger"><?php echo t('delete'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // زر تبديل المظهر
            document.getElementById('themeToggle').addEventListener('click', function() {
                const currentTheme = document.body.className.includes('theme-dark') ? 'dark' : 'light';
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.cookie = `theme=${newTheme}; path=/; max-age=31536000`;
                document.body.className = `theme-${newTheme}`;
                
                this.innerHTML = `<i class="fas fa-${newTheme === 'dark' ? 'sun' : 'moon'}"></i>`;
            });
            
            // تهيئة جدول البيانات
            const departmentsTable = $('#departmentsTable').DataTable({
                language: {
                    url: '<?php echo $lang === 'ar' ? 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/ar.json' : 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/en-GB.json'; ?>'
                },
                responsive: true,
                dom: 'lrtip',
                pageLength: 10,
                lengthMenu: [5, 10, 25, 50, 100],
                order: [[0, 'asc']]
            });
            
            // البحث في الجدول
            $('#departmentSearch').on('keyup', function() {
                departmentsTable.search(this.value).draw();
            });
            
            // تحديث الجدول
            $('#refreshTable').on('click', function() {
                location.reload();
            });
            
            // مودال عرض تفاصيل القسم
            $('#viewDepartmentModal').on('show.bs.modal', function(event) {
                const button = $(event.relatedTarget);
                const departmentId = button.data('department-id');
                
                // هنا يمكن إضافة طلب AJAX للحصول على بيانات القسم
                // لأغراض العرض، سنستخدم بيانات وهمية
                
                const departments = <?php echo json_encode($departments); ?>;
                const department = departments.find(d => d.id == departmentId);
                
                if (department) {
                    $('#viewName').text(department.name);
                    $('#viewCode').text(department.code);
                    $('#viewDescription').text(department.description || '-');
                    $('#viewStatus').html(department.status == 1 ? 
                        '<span class="badge-status-active"><?php echo t('active'); ?></span>' : 
                        '<span class="badge-status-inactive"><?php echo t('inactive'); ?></span>');
                    $('#viewCreatedAt').text(department.created_at || '-');
                    $('#viewUpdatedAt').text(department.updated_at || '-');
                    
                    $('#viewStudentsCount').text(department.students_count);
                    $('#viewTeachersCount').text(department.teachers_count || 0);
                    $('#viewProgramsCount').text(department.programs_count);
                    $('#viewCoursesCount').text(department.courses_count || 0);
                    
                    if (department.head_name) {
                        $('#departmentHeadContainer').show();
                        $('#viewHeadName').text(department.head_name);
                        $('#viewHeadTitle').text(department.head_title || '<?php echo t('department_head'); ?>');
                        $('#viewHeadImage').attr('src', department.head_image || 'assets/images/default-user.png');
                        $('#viewHeadEmail span').text(department.head_email || '-');
                        $('#viewHeadPhone span').text(department.head_phone || '-');
                    } else {
                        $('#departmentHeadContainer').hide();
                    }
                    
                    $('#viewProgramsBtn').attr('href', 'college_programs.php?department_id=' + departmentId);
                }
            });
            
            // مودال تعديل القسم
            $('#editDepartmentModal').on('show.bs.modal', function(event) {
                const button = $(event.relatedTarget);
                const departmentId = button.data('department-id');
                
                // هنا يمكن إضافة طلب AJAX للحصول على بيانات القسم
                // لأغراض العرض، سنستخدم بيانات وهمية
                
                const departments = <?php echo json_encode($departments); ?>;
                const department = departments.find(d => d.id == departmentId);
                
                if (department) {
                    $('#editDepartmentId').val(department.id);
                    $('#editName').val(department.name);
                    $('#editCode').val(department.code);
                    $('#editDescription').val(department.description);
                    $('#editHeadId').val(department.head_id || '');
                    $('#editStatus').val(department.status);
                }
            });
            
            // مودال حذف القسم
            $('#deleteDepartmentModal').on('show.bs.modal', function(event) {
                const button = $(event.relatedTarget);
                const departmentId = button.data('department-id');
                const departmentName = button.data('department-name');
                
                $('#deleteDepartmentId').val(departmentId);
                $('#deleteDepartmentName').text(departmentName);
            });
        });
    </script>
</body>
</html>
