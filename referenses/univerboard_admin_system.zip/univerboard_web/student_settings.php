<?php
/**
 * صفحة إعدادات الطالب في نظام UniverBoard
 * تتيح للطالب تخصيص إعدادات حسابه والتفضيلات الشخصية
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول الطالب
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات الطالب
$student_id = $_SESSION['user_id'];
$db = get_db_connection();
$student = get_student_info($db, $student_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// معالجة تحديث الإعدادات
$success_message = '';
$error_message = '';

// معالجة تحديث إعدادات اللغة والمظهر
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_appearance'])) {
    $new_lang = filter_input(INPUT_POST, 'language', FILTER_SANITIZE_STRING);
    $new_theme = filter_input(INPUT_POST, 'theme', FILTER_SANITIZE_STRING);
    
    // التحقق من صحة القيم
    if (in_array($new_lang, ['ar', 'en']) && in_array($new_theme, ['light', 'dark'])) {
        // تحديث ملفات تعريف الارتباط
        setcookie('lang', $new_lang, time() + 365 * 24 * 60 * 60, '/');
        setcookie('theme', $new_theme, time() + 365 * 24 * 60 * 60, '/');
        
        // تحديث المتغيرات
        $lang = $new_lang;
        $theme = $new_theme;
        
        $success_message = t('appearance_settings_updated');
    } else {
        $error_message = t('invalid_appearance_settings');
    }
}

// معالجة تحديث إعدادات الإشعارات
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_notifications'])) {
    $email_notifications = isset($_POST['email_notifications']) ? 1 : 0;
    $sms_notifications = isset($_POST['sms_notifications']) ? 1 : 0;
    $browser_notifications = isset($_POST['browser_notifications']) ? 1 : 0;
    
    // تحديث إعدادات الإشعارات في قاعدة البيانات
    $update_result = update_student_notification_settings($db, $student_id, $email_notifications, $sms_notifications, $browser_notifications);
    
    if ($update_result) {
        $success_message = t('notification_settings_updated');
    } else {
        $error_message = t('notification_settings_update_failed');
    }
}

// معالجة تحديث إعدادات الخصوصية
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_privacy'])) {
    $profile_visibility = filter_input(INPUT_POST, 'profile_visibility', FILTER_SANITIZE_STRING);
    $show_email = isset($_POST['show_email']) ? 1 : 0;
    $show_phone = isset($_POST['show_phone']) ? 1 : 0;
    
    // تحديث إعدادات الخصوصية في قاعدة البيانات
    $update_result = update_student_privacy_settings($db, $student_id, $profile_visibility, $show_email, $show_phone);
    
    if ($update_result) {
        $success_message = t('privacy_settings_updated');
    } else {
        $error_message = t('privacy_settings_update_failed');
    }
}

// معالجة تحديث إعدادات الأمان
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_security'])) {
    $two_factor_auth = isset($_POST['two_factor_auth']) ? 1 : 0;
    $login_notifications = isset($_POST['login_notifications']) ? 1 : 0;
    
    // تحديث إعدادات الأمان في قاعدة البيانات
    $update_result = update_student_security_settings($db, $student_id, $two_factor_auth, $login_notifications);
    
    if ($update_result) {
        $success_message = t('security_settings_updated');
    } else {
        $error_message = t('security_settings_update_failed');
    }
}

// الحصول على إعدادات الطالب الحالية
$student_settings = get_student_settings($db, $student_id);

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('settings'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .settings-container {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .theme-dark .settings-container {
            background-color: #212529;
        }
        
        .settings-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .settings-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .settings-title {
            margin-bottom: 0.5rem;
        }
        
        .settings-subtitle {
            color: var(--gray-color);
        }
        
        .settings-body {
            padding: 1.5rem;
        }
        
        .settings-section {
            margin-bottom: 2rem;
        }
        
        .settings-section:last-child {
            margin-bottom: 0;
        }
        
        .settings-section-title {
            font-weight: 600;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .settings-section-title {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .settings-form-group {
            margin-bottom: 1.5rem;
        }
        
        .settings-form-label {
            font-weight: 500;
            margin-bottom: 0.5rem;
            display: block;
        }
        
        .settings-form-text {
            color: var(--gray-color);
            font-size: 0.9rem;
            margin-top: 0.25rem;
        }
        
        .settings-form-control {
            border-radius: 0.25rem;
            padding: 0.75rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
            width: 100%;
        }
        
        .theme-dark .settings-form-control {
            background-color: #2c3034;
            border-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .settings-form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(0, 48, 73, 0.25);
        }
        
        .settings-form-select {
            border-radius: 0.25rem;
            padding: 0.75rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
            width: 100%;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' class='bi bi-chevron-down' viewBox='0 0 16 16'%3E%3Cpath fill-rule='evenodd' d='M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 16px 12px;
        }
        
        [dir="rtl"] .settings-form-select {
            background-position: left 0.75rem center;
        }
        
        .theme-dark .settings-form-select {
            background-color: #2c3034;
            border-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .settings-form-submit {
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 0.25rem;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: all 0.2s ease;
        }
        
        .settings-form-submit:hover {
            background-color: var(--secondary-color);
        }
        
        .settings-form-switch {
            display: flex;
            align-items: center;
        }
        
        .settings-form-switch .form-check-input {
            width: 3rem;
            height: 1.5rem;
            margin-top: 0;
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .settings-form-switch .form-check-input {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .settings-form-switch .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .settings-form-switch .form-check-label {
            font-weight: 500;
        }
        
        .settings-form-radio {
            margin-bottom: 0.5rem;
        }
        
        .settings-form-radio .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .settings-form-radio .form-check-label {
            font-weight: 500;
        }
        
        .settings-theme-preview {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }
        
        .settings-theme-option {
            flex: 1;
            border-radius: 0.5rem;
            overflow: hidden;
            border: 2px solid transparent;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .settings-theme-option.active {
            border-color: var(--primary-color);
        }
        
        .settings-theme-option-light {
            background-color: white;
            color: #212529;
        }
        
        .settings-theme-option-dark {
            background-color: #212529;
            color: white;
        }
        
        .settings-theme-header {
            padding: 0.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .settings-theme-option-dark .settings-theme-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .settings-theme-body {
            padding: 0.5rem;
        }
        
        .settings-theme-title {
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 0.25rem;
        }
        
        .settings-theme-text {
            font-size: 0.8rem;
            opacity: 0.7;
        }
        
        .settings-language-option {
            display: flex;
            align-items: center;
            padding: 0.75rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 0.5rem;
            margin-bottom: 0.5rem;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .theme-dark .settings-language-option {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .settings-language-option:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .theme-dark .settings-language-option:hover {
            background-color: rgba(255, 255, 255, 0.05);
        }
        
        .settings-language-option.active {
            border-color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
        }
        
        .theme-dark .settings-language-option.active {
            background-color: rgba(102, 155, 188, 0.05);
        }
        
        .settings-language-flag {
            width: 30px;
            height: 20px;
            margin-right: 0.75rem;
            border-radius: 2px;
            object-fit: cover;
        }
        
        [dir="rtl"] .settings-language-flag {
            margin-right: 0;
            margin-left: 0.75rem;
        }
        
        .settings-language-name {
            font-weight: 500;
        }
        
        .settings-language-native {
            font-size: 0.8rem;
            color: var(--gray-color);
            margin-left: 0.5rem;
        }
        
        [dir="rtl"] .settings-language-native {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .settings-language-radio {
            margin-left: auto;
        }
        
        [dir="rtl"] .settings-language-radio {
            margin-left: 0;
            margin-right: auto;
        }
        
        .settings-danger-zone {
            background-color: rgba(220, 53, 69, 0.1);
            border-radius: 0.5rem;
            padding: 1.5rem;
        }
        
        .settings-danger-title {
            color: #dc3545;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .settings-danger-text {
            margin-bottom: 1rem;
        }
        
        .settings-danger-button {
            background-color: #dc3545;
            color: white;
            border: none;
            border-radius: 0.25rem;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: all 0.2s ease;
        }
        
        .settings-danger-button:hover {
            background-color: #bb2d3b;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="student_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="student_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-book"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم إضافة محتوى جديد في مقرر برمجة الويب</p>
                                    <small class="text-muted">منذ 10 دقائق</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-tasks"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تذكير: موعد تسليم واجب قواعد البيانات غداً</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-success text-white rounded-circle">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تصحيح واجب البرمجة المتقدمة</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user1.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. محمد أحمد</p>
                                    <small class="text-muted">هل لديك استفسارات حول المشروع النهائي؟</small>
                                    <small class="text-muted d-block">منذ 15 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user2.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">أ. سارة خالد</p>
                                    <small class="text-muted">تم تحديد موعد المراجعة النهائية للاختبار</small>
                                    <small class="text-muted d-block">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $student['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $student['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $student['name']; ?></h6>
                            <small><?php echo $student['student_id']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="student_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="student_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <div>
                <h1 class="h3"><?php echo t('settings'); ?></h1>
                <p class="text-muted"><?php echo t('settings_subtitle'); ?></p>
            </div>
        </div>
        
        <?php if ($success_message): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="list-group">
                    <a href="#appearance" class="list-group-item list-group-item-action active" data-bs-toggle="list">
                        <i class="fas fa-palette me-2"></i> <?php echo t('appearance'); ?>
                    </a>
                    <a href="#notifications" class="list-group-item list-group-item-action" data-bs-toggle="list">
                        <i class="fas fa-bell me-2"></i> <?php echo t('notifications'); ?>
                    </a>
                    <a href="#privacy" class="list-group-item list-group-item-action" data-bs-toggle="list">
                        <i class="fas fa-user-shield me-2"></i> <?php echo t('privacy'); ?>
                    </a>
                    <a href="#security" class="list-group-item list-group-item-action" data-bs-toggle="list">
                        <i class="fas fa-lock me-2"></i> <?php echo t('security'); ?>
                    </a>
                    <a href="#account" class="list-group-item list-group-item-action" data-bs-toggle="list">
                        <i class="fas fa-user-cog me-2"></i> <?php echo t('account'); ?>
                    </a>
                </div>
            </div>
            
            <div class="col-md-9">
                <div class="tab-content">
                    <!-- إعدادات المظهر -->
                    <div class="tab-pane fade show active" id="appearance">
                        <div class="settings-container">
                            <div class="settings-header">
                                <h2 class="settings-title"><?php echo t('appearance_settings'); ?></h2>
                                <p class="settings-subtitle"><?php echo t('appearance_settings_subtitle'); ?></p>
                            </div>
                            <div class="settings-body">
                                <form action="" method="post">
                                    <div class="settings-section">
                                        <h3 class="settings-section-title"><?php echo t('theme'); ?></h3>
                                        <p class="settings-form-text"><?php echo t('theme_description'); ?></p>
                                        
                                        <div class="settings-theme-preview">
                                            <div class="settings-theme-option settings-theme-option-light <?php echo $theme === 'light' ? 'active' : ''; ?>" data-theme="light">
                                                <div class="settings-theme-header">
                                                    <div class="settings-theme-title"><?php echo t('light_theme'); ?></div>
                                                </div>
                                                <div class="settings-theme-body">
                                                    <div class="settings-theme-text"><?php echo t('light_theme_description'); ?></div>
                                                </div>
                                            </div>
                                            
                                            <div class="settings-theme-option settings-theme-option-dark <?php echo $theme === 'dark' ? 'active' : ''; ?>" data-theme="dark">
                                                <div class="settings-theme-header">
                                                    <div class="settings-theme-title"><?php echo t('dark_theme'); ?></div>
                                                </div>
                                                <div class="settings-theme-body">
                                                    <div class="settings-theme-text"><?php echo t('dark_theme_description'); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <input type="hidden" name="theme" id="themeInput" value="<?php echo $theme; ?>">
                                    </div>
                                    
                                    <div class="settings-section">
                                        <h3 class="settings-section-title"><?php echo t('language'); ?></h3>
                                        <p class="settings-form-text"><?php echo t('language_description'); ?></p>
                                        
                                        <div class="settings-language-option <?php echo $lang === 'ar' ? 'active' : ''; ?>" data-lang="ar">
                                            <img src="assets/images/flags/ar.png" alt="العربية" class="settings-language-flag">
                                            <div class="settings-language-name">العربية <span class="settings-language-native">(Arabic)</span></div>
                                            <div class="settings-language-radio">
                                                <input class="form-check-input" type="radio" name="language" id="language_ar" value="ar" <?php echo $lang === 'ar' ? 'checked' : ''; ?>>
                                            </div>
                                        </div>
                                        
                                        <div class="settings-language-option <?php echo $lang === 'en' ? 'active' : ''; ?>" data-lang="en">
                                            <img src="assets/images/flags/en.png" alt="English" class="settings-language-flag">
                                            <div class="settings-language-name">English <span class="settings-language-native">(الإنجليزية)</span></div>
                                            <div class="settings-language-radio">
                                                <input class="form-check-input" type="radio" name="language" id="language_en" value="en" <?php echo $lang === 'en' ? 'checked' : ''; ?>>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="settings-form-group">
                                        <button type="submit" name="update_appearance" class="btn settings-form-submit">
                                            <?php echo t('save_changes'); ?>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- إعدادات الإشعارات -->
                    <div class="tab-pane fade" id="notifications">
                        <div class="settings-container">
                            <div class="settings-header">
                                <h2 class="settings-title"><?php echo t('notification_settings'); ?></h2>
                                <p class="settings-subtitle"><?php echo t('notification_settings_subtitle'); ?></p>
                            </div>
                            <div class="settings-body">
                                <form action="" method="post">
                                    <div class="settings-section">
                                        <h3 class="settings-section-title"><?php echo t('notification_channels'); ?></h3>
                                        
                                        <div class="settings-form-group">
                                            <div class="form-check form-switch settings-form-switch">
                                                <input class="form-check-input" type="checkbox" id="email_notifications" name="email_notifications" <?php echo isset($student_settings['email_notifications']) && $student_settings['email_notifications'] ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="email_notifications">
                                                    <?php echo t('email_notifications'); ?>
                                                </label>
                                            </div>
                                            <p class="settings-form-text"><?php echo t('email_notifications_description'); ?></p>
                                        </div>
                                        
                                        <div class="settings-form-group">
                                            <div class="form-check form-switch settings-form-switch">
                                                <input class="form-check-input" type="checkbox" id="sms_notifications" name="sms_notifications" <?php echo isset($student_settings['sms_notifications']) && $student_settings['sms_notifications'] ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="sms_notifications">
                                                    <?php echo t('sms_notifications'); ?>
                                                </label>
                                            </div>
                                            <p class="settings-form-text"><?php echo t('sms_notifications_description'); ?></p>
                                        </div>
                                        
                                        <div class="settings-form-group">
                                            <div class="form-check form-switch settings-form-switch">
                                                <input class="form-check-input" type="checkbox" id="browser_notifications" name="browser_notifications" <?php echo isset($student_settings['browser_notifications']) && $student_settings['browser_notifications'] ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="browser_notifications">
                                                    <?php echo t('browser_notifications'); ?>
                                                </label>
                                            </div>
                                            <p class="settings-form-text"><?php echo t('browser_notifications_description'); ?></p>
                                        </div>
                                    </div>
                                    
                                    <div class="settings-section">
                                        <h3 class="settings-section-title"><?php echo t('notification_types'); ?></h3>
                                        
                                        <div class="settings-form-group">
                                            <div class="form-check form-switch settings-form-switch">
                                                <input class="form-check-input" type="checkbox" id="course_notifications" name="course_notifications" checked>
                                                <label class="form-check-label" for="course_notifications">
                                                    <?php echo t('course_notifications'); ?>
                                                </label>
                                            </div>
                                            <p class="settings-form-text"><?php echo t('course_notifications_description'); ?></p>
                                        </div>
                                        
                                        <div class="settings-form-group">
                                            <div class="form-check form-switch settings-form-switch">
                                                <input class="form-check-input" type="checkbox" id="assignment_notifications" name="assignment_notifications" checked>
                                                <label class="form-check-label" for="assignment_notifications">
                                                    <?php echo t('assignment_notifications'); ?>
                                                </label>
                                            </div>
                                            <p class="settings-form-text"><?php echo t('assignment_notifications_description'); ?></p>
                                        </div>
                                        
                                        <div class="settings-form-group">
                                            <div class="form-check form-switch settings-form-switch">
                                                <input class="form-check-input" type="checkbox" id="grade_notifications" name="grade_notifications" checked>
                                                <label class="form-check-label" for="grade_notifications">
                                                    <?php echo t('grade_notifications'); ?>
                                                </label>
                                            </div>
                                            <p class="settings-form-text"><?php echo t('grade_notifications_description'); ?></p>
                                        </div>
                                        
                                        <div class="settings-form-group">
                                            <div class="form-check form-switch settings-form-switch">
                                                <input class="form-check-input" type="checkbox" id="forum_notifications" name="forum_notifications" checked>
                                                <label class="form-check-label" for="forum_notifications">
                                                    <?php echo t('forum_notifications'); ?>
                                                </label>
                                            </div>
                                            <p class="settings-form-text"><?php echo t('forum_notifications_description'); ?></p>
                                        </div>
                                        
                                        <div class="settings-form-group">
                                            <div class="form-check form-switch settings-form-switch">
                                                <input class="form-check-input" type="checkbox" id="message_notifications" name="message_notifications" checked>
                                                <label class="form-check-label" for="message_notifications">
                                                    <?php echo t('message_notifications'); ?>
                                                </label>
                                            </div>
                                            <p class="settings-form-text"><?php echo t('message_notifications_description'); ?></p>
                                        </div>
                                    </div>
                                    
                                    <div class="settings-form-group">
                                        <button type="submit" name="update_notifications" class="btn settings-form-submit">
                                            <?php echo t('save_changes'); ?>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- إعدادات الخصوصية -->
                    <div class="tab-pane fade" id="privacy">
                        <div class="settings-container">
                            <div class="settings-header">
                                <h2 class="settings-title"><?php echo t('privacy_settings'); ?></h2>
                                <p class="settings-subtitle"><?php echo t('privacy_settings_subtitle'); ?></p>
                            </div>
                            <div class="settings-body">
                                <form action="" method="post">
                                    <div class="settings-section">
                                        <h3 class="settings-section-title"><?php echo t('profile_visibility'); ?></h3>
                                        
                                        <div class="settings-form-group">
                                            <label class="settings-form-label"><?php echo t('who_can_see_profile'); ?></label>
                                            
                                            <div class="settings-form-radio">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="profile_visibility" id="profile_visibility_public" value="public" <?php echo isset($student_settings['profile_visibility']) && $student_settings['profile_visibility'] === 'public' ? 'checked' : ''; ?>>
                                                    <label class="form-check-label" for="profile_visibility_public">
                                                        <?php echo t('public'); ?>
                                                    </label>
                                                </div>
                                                <p class="settings-form-text"><?php echo t('public_profile_description'); ?></p>
                                            </div>
                                            
                                            <div class="settings-form-radio">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="profile_visibility" id="profile_visibility_university" value="university" <?php echo isset($student_settings['profile_visibility']) && $student_settings['profile_visibility'] === 'university' ? 'checked' : ''; ?>>
                                                    <label class="form-check-label" for="profile_visibility_university">
                                                        <?php echo t('university_only'); ?>
                                                    </label>
                                                </div>
                                                <p class="settings-form-text"><?php echo t('university_profile_description'); ?></p>
                                            </div>
                                            
                                            <div class="settings-form-radio">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="profile_visibility" id="profile_visibility_private" value="private" <?php echo isset($student_settings['profile_visibility']) && $student_settings['profile_visibility'] === 'private' ? 'checked' : ''; ?>>
                                                    <label class="form-check-label" for="profile_visibility_private">
                                                        <?php echo t('private'); ?>
                                                    </label>
                                                </div>
                                                <p class="settings-form-text"><?php echo t('private_profile_description'); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="settings-section">
                                        <h3 class="settings-section-title"><?php echo t('contact_information'); ?></h3>
                                        
                                        <div class="settings-form-group">
                                            <div class="form-check form-switch settings-form-switch">
                                                <input class="form-check-input" type="checkbox" id="show_email" name="show_email" <?php echo isset($student_settings['show_email']) && $student_settings['show_email'] ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="show_email">
                                                    <?php echo t('show_email'); ?>
                                                </label>
                                            </div>
                                            <p class="settings-form-text"><?php echo t('show_email_description'); ?></p>
                                        </div>
                                        
                                        <div class="settings-form-group">
                                            <div class="form-check form-switch settings-form-switch">
                                                <input class="form-check-input" type="checkbox" id="show_phone" name="show_phone" <?php echo isset($student_settings['show_phone']) && $student_settings['show_phone'] ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="show_phone">
                                                    <?php echo t('show_phone'); ?>
                                                </label>
                                            </div>
                                            <p class="settings-form-text"><?php echo t('show_phone_description'); ?></p>
                                        </div>
                                    </div>
                                    
                                    <div class="settings-form-group">
                                        <button type="submit" name="update_privacy" class="btn settings-form-submit">
                                            <?php echo t('save_changes'); ?>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- إعدادات الأمان -->
                    <div class="tab-pane fade" id="security">
                        <div class="settings-container">
                            <div class="settings-header">
                                <h2 class="settings-title"><?php echo t('security_settings'); ?></h2>
                                <p class="settings-subtitle"><?php echo t('security_settings_subtitle'); ?></p>
                            </div>
                            <div class="settings-body">
                                <form action="" method="post">
                                    <div class="settings-section">
                                        <h3 class="settings-section-title"><?php echo t('two_factor_authentication'); ?></h3>
                                        
                                        <div class="settings-form-group">
                                            <div class="form-check form-switch settings-form-switch">
                                                <input class="form-check-input" type="checkbox" id="two_factor_auth" name="two_factor_auth" <?php echo isset($student_settings['two_factor_auth']) && $student_settings['two_factor_auth'] ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="two_factor_auth">
                                                    <?php echo t('enable_two_factor_auth'); ?>
                                                </label>
                                            </div>
                                            <p class="settings-form-text"><?php echo t('two_factor_auth_description'); ?></p>
                                        </div>
                                    </div>
                                    
                                    <div class="settings-section">
                                        <h3 class="settings-section-title"><?php echo t('login_notifications'); ?></h3>
                                        
                                        <div class="settings-form-group">
                                            <div class="form-check form-switch settings-form-switch">
                                                <input class="form-check-input" type="checkbox" id="login_notifications" name="login_notifications" <?php echo isset($student_settings['login_notifications']) && $student_settings['login_notifications'] ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="login_notifications">
                                                    <?php echo t('enable_login_notifications'); ?>
                                                </label>
                                            </div>
                                            <p class="settings-form-text"><?php echo t('login_notifications_description'); ?></p>
                                        </div>
                                    </div>
                                    
                                    <div class="settings-section">
                                        <h3 class="settings-section-title"><?php echo t('session_management'); ?></h3>
                                        
                                        <div class="settings-form-group">
                                            <p><?php echo t('active_sessions'); ?></p>
                                            
                                            <div class="card mb-3">
                                                <div class="card-body">
                                                    <div class="d-flex justify-content-between align-items-center">
                                                        <div>
                                                            <h5 class="card-title"><?php echo t('current_session'); ?></h5>
                                                            <p class="card-text text-muted">
                                                                <i class="fas fa-desktop me-1"></i> <?php echo $_SERVER['HTTP_USER_AGENT']; ?><br>
                                                                <i class="fas fa-map-marker-alt me-1"></i> الرياض، المملكة العربية السعودية<br>
                                                                <i class="fas fa-clock me-1"></i> <?php echo date('Y-m-d H:i:s'); ?>
                                                            </p>
                                                        </div>
                                                        <span class="badge bg-success"><?php echo t('active'); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <button type="button" class="btn btn-outline-danger">
                                                <?php echo t('logout_all_devices'); ?>
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <div class="settings-form-group">
                                        <button type="submit" name="update_security" class="btn settings-form-submit">
                                            <?php echo t('save_changes'); ?>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- إعدادات الحساب -->
                    <div class="tab-pane fade" id="account">
                        <div class="settings-container">
                            <div class="settings-header">
                                <h2 class="settings-title"><?php echo t('account_settings'); ?></h2>
                                <p class="settings-subtitle"><?php echo t('account_settings_subtitle'); ?></p>
                            </div>
                            <div class="settings-body">
                                <div class="settings-section">
                                    <h3 class="settings-section-title"><?php echo t('account_information'); ?></h3>
                                    
                                    <div class="settings-form-group">
                                        <label class="settings-form-label"><?php echo t('student_id'); ?></label>
                                        <input type="text" class="form-control settings-form-control" value="<?php echo $student['student_id']; ?>" readonly>
                                    </div>
                                    
                                    <div class="settings-form-group">
                                        <label class="settings-form-label"><?php echo t('account_type'); ?></label>
                                        <input type="text" class="form-control settings-form-control" value="<?php echo t('student'); ?>" readonly>
                                    </div>
                                    
                                    <div class="settings-form-group">
                                        <label class="settings-form-label"><?php echo t('account_status'); ?></label>
                                        <input type="text" class="form-control settings-form-control" value="<?php echo t('active'); ?>" readonly>
                                    </div>
                                    
                                    <div class="settings-form-group">
                                        <label class="settings-form-label"><?php echo t('registration_date'); ?></label>
                                        <input type="text" class="form-control settings-form-control" value="2022-09-01" readonly>
                                    </div>
                                </div>
                                
                                <div class="settings-section">
                                    <h3 class="settings-section-title"><?php echo t('data_export'); ?></h3>
                                    
                                    <div class="settings-form-group">
                                        <p><?php echo t('data_export_description'); ?></p>
                                        <button type="button" class="btn btn-outline-primary">
                                            <i class="fas fa-download me-1"></i> <?php echo t('export_data'); ?>
                                        </button>
                                    </div>
                                </div>
                                
                                <div class="settings-section">
                                    <h3 class="settings-section-title"><?php echo t('danger_zone'); ?></h3>
                                    
                                    <div class="settings-danger-zone">
                                        <h4 class="settings-danger-title"><?php echo t('deactivate_account'); ?></h4>
                                        <p class="settings-danger-text"><?php echo t('deactivate_account_description'); ?></p>
                                        <button type="button" class="btn settings-danger-button" data-bs-toggle="modal" data-bs-target="#deactivateAccountModal">
                                            <?php echo t('deactivate_account'); ?>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال تعطيل الحساب -->
    <div class="modal fade" id="deactivateAccountModal" tabindex="-1" aria-labelledby="deactivateAccountModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deactivateAccountModalLabel"><?php echo t('deactivate_account'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p><?php echo t('deactivate_account_confirmation'); ?></p>
                    <div class="mb-3">
                        <label for="deactivateReason" class="form-label"><?php echo t('deactivate_reason'); ?></label>
                        <select class="form-select" id="deactivateReason">
                            <option value=""><?php echo t('select_reason'); ?></option>
                            <option value="temporary"><?php echo t('temporary_leave'); ?></option>
                            <option value="graduated"><?php echo t('graduated'); ?></option>
                            <option value="transferred"><?php echo t('transferred'); ?></option>
                            <option value="other"><?php echo t('other'); ?></option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="deactivatePassword" class="form-label"><?php echo t('confirm_password'); ?></label>
                        <input type="password" class="form-control" id="deactivatePassword" placeholder="<?php echo t('enter_password'); ?>">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="button" class="btn btn-danger"><?php echo t('deactivate'); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // تحديد خيار المظهر
            document.querySelectorAll('.settings-theme-option').forEach(function(option) {
                option.addEventListener('click', function() {
                    // إزالة الفئة النشطة من جميع الخيارات
                    document.querySelectorAll('.settings-theme-option').forEach(function(opt) {
                        opt.classList.remove('active');
                    });
                    
                    // إضافة الفئة النشطة إلى الخيار المحدد
                    this.classList.add('active');
                    
                    // تحديث قيمة الإدخال المخفي
                    document.getElementById('themeInput').value = this.getAttribute('data-theme');
                });
            });
            
            // تحديد خيار اللغة
            document.querySelectorAll('.settings-language-option').forEach(function(option) {
                option.addEventListener('click', function() {
                    // إزالة الفئة النشطة من جميع الخيارات
                    document.querySelectorAll('.settings-language-option').forEach(function(opt) {
                        opt.classList.remove('active');
                    });
                    
                    // إضافة الفئة النشطة إلى الخيار المحدد
                    this.classList.add('active');
                    
                    // تحديد زر الراديو المقابل
                    const lang = this.getAttribute('data-lang');
                    document.getElementById(`language_${lang}`).checked = true;
                });
            });
            
            // زر تبديل المظهر
            document.getElementById('themeToggle').addEventListener('click', function() {
                const currentTheme = document.body.className.includes('theme-dark') ? 'dark' : 'light';
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.cookie = `theme=${newTheme}; path=/; max-age=31536000`;
                document.body.className = `theme-${newTheme}`;
                
                this.innerHTML = `<i class="fas fa-${newTheme === 'dark' ? 'sun' : 'moon'}"></i>`;
                
                // تحديث خيار المظهر في الإعدادات
                document.querySelectorAll('.settings-theme-option').forEach(function(option) {
                    option.classList.remove('active');
                });
                document.querySelector(`.settings-theme-option-${newTheme}`).classList.add('active');
                document.getElementById('themeInput').value = newTheme;
            });
        });
    </script>
</body>
</html>
