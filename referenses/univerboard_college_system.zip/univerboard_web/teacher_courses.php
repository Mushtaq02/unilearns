<?php
/**
 * صفحة إدارة المقررات للمعلم في نظام UniverBoard
 * تتيح للمعلم عرض وإدارة المقررات التي يدرسها
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول المعلم
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'teacher') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات المعلم
$teacher_id = $_SESSION['user_id'];
$db = get_db_connection();
$teacher = get_teacher_info($db, $teacher_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// الحصول على المقررات التي يدرسها المعلم
$courses = get_teacher_courses($db, $teacher_id);

// معالجة البحث والتصفية
$search_query = isset($_GET['search']) ? filter_input(INPUT_GET, 'search', FILTER_SANITIZE_STRING) : '';
$filter_semester = isset($_GET['semester']) ? filter_input(INPUT_GET, 'semester', FILTER_SANITIZE_STRING) : '';
$filter_status = isset($_GET['status']) ? filter_input(INPUT_GET, 'status', FILTER_SANITIZE_STRING) : '';

// تطبيق البحث والتصفية على المقررات
if (!empty($search_query) || !empty($filter_semester) || !empty($filter_status)) {
    $filtered_courses = [];
    foreach ($courses as $course) {
        $match_search = empty($search_query) || stripos($course['name'], $search_query) !== false || stripos($course['code'], $search_query) !== false;
        $match_semester = empty($filter_semester) || $course['semester'] === $filter_semester;
        $match_status = empty($filter_status) || $course['status'] === $filter_status;
        
        if ($match_search && $match_semester && $match_status) {
            $filtered_courses[] = $course;
        }
    }
    $courses = $filtered_courses;
}

// الحصول على قائمة الفصول الدراسية المتاحة للتصفية
$semesters = [];
$statuses = [];
foreach (get_teacher_courses($db, $teacher_id) as $course) {
    if (!in_array($course['semester'], $semesters)) {
        $semesters[] = $course['semester'];
    }
    if (!in_array($course['status'], $statuses)) {
        $statuses[] = $course['status'];
    }
}

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('my_courses'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .course-card {
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 1.5rem;
            transition: all 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .course-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
        }
        
        .course-card-header {
            padding: 1.25rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .course-card-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .course-card-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }
        
        .course-card-body {
            padding: 1.25rem;
            flex-grow: 1;
        }
        
        .course-card-footer {
            padding: 1rem 1.25rem;
            background-color: rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .theme-dark .course-card-footer {
            background-color: rgba(255, 255, 255, 0.05);
        }
        
        .course-card-stat {
            display: flex;
            align-items: center;
        }
        
        .course-card-stat i {
            margin-right: 0.5rem;
            opacity: 0.7;
        }
        
        [dir="rtl"] .course-card-stat i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .course-card-badge {
            position: absolute;
            top: 0;
            right: 1rem;
            transform: translateY(-50%);
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        [dir="rtl"] .course-card-badge {
            right: auto;
            left: 1rem;
        }
        
        .course-card-badge.active {
            background-color: #28a745;
            color: white;
        }
        
        .course-card-badge.upcoming {
            background-color: #ffc107;
            color: #212529;
        }
        
        .course-card-badge.completed {
            background-color: #6c757d;
            color: white;
        }
        
        .course-card-badge.archived {
            background-color: #dc3545;
            color: white;
        }
        
        .course-card-actions {
            position: absolute;
            top: 1rem;
            right: 1rem;
        }
        
        [dir="rtl"] .course-card-actions {
            right: auto;
            left: 1rem;
        }
        
        .course-card-actions .dropdown-toggle::after {
            display: none;
        }
        
        .course-card-actions .dropdown-toggle {
            color: white;
            background: none;
            border: none;
            font-size: 1.25rem;
        }
        
        .course-card-actions .dropdown-menu {
            min-width: 200px;
        }
        
        .course-card-actions .dropdown-item {
            padding: 0.5rem 1rem;
            display: flex;
            align-items: center;
        }
        
        .course-card-actions .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .course-card-actions .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .course-card-image {
            height: 150px;
            background-size: cover;
            background-position: center;
            position: relative;
        }
        
        .course-card-image-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.2));
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            padding: 1.25rem;
            color: white;
        }
        
        .course-card-image-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
            font-size: 1.25rem;
        }
        
        .course-card-image-subtitle {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .course-list-item {
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 1rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: stretch;
        }
        
        .course-list-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
        }
        
        .course-list-color {
            width: 10px;
            background-color: var(--primary-color);
        }
        
        .course-list-content {
            padding: 1.25rem;
            flex-grow: 1;
            display: flex;
            align-items: center;
        }
        
        .course-list-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-right: 1.25rem;
            flex-shrink: 0;
        }
        
        [dir="rtl"] .course-list-icon {
            margin-right: 0;
            margin-left: 1.25rem;
        }
        
        .course-list-details {
            flex-grow: 1;
        }
        
        .course-list-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
            font-size: 1.1rem;
        }
        
        .course-list-subtitle {
            font-size: 0.9rem;
            color: var(--gray-color);
            margin-bottom: 0.5rem;
        }
        
        .course-list-stats {
            display: flex;
            align-items: center;
            font-size: 0.85rem;
            color: var(--gray-color);
        }
        
        .course-list-stat {
            display: flex;
            align-items: center;
            margin-right: 1rem;
        }
        
        [dir="rtl"] .course-list-stat {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .course-list-stat i {
            margin-right: 0.5rem;
            opacity: 0.7;
        }
        
        [dir="rtl"] .course-list-stat i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .course-list-actions {
            display: flex;
            align-items: center;
            padding: 1.25rem;
            background-color: rgba(0, 0, 0, 0.02);
        }
        
        .theme-dark .course-list-actions {
            background-color: rgba(255, 255, 255, 0.02);
        }
        
        .course-list-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 600;
            margin-right: 1rem;
        }
        
        [dir="rtl"] .course-list-badge {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .course-list-badge.active {
            background-color: #28a745;
            color: white;
        }
        
        .course-list-badge.upcoming {
            background-color: #ffc107;
            color: #212529;
        }
        
        .course-list-badge.completed {
            background-color: #6c757d;
            color: white;
        }
        
        .course-list-badge.archived {
            background-color: #dc3545;
            color: white;
        }
        
        .filter-card {
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            padding: 1.25rem;
            margin-bottom: 1.5rem;
        }
        
        .filter-title {
            font-weight: 600;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .filter-title {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .filter-group {
            margin-bottom: 1rem;
        }
        
        .filter-group:last-child {
            margin-bottom: 0;
        }
        
        .filter-label {
            font-weight: 500;
            margin-bottom: 0.5rem;
            display: block;
        }
        
        .filter-control {
            width: 100%;
            padding: 0.5rem;
            border-radius: 0.25rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .filter-control {
            background-color: var(--dark-bg);
            border-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .filter-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(0, 48, 73, 0.25);
        }
        
        .filter-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 1rem;
        }
        
        .view-toggle {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .view-toggle-btn {
            padding: 0.5rem 1rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
            background-color: white;
            color: var(--text-color);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .theme-dark .view-toggle-btn {
            background-color: var(--dark-bg);
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .view-toggle-btn:first-child {
            border-top-left-radius: 0.25rem;
            border-bottom-left-radius: 0.25rem;
        }
        
        .view-toggle-btn:last-child {
            border-top-right-radius: 0.25rem;
            border-bottom-right-radius: 0.25rem;
        }
        
        [dir="rtl"] .view-toggle-btn:first-child {
            border-radius: 0;
            border-top-right-radius: 0.25rem;
            border-bottom-right-radius: 0.25rem;
        }
        
        [dir="rtl"] .view-toggle-btn:last-child {
            border-radius: 0;
            border-top-left-radius: 0.25rem;
            border-bottom-left-radius: 0.25rem;
        }
        
        .view-toggle-btn.active {
            background-color: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .view-toggle-btn i {
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .view-toggle-btn i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background-color: rgba(0, 0, 0, 0.02);
            border-radius: 0.5rem;
        }
        
        .theme-dark .empty-state {
            background-color: rgba(255, 255, 255, 0.02);
        }
        
        .empty-state-icon {
            font-size: 4rem;
            color: var(--gray-color);
            margin-bottom: 1.5rem;
        }
        
        .empty-state-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .empty-state-text {
            color: var(--gray-color);
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="teacher_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="teacher_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_students.php">
                        <i class="fas fa-user-graduate"></i> <?php echo t('students'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="teacher_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="teacher_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-user-graduate"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">قام الطالب أحمد محمد بتسليم واجب جديد</p>
                                    <small class="text-muted">منذ 10 دقائق</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-calendar-alt"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تذكير: موعد محاضرة برمجة الويب غداً</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-info text-white rounded-circle">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">رسالة جديدة من رئيس القسم</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="teacher_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/student1.jpg" alt="Student" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">سارة أحمد</p>
                                    <small class="text-muted">هل يمكنني الحصول على مساعدة في المشروع النهائي؟</small>
                                    <small class="text-muted d-block">منذ 15 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/student2.jpg" alt="Student" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">محمد علي</p>
                                    <small class="text-muted">أستاذ، هل يمكنني تأجيل موعد تسليم الواجب؟</small>
                                    <small class="text-muted d-block">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="teacher_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $teacher['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $teacher['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $teacher['name']; ?></h6>
                            <small><?php echo $teacher['title']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="teacher_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="teacher_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <div>
                <h1 class="h3"><?php echo t('my_courses'); ?></h1>
                <p class="text-muted"><?php echo t('manage_your_courses'); ?></p>
            </div>
            <div>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createCourseModal">
                    <i class="fas fa-plus me-1"></i> <?php echo t('create_new_course'); ?>
                </button>
            </div>
        </div>
        
        <!-- أدوات البحث والتصفية -->
        <div class="row mb-4">
            <div class="col-md-8">
                <form action="" method="get" class="d-flex">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="<?php echo t('search_courses'); ?>" name="search" value="<?php echo htmlspecialchars($search_query); ?>">
                        <button class="btn btn-primary" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>
            <div class="col-md-4">
                <div class="view-toggle float-end">
                    <button class="view-toggle-btn active" data-view="grid">
                        <i class="fas fa-th"></i> <?php echo t('grid'); ?>
                    </button>
                    <button class="view-toggle-btn" data-view="list">
                        <i class="fas fa-list"></i> <?php echo t('list'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- فلاتر جانبية -->
            <div class="col-lg-3">
                <div class="filter-card">
                    <h5 class="filter-title"><?php echo t('filters'); ?></h5>
                    <form action="" method="get">
                        <?php if (!empty($search_query)): ?>
                            <input type="hidden" name="search" value="<?php echo htmlspecialchars($search_query); ?>">
                        <?php endif; ?>
                        
                        <div class="filter-group">
                            <label class="filter-label"><?php echo t('semester'); ?></label>
                            <select name="semester" class="filter-control">
                                <option value=""><?php echo t('all_semesters'); ?></option>
                                <?php foreach ($semesters as $semester): ?>
                                    <option value="<?php echo $semester; ?>" <?php echo $filter_semester === $semester ? 'selected' : ''; ?>>
                                        <?php echo $semester; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label class="filter-label"><?php echo t('status'); ?></label>
                            <select name="status" class="filter-control">
                                <option value=""><?php echo t('all_statuses'); ?></option>
                                <?php foreach ($statuses as $status): ?>
                                    <option value="<?php echo $status; ?>" <?php echo $filter_status === $status ? 'selected' : ''; ?>>
                                        <?php echo t($status); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="filter-actions">
                            <button type="submit" class="btn btn-primary btn-sm">
                                <?php echo t('apply_filters'); ?>
                            </button>
                            <a href="teacher_courses.php" class="btn btn-outline-secondary btn-sm">
                                <?php echo t('clear_filters'); ?>
                            </a>
                        </div>
                    </form>
                </div>
                
                <div class="filter-card">
                    <h5 class="filter-title"><?php echo t('quick_stats'); ?></h5>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span><?php echo t('active_courses'); ?></span>
                            <span class="fw-bold">
                                <?php
                                $active_count = 0;
                                foreach (get_teacher_courses($db, $teacher_id) as $course) {
                                    if ($course['status'] === 'active') {
                                        $active_count++;
                                    }
                                }
                                echo $active_count;
                                ?>
                            </span>
                        </div>
                        <div class="progress" style="height: 5px;">
                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo count(get_teacher_courses($db, $teacher_id)) > 0 ? ($active_count / count(get_teacher_courses($db, $teacher_id)) * 100) : 0; ?>%;" aria-valuenow="<?php echo $active_count; ?>" aria-valuemin="0" aria-valuemax="<?php echo count(get_teacher_courses($db, $teacher_id)); ?>"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span><?php echo t('upcoming_courses'); ?></span>
                            <span class="fw-bold">
                                <?php
                                $upcoming_count = 0;
                                foreach (get_teacher_courses($db, $teacher_id) as $course) {
                                    if ($course['status'] === 'upcoming') {
                                        $upcoming_count++;
                                    }
                                }
                                echo $upcoming_count;
                                ?>
                            </span>
                        </div>
                        <div class="progress" style="height: 5px;">
                            <div class="progress-bar bg-warning" role="progressbar" style="width: <?php echo count(get_teacher_courses($db, $teacher_id)) > 0 ? ($upcoming_count / count(get_teacher_courses($db, $teacher_id)) * 100) : 0; ?>%;" aria-valuenow="<?php echo $upcoming_count; ?>" aria-valuemin="0" aria-valuemax="<?php echo count(get_teacher_courses($db, $teacher_id)); ?>"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span><?php echo t('completed_courses'); ?></span>
                            <span class="fw-bold">
                                <?php
                                $completed_count = 0;
                                foreach (get_teacher_courses($db, $teacher_id) as $course) {
                                    if ($course['status'] === 'completed') {
                                        $completed_count++;
                                    }
                                }
                                echo $completed_count;
                                ?>
                            </span>
                        </div>
                        <div class="progress" style="height: 5px;">
                            <div class="progress-bar bg-secondary" role="progressbar" style="width: <?php echo count(get_teacher_courses($db, $teacher_id)) > 0 ? ($completed_count / count(get_teacher_courses($db, $teacher_id)) * 100) : 0; ?>%;" aria-valuenow="<?php echo $completed_count; ?>" aria-valuemin="0" aria-valuemax="<?php echo count(get_teacher_courses($db, $teacher_id)); ?>"></div>
                        </div>
                    </div>
                    
                    <div>
                        <div class="d-flex justify-content-between mb-1">
                            <span><?php echo t('archived_courses'); ?></span>
                            <span class="fw-bold">
                                <?php
                                $archived_count = 0;
                                foreach (get_teacher_courses($db, $teacher_id) as $course) {
                                    if ($course['status'] === 'archived') {
                                        $archived_count++;
                                    }
                                }
                                echo $archived_count;
                                ?>
                            </span>
                        </div>
                        <div class="progress" style="height: 5px;">
                            <div class="progress-bar bg-danger" role="progressbar" style="width: <?php echo count(get_teacher_courses($db, $teacher_id)) > 0 ? ($archived_count / count(get_teacher_courses($db, $teacher_id)) * 100) : 0; ?>%;" aria-valuenow="<?php echo $archived_count; ?>" aria-valuemin="0" aria-valuemax="<?php echo count(get_teacher_courses($db, $teacher_id)); ?>"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- قائمة المقررات -->
            <div class="col-lg-9">
                <?php if (count($courses) > 0): ?>
                    <!-- عرض الشبكة -->
                    <div class="view-content" id="gridView">
                        <div class="row">
                            <?php foreach ($courses as $course): ?>
                                <div class="col-md-6 col-lg-4 mb-4">
                                    <div class="course-card">
                                        <div class="course-card-image" style="background-image: url('<?php echo $course['image'] ?: 'assets/images/course-default.jpg'; ?>');">
                                            <div class="course-card-image-overlay">
                                                <h5 class="course-card-image-title"><?php echo $course['name']; ?></h5>
                                                <div class="course-card-image-subtitle"><?php echo $course['code']; ?></div>
                                            </div>
                                            <div class="course-card-actions">
                                                <div class="dropdown">
                                                    <button class="dropdown-toggle" type="button" id="courseActions<?php echo $course['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="fas fa-ellipsis-v"></i>
                                                    </button>
                                                    <ul class="dropdown-menu" aria-labelledby="courseActions<?php echo $course['id']; ?>">
                                                        <li>
                                                            <a class="dropdown-item" href="teacher_course_details.php?id=<?php echo $course['id']; ?>">
                                                                <i class="fas fa-eye"></i> <?php echo t('view_details'); ?>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a class="dropdown-item" href="teacher_course_edit.php?id=<?php echo $course['id']; ?>">
                                                                <i class="fas fa-edit"></i> <?php echo t('edit_course'); ?>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a class="dropdown-item" href="teacher_course_content.php?id=<?php echo $course['id']; ?>">
                                                                <i class="fas fa-book-open"></i> <?php echo t('manage_content'); ?>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a class="dropdown-item" href="teacher_course_students.php?id=<?php echo $course['id']; ?>">
                                                                <i class="fas fa-user-graduate"></i> <?php echo t('manage_students'); ?>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a class="dropdown-item" href="teacher_course_assignments.php?id=<?php echo $course['id']; ?>">
                                                                <i class="fas fa-tasks"></i> <?php echo t('manage_assignments'); ?>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a class="dropdown-item" href="teacher_course_exams.php?id=<?php echo $course['id']; ?>">
                                                                <i class="fas fa-file-alt"></i> <?php echo t('manage_exams'); ?>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a class="dropdown-item" href="teacher_course_grades.php?id=<?php echo $course['id']; ?>">
                                                                <i class="fas fa-chart-line"></i> <?php echo t('manage_grades'); ?>
                                                            </a>
                                                        </li>
                                                        <li><hr class="dropdown-divider"></li>
                                                        <li>
                                                            <a class="dropdown-item text-danger" href="#" data-bs-toggle="modal" data-bs-target="#deleteCourseModal" data-course-id="<?php echo $course['id']; ?>" data-course-name="<?php echo $course['name']; ?>">
                                                                <i class="fas fa-trash-alt"></i> <?php echo t('delete_course'); ?>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="course-card-body">
                                            <div class="position-relative">
                                                <span class="course-card-badge <?php echo $course['status']; ?>">
                                                    <?php echo t($course['status']); ?>
                                                </span>
                                            </div>
                                            <p class="mt-3"><?php echo substr($course['description'], 0, 100); ?>...</p>
                                            <div class="progress mb-3" style="height: 5px;">
                                                <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo $course['progress']; ?>%;" aria-valuenow="<?php echo $course['progress']; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                            <div class="d-flex justify-content-between">
                                                <small class="text-muted"><?php echo t('progress'); ?>: <?php echo $course['progress']; ?>%</small>
                                                <small class="text-muted"><?php echo $course['weeks_completed']; ?>/<?php echo $course['total_weeks']; ?> <?php echo t('weeks'); ?></small>
                                            </div>
                                        </div>
                                        <div class="course-card-footer">
                                            <div class="course-card-stat">
                                                <i class="fas fa-user-graduate"></i> <?php echo $course['students_count']; ?> <?php echo t('students'); ?>
                                            </div>
                                            <a href="teacher_course_details.php?id=<?php echo $course['id']; ?>" class="btn btn-sm btn-primary"><?php echo t('manage'); ?></a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- عرض القائمة -->
                    <div class="view-content d-none" id="listView">
                        <?php foreach ($courses as $course): ?>
                            <div class="course-list-item">
                                <div class="course-list-color"></div>
                                <div class="course-list-content">
                                    <div class="course-list-icon">
                                        <i class="fas fa-book"></i>
                                    </div>
                                    <div class="course-list-details">
                                        <h5 class="course-list-title"><?php echo $course['name']; ?></h5>
                                        <div class="course-list-subtitle"><?php echo $course['code']; ?> - <?php echo $course['semester']; ?></div>
                                        <div class="course-list-stats">
                                            <div class="course-list-stat">
                                                <i class="fas fa-user-graduate"></i> <?php echo $course['students_count']; ?> <?php echo t('students'); ?>
                                            </div>
                                            <div class="course-list-stat">
                                                <i class="fas fa-tasks"></i> <?php echo $course['assignments_count']; ?> <?php echo t('assignments'); ?>
                                            </div>
                                            <div class="course-list-stat">
                                                <i class="fas fa-calendar-alt"></i> <?php echo $course['weeks_completed']; ?>/<?php echo $course['total_weeks']; ?> <?php echo t('weeks'); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="course-list-actions">
                                    <span class="course-list-badge <?php echo $course['status']; ?>">
                                        <?php echo t($course['status']); ?>
                                    </span>
                                    <a href="teacher_course_details.php?id=<?php echo $course['id']; ?>" class="btn btn-sm btn-primary"><?php echo t('manage'); ?></a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <!-- حالة عدم وجود مقررات -->
                    <div class="empty-state">
                        <div class="empty-state-icon">
                            <i class="fas fa-book"></i>
                        </div>
                        <h3 class="empty-state-title"><?php echo t('no_courses_found'); ?></h3>
                        <p class="empty-state-text"><?php echo t('no_courses_message'); ?></p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createCourseModal">
                            <i class="fas fa-plus me-1"></i> <?php echo t('create_new_course'); ?>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- مودال إنشاء مقرر جديد -->
    <div class="modal fade" id="createCourseModal" tabindex="-1" aria-labelledby="createCourseModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createCourseModalLabel"><?php echo t('create_new_course'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="createCourseForm">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="courseName" class="form-label"><?php echo t('course_name'); ?> <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="courseName" name="name" required>
                            </div>
                            <div class="col-md-6">
                                <label for="courseCode" class="form-label"><?php echo t('course_code'); ?> <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="courseCode" name="code" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="courseSemester" class="form-label"><?php echo t('semester'); ?> <span class="text-danger">*</span></label>
                                <select class="form-select" id="courseSemester" name="semester" required>
                                    <option value=""><?php echo t('select_semester'); ?></option>
                                    <option value="الفصل الأول 2023-2024">الفصل الأول 2023-2024</option>
                                    <option value="الفصل الثاني 2023-2024">الفصل الثاني 2023-2024</option>
                                    <option value="الفصل الصيفي 2023-2024">الفصل الصيفي 2023-2024</option>
                                    <option value="الفصل الأول 2024-2025">الفصل الأول 2024-2025</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="courseStatus" class="form-label"><?php echo t('status'); ?> <span class="text-danger">*</span></label>
                                <select class="form-select" id="courseStatus" name="status" required>
                                    <option value=""><?php echo t('select_status'); ?></option>
                                    <option value="active"><?php echo t('active'); ?></option>
                                    <option value="upcoming"><?php echo t('upcoming'); ?></option>
                                    <option value="completed"><?php echo t('completed'); ?></option>
                                    <option value="archived"><?php echo t('archived'); ?></option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="courseDescription" class="form-label"><?php echo t('description'); ?> <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="courseDescription" name="description" rows="4" required></textarea>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="courseStartDate" class="form-label"><?php echo t('start_date'); ?> <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="courseStartDate" name="start_date" required>
                            </div>
                            <div class="col-md-6">
                                <label for="courseEndDate" class="form-label"><?php echo t('end_date'); ?> <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="courseEndDate" name="end_date" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="courseCredits" class="form-label"><?php echo t('credits'); ?> <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="courseCredits" name="credits" min="1" max="6" required>
                            </div>
                            <div class="col-md-6">
                                <label for="courseCapacity" class="form-label"><?php echo t('capacity'); ?> <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="courseCapacity" name="capacity" min="1" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="courseImage" class="form-label"><?php echo t('course_image'); ?></label>
                            <input type="file" class="form-control" id="courseImage" name="image" accept="image/*">
                            <div class="form-text"><?php echo t('course_image_hint'); ?></div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label"><?php echo t('course_options'); ?></label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="courseVisible" name="visible" checked>
                                <label class="form-check-label" for="courseVisible">
                                    <?php echo t('visible_to_students'); ?>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="courseEnrollmentOpen" name="enrollment_open" checked>
                                <label class="form-check-label" for="courseEnrollmentOpen">
                                    <?php echo t('enrollment_open'); ?>
                                </label>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="button" class="btn btn-primary" id="createCourseBtn"><?php echo t('create_course'); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال حذف مقرر -->
    <div class="modal fade" id="deleteCourseModal" tabindex="-1" aria-labelledby="deleteCourseModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteCourseModalLabel"><?php echo t('delete_course'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p><?php echo t('delete_course_confirmation'); ?> <strong id="deleteCourseNameSpan"></strong>؟</p>
                    <p class="text-danger"><?php echo t('delete_course_warning'); ?></p>
                    <div class="mb-3">
                        <label for="deleteConfirmation" class="form-label"><?php echo t('type_delete_to_confirm'); ?></label>
                        <input type="text" class="form-control" id="deleteConfirmation" placeholder="delete">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="button" class="btn btn-danger" id="deleteCourseBtn" disabled><?php echo t('delete'); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // زر تبديل المظهر
            document.getElementById('themeToggle').addEventListener('click', function() {
                const currentTheme = document.body.className.includes('theme-dark') ? 'dark' : 'light';
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.cookie = `theme=${newTheme}; path=/; max-age=31536000`;
                document.body.className = `theme-${newTheme}`;
                
                this.innerHTML = `<i class="fas fa-${newTheme === 'dark' ? 'sun' : 'moon'}"></i>`;
            });
            
            // تبديل طريقة العرض (شبكة/قائمة)
            document.querySelectorAll('.view-toggle-btn').forEach(button => {
                button.addEventListener('click', function() {
                    // إزالة الفئة النشطة من جميع الأزرار
                    document.querySelectorAll('.view-toggle-btn').forEach(btn => {
                        btn.classList.remove('active');
                    });
                    
                    // إضافة الفئة النشطة إلى الزر المحدد
                    this.classList.add('active');
                    
                    // تحديث طريقة العرض
                    const view = this.getAttribute('data-view');
                    
                    if (view === 'grid') {
                        document.getElementById('gridView').classList.remove('d-none');
                        document.getElementById('listView').classList.add('d-none');
                    } else if (view === 'list') {
                        document.getElementById('gridView').classList.add('d-none');
                        document.getElementById('listView').classList.remove('d-none');
                    }
                });
            });
            
            // مودال حذف مقرر
            const deleteCourseModal = document.getElementById('deleteCourseModal');
            if (deleteCourseModal) {
                deleteCourseModal.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    const courseId = button.getAttribute('data-course-id');
                    const courseName = button.getAttribute('data-course-name');
                    
                    document.getElementById('deleteCourseNameSpan').textContent = courseName;
                    
                    // تعطيل زر الحذف حتى يتم تأكيد الحذف
                    document.getElementById('deleteCourseBtn').disabled = true;
                    document.getElementById('deleteConfirmation').value = '';
                    
                    // تمكين زر الحذف عند كتابة "delete"
                    document.getElementById('deleteConfirmation').addEventListener('input', function() {
                        document.getElementById('deleteCourseBtn').disabled = this.value !== 'delete';
                    });
                    
                    // إجراء الحذف عند النقر على زر الحذف
                    document.getElementById('deleteCourseBtn').onclick = function() {
                        if (document.getElementById('deleteConfirmation').value === 'delete') {
                            // هنا يمكن إضافة كود لحذف المقرر
                            alert('تم حذف المقرر: ' + courseName);
                            
                            // إغلاق المودال
                            const modal = bootstrap.Modal.getInstance(deleteCourseModal);
                            modal.hide();
                        }
                    };
                });
            }
            
            // إنشاء مقرر جديد
            document.getElementById('createCourseBtn').addEventListener('click', function() {
                const form = document.getElementById('createCourseForm');
                
                // التحقق من صحة النموذج
                if (form.checkValidity()) {
                    // هنا يمكن إضافة كود لإنشاء المقرر
                    alert('تم إنشاء المقرر بنجاح!');
                    
                    // إغلاق المودال
                    const modal = bootstrap.Modal.getInstance(document.getElementById('createCourseModal'));
                    modal.hide();
                } else {
                    form.reportValidity();
                }
            });
        });
    </script>
</body>
</html>
