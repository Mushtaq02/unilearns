<?php
/**
 * صفحة المنتدى للطالب في نظام UniverBoard
 * تعرض المنتديات والمواضيع وتتيح المشاركة في النقاشات
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول الطالب
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات الطالب
$student_id = $_SESSION['user_id'];
$db = get_db_connection();
$student = get_student_info($db, $student_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// الحصول على المنتديات المتاحة للطالب
$forums = get_student_forums($db, $student_id);

// الحصول على المواضيع للمنتدى المحدد
$selected_forum_id = isset($_GET['forum_id']) ? intval($_GET['forum_id']) : 0;
$topics = [];
$forum_info = null;

if ($selected_forum_id > 0) {
    $topics = get_forum_topics($db, $selected_forum_id);
    $forum_info = get_forum_info($db, $selected_forum_id);
}

// الحصول على المشاركات للموضوع المحدد
$selected_topic_id = isset($_GET['topic_id']) ? intval($_GET['topic_id']) : 0;
$posts = [];
$topic_info = null;

if ($selected_topic_id > 0) {
    $posts = get_topic_posts($db, $selected_topic_id);
    $topic_info = get_topic_info($db, $selected_topic_id);
    
    // تحديث عدد المشاهدات للموضوع
    update_topic_views($db, $selected_topic_id);
}

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('forums'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .forum-container {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .theme-dark .forum-container {
            background-color: #212529;
        }
        
        .forum-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .forum-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .forum-title {
            margin-bottom: 0.5rem;
        }
        
        .forum-description {
            color: var(--gray-color);
        }
        
        .forum-stats {
            display: flex;
            gap: 1.5rem;
            margin-top: 1rem;
        }
        
        .forum-stat {
            display: flex;
            align-items: center;
        }
        
        .forum-stat i {
            margin-right: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .forum-stat i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .forum-body {
            padding: 1.5rem;
        }
        
        .forum-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .forum-item {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.2s ease;
        }
        
        .theme-dark .forum-item {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .forum-item:last-child {
            border-bottom: none;
        }
        
        .forum-item:hover {
            background-color: rgba(0, 0, 0, 0.02);
        }
        
        .theme-dark .forum-item:hover {
            background-color: rgba(255, 255, 255, 0.02);
        }
        
        .forum-item-header {
            display: flex;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        
        .forum-item-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        
        [dir="rtl"] .forum-item-icon {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .forum-item-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .forum-item-description {
            color: var(--gray-color);
            margin-bottom: 1rem;
        }
        
        .forum-item-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
            color: var(--gray-color);
        }
        
        .forum-item-stats {
            display: flex;
            gap: 1rem;
        }
        
        .forum-item-stat {
            display: flex;
            align-items: center;
        }
        
        .forum-item-stat i {
            margin-right: 0.25rem;
        }
        
        [dir="rtl"] .forum-item-stat i {
            margin-right: 0;
            margin-left: 0.25rem;
        }
        
        .forum-item-last-post {
            display: flex;
            align-items: center;
        }
        
        .forum-item-last-post img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .forum-item-last-post img {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .topic-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .topic-item {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.2s ease;
        }
        
        .theme-dark .topic-item {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .topic-item:last-child {
            border-bottom: none;
        }
        
        .topic-item:hover {
            background-color: rgba(0, 0, 0, 0.02);
        }
        
        .theme-dark .topic-item:hover {
            background-color: rgba(255, 255, 255, 0.02);
        }
        
        .topic-item-header {
            display: flex;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        
        .topic-item-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        
        [dir="rtl"] .topic-item-icon {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .topic-item-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .topic-item-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9rem;
            color: var(--gray-color);
        }
        
        .topic-item-author {
            display: flex;
            align-items: center;
        }
        
        .topic-item-author img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .topic-item-author img {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .topic-item-stats {
            display: flex;
            gap: 1rem;
        }
        
        .topic-item-stat {
            display: flex;
            align-items: center;
        }
        
        .topic-item-stat i {
            margin-right: 0.25rem;
        }
        
        [dir="rtl"] .topic-item-stat i {
            margin-right: 0;
            margin-left: 0.25rem;
        }
        
        .topic-item-last-post {
            display: flex;
            align-items: center;
        }
        
        .topic-item-last-post img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .topic-item-last-post img {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .topic-item-badge {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.8rem;
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .topic-item-badge {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .topic-item-badge.sticky {
            background-color: #dc3545;
            color: white;
        }
        
        .topic-item-badge.announcement {
            background-color: #ffc107;
            color: #212529;
        }
        
        .topic-item-badge.solved {
            background-color: #28a745;
            color: white;
        }
        
        .post-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .post-item {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .post-item {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .post-item:last-child {
            border-bottom: none;
        }
        
        .post-item-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 1rem;
        }
        
        .post-item-author {
            display: flex;
            align-items: center;
        }
        
        .post-item-author img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .post-item-author img {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .post-item-author-name {
            font-weight: 600;
        }
        
        .post-item-author-role {
            font-size: 0.8rem;
            color: var(--gray-color);
        }
        
        .post-item-date {
            font-size: 0.9rem;
            color: var(--gray-color);
        }
        
        .post-item-content {
            margin-bottom: 1rem;
        }
        
        .post-item-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .post-item-actions {
            display: flex;
            gap: 0.5rem;
        }
        
        .post-item-action {
            display: flex;
            align-items: center;
            color: var(--gray-color);
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .post-item-action:hover {
            color: var(--primary-color);
        }
        
        .post-item-action i {
            margin-right: 0.25rem;
        }
        
        [dir="rtl"] .post-item-action i {
            margin-right: 0;
            margin-left: 0.25rem;
        }
        
        .post-item-likes {
            display: flex;
            align-items: center;
        }
        
        .post-item-likes i {
            margin-right: 0.25rem;
            color: #dc3545;
        }
        
        [dir="rtl"] .post-item-likes i {
            margin-right: 0;
            margin-left: 0.25rem;
        }
        
        .post-form {
            padding: 1.5rem;
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .post-form {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .post-form-title {
            margin-bottom: 1rem;
        }
        
        .post-form-actions {
            display: flex;
            justify-content: flex-end;
            margin-top: 1rem;
        }
        
        .breadcrumb-container {
            margin-bottom: 1.5rem;
        }
        
        .breadcrumb-item a {
            color: var(--primary-color);
            text-decoration: none;
        }
        
        .breadcrumb-item.active {
            color: var(--gray-color);
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .search-box {
            position: relative;
            margin-bottom: 1rem;
        }
        
        .search-box input {
            width: 100%;
            padding: 0.75rem 1rem 0.75rem 3rem;
            border: none;
            border-radius: 0.5rem;
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        [dir="rtl"] .search-box input {
            padding: 0.75rem 3rem 0.75rem 1rem;
        }
        
        .theme-dark .search-box input {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .search-box input:focus {
            outline: none;
            box-shadow: 0 0 0 2px rgba(0, 48, 73, 0.2);
        }
        
        .search-box i {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-color);
        }
        
        [dir="rtl"] .search-box i {
            left: auto;
            right: 1rem;
        }
        
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 3rem;
            text-align: center;
        }
        
        .empty-state i {
            font-size: 4rem;
            color: var(--gray-color);
            margin-bottom: 1.5rem;
        }
        
        .empty-state h4 {
            margin-bottom: 1rem;
        }
        
        .empty-state p {
            color: var(--gray-color);
            margin-bottom: 1.5rem;
            max-width: 500px;
        }
        
        .forum-actions {
            display: flex;
            justify-content: space-between;
            margin-bottom: 1.5rem;
        }
        
        .forum-filter {
            display: flex;
            gap: 0.5rem;
        }
        
        .forum-filter .btn {
            border-radius: 2rem;
            padding: 0.5rem 1.5rem;
        }
        
        .forum-filter .btn.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .pagination-container {
            display: flex;
            justify-content: center;
            margin-top: 1.5rem;
        }
        
        .pagination .page-item .page-link {
            color: var(--primary-color);
        }
        
        .pagination .page-item.active .page-link {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        .pagination .page-item.disabled .page-link {
            color: var(--gray-color);
        }
        
        .post-item-attachments {
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .post-item-attachments {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .post-item-attachment {
            display: flex;
            align-items: center;
            padding: 0.5rem;
            background-color: rgba(0, 0, 0, 0.05);
            border-radius: 0.5rem;
            margin-bottom: 0.5rem;
        }
        
        .theme-dark .post-item-attachment {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .post-item-attachment i {
            font-size: 1.5rem;
            margin-right: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .post-item-attachment i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .post-item-attachment-info {
            flex: 1;
        }
        
        .post-item-attachment-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .post-item-attachment-size {
            font-size: 0.8rem;
            color: var(--gray-color);
        }
        
        .post-item-attachment-actions a {
            color: var(--gray-color);
            transition: all 0.2s ease;
        }
        
        .post-item-attachment-actions a:hover {
            color: var(--primary-color);
        }
        
        .post-editor-toolbar {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
            padding: 0.5rem;
            background-color: rgba(0, 0, 0, 0.05);
            border-radius: 0.5rem;
        }
        
        .theme-dark .post-editor-toolbar {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .post-editor-toolbar button {
            width: 40px;
            height: 40px;
            border-radius: 0.25rem;
            display: flex;
            align-items: center;
            justify-content: center;
            background: none;
            border: none;
            color: var(--text-color);
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .post-editor-toolbar button:hover {
            background-color: rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .post-editor-toolbar button:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .post-editor-toolbar .separator {
            width: 1px;
            height: 24px;
            background-color: rgba(0, 0, 0, 0.1);
            margin: 0 0.25rem;
        }
        
        .theme-dark .post-editor-toolbar .separator {
            background-color: rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="student_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="student_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-book"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم إضافة محتوى جديد في مقرر برمجة الويب</p>
                                    <small class="text-muted">منذ 10 دقائق</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-tasks"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تذكير: موعد تسليم واجب قواعد البيانات غداً</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-success text-white rounded-circle">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تصحيح واجب البرمجة المتقدمة</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user1.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. محمد أحمد</p>
                                    <small class="text-muted">هل لديك استفسارات حول المشروع النهائي؟</small>
                                    <small class="text-muted d-block">منذ 15 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user2.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">أ. سارة خالد</p>
                                    <small class="text-muted">تم تحديد موعد المراجعة النهائية للاختبار</small>
                                    <small class="text-muted d-block">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $student['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $student['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $student['name']; ?></h6>
                            <small><?php echo $student['student_id']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="student_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="student_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <div>
                <h1 class="h3"><?php echo t('forums'); ?></h1>
                <p class="text-muted"><?php echo t('forums_subtitle'); ?></p>
            </div>
            <div>
                <?php if ($selected_forum_id > 0 && !$selected_topic_id): ?>
                    <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newTopicModal">
                        <i class="fas fa-plus-circle me-1"></i> <?php echo t('new_topic'); ?>
                    </a>
                <?php elseif ($selected_topic_id > 0): ?>
                    <a href="#replyForm" class="btn btn-primary">
                        <i class="fas fa-reply me-1"></i> <?php echo t('reply'); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- فتات الخبز -->
        <nav aria-label="breadcrumb" class="breadcrumb-container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="student_forums.php"><?php echo t('forums'); ?></a></li>
                <?php if ($selected_forum_id > 0 && $forum_info): ?>
                    <li class="breadcrumb-item <?php echo $selected_topic_id > 0 ? '' : 'active'; ?>">
                        <?php if ($selected_topic_id > 0): ?>
                            <a href="student_forums.php?forum_id=<?php echo $selected_forum_id; ?>"><?php echo $forum_info['title']; ?></a>
                        <?php else: ?>
                            <?php echo $forum_info['title']; ?>
                        <?php endif; ?>
                    </li>
                <?php endif; ?>
                <?php if ($selected_topic_id > 0 && $topic_info): ?>
                    <li class="breadcrumb-item active"><?php echo $topic_info['title']; ?></li>
                <?php endif; ?>
            </ol>
        </nav>
        
        <!-- حاوية المنتدى -->
        <div class="forum-container">
            <?php if (!$selected_forum_id): ?>
                <!-- قائمة المنتديات -->
                <div class="forum-header">
                    <h2 class="forum-title"><?php echo t('available_forums'); ?></h2>
                    <p class="forum-description"><?php echo t('available_forums_description'); ?></p>
                    <div class="forum-stats">
                        <div class="forum-stat">
                            <i class="fas fa-comments"></i>
                            <span><?php echo count($forums); ?> <?php echo t('forums'); ?></span>
                        </div>
                        <div class="forum-stat">
                            <i class="fas fa-file-alt"></i>
                            <span>150+ <?php echo t('topics'); ?></span>
                        </div>
                        <div class="forum-stat">
                            <i class="fas fa-reply"></i>
                            <span>500+ <?php echo t('posts'); ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="forum-body">
                    <!-- البحث والتصفية -->
                    <div class="forum-actions">
                        <div class="search-box">
                            <input type="text" placeholder="<?php echo t('search_forums'); ?>" id="forumSearch">
                            <i class="fas fa-search"></i>
                        </div>
                        <div class="forum-filter">
                            <button class="btn btn-outline-primary active" data-filter="all"><?php echo t('all'); ?></button>
                            <button class="btn btn-outline-primary" data-filter="course"><?php echo t('course'); ?></button>
                            <button class="btn btn-outline-primary" data-filter="general"><?php echo t('general'); ?></button>
                            <button class="btn btn-outline-primary" data-filter="support"><?php echo t('support'); ?></button>
                        </div>
                    </div>
                    
                    <?php if (count($forums) > 0): ?>
                        <ul class="forum-list">
                            <?php foreach ($forums as $forum): ?>
                                <li class="forum-item" data-type="<?php echo $forum['type']; ?>">
                                    <a href="student_forums.php?forum_id=<?php echo $forum['id']; ?>" class="text-decoration-none">
                                        <div class="forum-item-header">
                                            <div class="forum-item-icon">
                                                <i class="fas <?php echo $forum['icon']; ?>"></i>
                                            </div>
                                            <div>
                                                <h4 class="forum-item-title"><?php echo $forum['title']; ?></h4>
                                                <p class="forum-item-description"><?php echo $forum['description']; ?></p>
                                            </div>
                                        </div>
                                        <div class="forum-item-meta">
                                            <div class="forum-item-stats">
                                                <div class="forum-item-stat">
                                                    <i class="fas fa-file-alt"></i>
                                                    <span><?php echo $forum['topics_count']; ?> <?php echo t('topics'); ?></span>
                                                </div>
                                                <div class="forum-item-stat">
                                                    <i class="fas fa-reply"></i>
                                                    <span><?php echo $forum['posts_count']; ?> <?php echo t('posts'); ?></span>
                                                </div>
                                            </div>
                                            <div class="forum-item-last-post">
                                                <?php if ($forum['last_post']): ?>
                                                    <img src="<?php echo $forum['last_post']['author_avatar']; ?>" alt="<?php echo $forum['last_post']['author_name']; ?>">
                                                    <div>
                                                        <div><?php echo $forum['last_post']['title']; ?></div>
                                                        <small><?php echo $forum['last_post']['time']; ?></small>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted"><?php echo t('no_posts_yet'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-comments"></i>
                            <h4><?php echo t('no_forums_available'); ?></h4>
                            <p><?php echo t('no_forums_available_message'); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php elseif ($selected_forum_id > 0 && !$selected_topic_id && $forum_info): ?>
                <!-- قائمة المواضيع في المنتدى المحدد -->
                <div class="forum-header">
                    <h2 class="forum-title"><?php echo $forum_info['title']; ?></h2>
                    <p class="forum-description"><?php echo $forum_info['description']; ?></p>
                    <div class="forum-stats">
                        <div class="forum-stat">
                            <i class="fas fa-file-alt"></i>
                            <span><?php echo $forum_info['topics_count']; ?> <?php echo t('topics'); ?></span>
                        </div>
                        <div class="forum-stat">
                            <i class="fas fa-reply"></i>
                            <span><?php echo $forum_info['posts_count']; ?> <?php echo t('posts'); ?></span>
                        </div>
                        <div class="forum-stat">
                            <i class="fas fa-user"></i>
                            <span><?php echo $forum_info['participants_count']; ?> <?php echo t('participants'); ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="forum-body">
                    <!-- البحث والتصفية -->
                    <div class="forum-actions">
                        <div class="search-box">
                            <input type="text" placeholder="<?php echo t('search_topics'); ?>" id="topicSearch">
                            <i class="fas fa-search"></i>
                        </div>
                        <div class="forum-filter">
                            <button class="btn btn-outline-primary active" data-filter="all"><?php echo t('all'); ?></button>
                            <button class="btn btn-outline-primary" data-filter="sticky"><?php echo t('sticky'); ?></button>
                            <button class="btn btn-outline-primary" data-filter="announcement"><?php echo t('announcements'); ?></button>
                            <button class="btn btn-outline-primary" data-filter="solved"><?php echo t('solved'); ?></button>
                        </div>
                    </div>
                    
                    <?php if (count($topics) > 0): ?>
                        <ul class="topic-list">
                            <?php foreach ($topics as $topic): ?>
                                <li class="topic-item" data-type="<?php echo $topic['type']; ?>">
                                    <a href="student_forums.php?forum_id=<?php echo $selected_forum_id; ?>&topic_id=<?php echo $topic['id']; ?>" class="text-decoration-none">
                                        <div class="topic-item-header">
                                            <div class="topic-item-icon">
                                                <i class="fas <?php echo $topic['icon']; ?>"></i>
                                            </div>
                                            <div>
                                                <h4 class="topic-item-title">
                                                    <?php if ($topic['is_sticky']): ?>
                                                        <span class="topic-item-badge sticky"><?php echo t('sticky'); ?></span>
                                                    <?php endif; ?>
                                                    <?php if ($topic['is_announcement']): ?>
                                                        <span class="topic-item-badge announcement"><?php echo t('announcement'); ?></span>
                                                    <?php endif; ?>
                                                    <?php if ($topic['is_solved']): ?>
                                                        <span class="topic-item-badge solved"><?php echo t('solved'); ?></span>
                                                    <?php endif; ?>
                                                    <?php echo $topic['title']; ?>
                                                </h4>
                                                <div class="topic-item-meta">
                                                    <div class="topic-item-author">
                                                        <img src="<?php echo $topic['author_avatar']; ?>" alt="<?php echo $topic['author_name']; ?>">
                                                        <div>
                                                            <div><?php echo $topic['author_name']; ?></div>
                                                            <small><?php echo $topic['created_at']; ?></small>
                                                        </div>
                                                    </div>
                                                    <div class="topic-item-stats">
                                                        <div class="topic-item-stat">
                                                            <i class="fas fa-eye"></i>
                                                            <span><?php echo $topic['views_count']; ?></span>
                                                        </div>
                                                        <div class="topic-item-stat">
                                                            <i class="fas fa-reply"></i>
                                                            <span><?php echo $topic['replies_count']; ?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        
                        <!-- الترقيم -->
                        <div class="pagination-container">
                            <nav aria-label="Page navigation">
                                <ul class="pagination">
                                    <li class="page-item disabled">
                                        <a class="page-link" href="#" tabindex="-1" aria-disabled="true"><?php echo t('previous'); ?></a>
                                    </li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item">
                                        <a class="page-link" href="#"><?php echo t('next'); ?></a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-file-alt"></i>
                            <h4><?php echo t('no_topics_available'); ?></h4>
                            <p><?php echo t('no_topics_available_message'); ?></p>
                            <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newTopicModal">
                                <i class="fas fa-plus-circle me-1"></i> <?php echo t('create_first_topic'); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php elseif ($selected_topic_id > 0 && $topic_info): ?>
                <!-- عرض الموضوع والمشاركات -->
                <div class="forum-header">
                    <h2 class="forum-title">
                        <?php if ($topic_info['is_sticky']): ?>
                            <span class="topic-item-badge sticky"><?php echo t('sticky'); ?></span>
                        <?php endif; ?>
                        <?php if ($topic_info['is_announcement']): ?>
                            <span class="topic-item-badge announcement"><?php echo t('announcement'); ?></span>
                        <?php endif; ?>
                        <?php if ($topic_info['is_solved']): ?>
                            <span class="topic-item-badge solved"><?php echo t('solved'); ?></span>
                        <?php endif; ?>
                        <?php echo $topic_info['title']; ?>
                    </h2>
                    <p class="forum-description">
                        <span class="me-2">
                            <i class="fas fa-user me-1"></i> <?php echo $topic_info['author_name']; ?>
                        </span>
                        <span class="me-2">
                            <i class="fas fa-calendar-alt me-1"></i> <?php echo $topic_info['created_at']; ?>
                        </span>
                        <span class="me-2">
                            <i class="fas fa-eye me-1"></i> <?php echo $topic_info['views_count']; ?> <?php echo t('views'); ?>
                        </span>
                        <span>
                            <i class="fas fa-reply me-1"></i> <?php echo $topic_info['replies_count']; ?> <?php echo t('replies'); ?>
                        </span>
                    </p>
                </div>
                
                <div class="forum-body">
                    <?php if (count($posts) > 0): ?>
                        <ul class="post-list">
                            <?php foreach ($posts as $index => $post): ?>
                                <li class="post-item" id="post-<?php echo $post['id']; ?>">
                                    <div class="post-item-header">
                                        <div class="post-item-author">
                                            <img src="<?php echo $post['author_avatar']; ?>" alt="<?php echo $post['author_name']; ?>">
                                            <div>
                                                <div class="post-item-author-name"><?php echo $post['author_name']; ?></div>
                                                <div class="post-item-author-role"><?php echo $post['author_role']; ?></div>
                                            </div>
                                        </div>
                                        <div class="post-item-date">
                                            <?php echo $post['created_at']; ?>
                                            <?php if ($index === 0): ?>
                                                <span class="badge bg-primary ms-1"><?php echo t('original_post'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="post-item-content">
                                        <?php echo $post['content']; ?>
                                    </div>
                                    
                                    <?php if (isset($post['attachments']) && count($post['attachments']) > 0): ?>
                                        <div class="post-item-attachments">
                                            <h6><?php echo t('attachments'); ?></h6>
                                            <?php foreach ($post['attachments'] as $attachment): ?>
                                                <div class="post-item-attachment">
                                                    <i class="fas fa-file-<?php echo $attachment['icon']; ?>"></i>
                                                    <div class="post-item-attachment-info">
                                                        <div class="post-item-attachment-name"><?php echo $attachment['name']; ?></div>
                                                        <div class="post-item-attachment-size"><?php echo $attachment['size']; ?></div>
                                                    </div>
                                                    <div class="post-item-attachment-actions">
                                                        <a href="<?php echo $attachment['url']; ?>" download>
                                                            <i class="fas fa-download"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="post-item-footer">
                                        <div class="post-item-actions">
                                            <div class="post-item-action" data-bs-toggle="tooltip" title="<?php echo t('quote'); ?>">
                                                <i class="fas fa-quote-right"></i>
                                                <span><?php echo t('quote'); ?></span>
                                            </div>
                                            <div class="post-item-action" data-bs-toggle="tooltip" title="<?php echo t('reply'); ?>">
                                                <i class="fas fa-reply"></i>
                                                <span><?php echo t('reply'); ?></span>
                                            </div>
                                            <?php if ($post['author_id'] === $student_id): ?>
                                                <div class="post-item-action" data-bs-toggle="tooltip" title="<?php echo t('edit'); ?>">
                                                    <i class="fas fa-edit"></i>
                                                    <span><?php echo t('edit'); ?></span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="post-item-likes">
                                            <i class="fas fa-heart"></i>
                                            <span><?php echo $post['likes_count']; ?></span>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        
                        <!-- الترقيم -->
                        <div class="pagination-container">
                            <nav aria-label="Page navigation">
                                <ul class="pagination">
                                    <li class="page-item disabled">
                                        <a class="page-link" href="#" tabindex="-1" aria-disabled="true"><?php echo t('previous'); ?></a>
                                    </li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item">
                                        <a class="page-link" href="#"><?php echo t('next'); ?></a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-comments"></i>
                            <h4><?php echo t('no_posts_available'); ?></h4>
                            <p><?php echo t('no_posts_available_message'); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- نموذج الرد -->
                <div class="post-form" id="replyForm">
                    <h4 class="post-form-title"><?php echo t('reply_to_topic'); ?></h4>
                    <form id="replyToTopicForm">
                        <input type="hidden" name="topic_id" value="<?php echo $selected_topic_id; ?>">
                        
                        <div class="post-editor-toolbar">
                            <button type="button" title="<?php echo t('bold'); ?>"><i class="fas fa-bold"></i></button>
                            <button type="button" title="<?php echo t('italic'); ?>"><i class="fas fa-italic"></i></button>
                            <button type="button" title="<?php echo t('underline'); ?>"><i class="fas fa-underline"></i></button>
                            <div class="separator"></div>
                            <button type="button" title="<?php echo t('bullet_list'); ?>"><i class="fas fa-list-ul"></i></button>
                            <button type="button" title="<?php echo t('numbered_list'); ?>"><i class="fas fa-list-ol"></i></button>
                            <div class="separator"></div>
                            <button type="button" title="<?php echo t('link'); ?>"><i class="fas fa-link"></i></button>
                            <button type="button" title="<?php echo t('image'); ?>"><i class="fas fa-image"></i></button>
                            <button type="button" title="<?php echo t('code'); ?>"><i class="fas fa-code"></i></button>
                            <button type="button" title="<?php echo t('quote'); ?>"><i class="fas fa-quote-right"></i></button>
                        </div>
                        
                        <div class="mb-3">
                            <textarea class="form-control" name="content" rows="5" placeholder="<?php echo t('write_your_reply'); ?>" required></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="attachment" class="form-label"><?php echo t('attachment'); ?> (<?php echo t('optional'); ?>)</label>
                            <input type="file" class="form-control" id="attachment" name="attachment">
                        </div>
                        
                        <div class="post-form-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane me-1"></i> <?php echo t('post_reply'); ?>
                            </button>
                        </div>
                    </form>
                </div>
            <?php else: ?>
                <!-- حالة خطأ -->
                <div class="empty-state">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h4><?php echo t('forum_not_found'); ?></h4>
                    <p><?php echo t('forum_not_found_message'); ?></p>
                    <a href="student_forums.php" class="btn btn-primary">
                        <i class="fas fa-arrow-left me-1"></i> <?php echo t('back_to_forums'); ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- مودال موضوع جديد -->
    <div class="modal fade" id="newTopicModal" tabindex="-1" aria-labelledby="newTopicModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newTopicModalLabel"><?php echo t('new_topic'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="newTopicForm">
                        <input type="hidden" name="forum_id" value="<?php echo $selected_forum_id; ?>">
                        
                        <div class="mb-3">
                            <label for="topicTitle" class="form-label"><?php echo t('title'); ?></label>
                            <input type="text" class="form-control" id="topicTitle" name="title" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="topicContent" class="form-label"><?php echo t('content'); ?></label>
                            
                            <div class="post-editor-toolbar">
                                <button type="button" title="<?php echo t('bold'); ?>"><i class="fas fa-bold"></i></button>
                                <button type="button" title="<?php echo t('italic'); ?>"><i class="fas fa-italic"></i></button>
                                <button type="button" title="<?php echo t('underline'); ?>"><i class="fas fa-underline"></i></button>
                                <div class="separator"></div>
                                <button type="button" title="<?php echo t('bullet_list'); ?>"><i class="fas fa-list-ul"></i></button>
                                <button type="button" title="<?php echo t('numbered_list'); ?>"><i class="fas fa-list-ol"></i></button>
                                <div class="separator"></div>
                                <button type="button" title="<?php echo t('link'); ?>"><i class="fas fa-link"></i></button>
                                <button type="button" title="<?php echo t('image'); ?>"><i class="fas fa-image"></i></button>
                                <button type="button" title="<?php echo t('code'); ?>"><i class="fas fa-code"></i></button>
                                <button type="button" title="<?php echo t('quote'); ?>"><i class="fas fa-quote-right"></i></button>
                            </div>
                            
                            <textarea class="form-control" id="topicContent" name="content" rows="10" required></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="topicTags" class="form-label"><?php echo t('tags'); ?> (<?php echo t('optional'); ?>)</label>
                            <input type="text" class="form-control" id="topicTags" name="tags" placeholder="<?php echo t('tags_placeholder'); ?>">
                            <div class="form-text"><?php echo t('tags_help'); ?></div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="topicAttachment" class="form-label"><?php echo t('attachment'); ?> (<?php echo t('optional'); ?>)</label>
                            <input type="file" class="form-control" id="topicAttachment" name="attachment">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="button" class="btn btn-primary" id="createTopic">
                        <i class="fas fa-plus-circle me-1"></i> <?php echo t('create_topic'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // تفعيل tooltips
            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
            
            // البحث في المنتديات
            const forumSearch = document.getElementById('forumSearch');
            if (forumSearch) {
                forumSearch.addEventListener('input', function() {
                    const searchTerm = this.value.toLowerCase();
                    const forums = document.querySelectorAll('.forum-item');
                    
                    forums.forEach(forum => {
                        const title = forum.querySelector('.forum-item-title').textContent.toLowerCase();
                        const description = forum.querySelector('.forum-item-description').textContent.toLowerCase();
                        
                        if (title.includes(searchTerm) || description.includes(searchTerm)) {
                            forum.style.display = 'block';
                        } else {
                            forum.style.display = 'none';
                        }
                    });
                });
            }
            
            // البحث في المواضيع
            const topicSearch = document.getElementById('topicSearch');
            if (topicSearch) {
                topicSearch.addEventListener('input', function() {
                    const searchTerm = this.value.toLowerCase();
                    const topics = document.querySelectorAll('.topic-item');
                    
                    topics.forEach(topic => {
                        const title = topic.querySelector('.topic-item-title').textContent.toLowerCase();
                        
                        if (title.includes(searchTerm)) {
                            topic.style.display = 'block';
                        } else {
                            topic.style.display = 'none';
                        }
                    });
                });
            }
            
            // تصفية المنتديات
            const forumFilterButtons = document.querySelectorAll('.forum-filter button[data-filter]');
            if (forumFilterButtons.length > 0) {
                forumFilterButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        // إزالة الفئة النشطة من جميع الأزرار
                        forumFilterButtons.forEach(btn => btn.classList.remove('active'));
                        
                        // إضافة الفئة النشطة إلى الزر المحدد
                        this.classList.add('active');
                        
                        const filter = this.getAttribute('data-filter');
                        const items = document.querySelectorAll('.forum-item, .topic-item');
                        
                        items.forEach(item => {
                            if (filter === 'all' || item.getAttribute('data-type') === filter) {
                                item.style.display = 'block';
                            } else {
                                item.style.display = 'none';
                            }
                        });
                    });
                });
            }
            
            // إنشاء موضوع جديد
            const createTopicButton = document.getElementById('createTopic');
            const newTopicForm = document.getElementById('newTopicForm');
            
            if (createTopicButton && newTopicForm) {
                createTopicButton.addEventListener('click', function() {
                    // التحقق من صحة النموذج
                    if (newTopicForm.checkValidity()) {
                        // إرسال الموضوع إلى الخادم
                        // هنا يمكن إضافة كود لإرسال طلب AJAX
                        
                        // إغلاق المودال
                        const modal = bootstrap.Modal.getInstance(document.getElementById('newTopicModal'));
                        modal.hide();
                        
                        // إعادة تعيين النموذج
                        newTopicForm.reset();
                        
                        // عرض رسالة نجاح
                        alert('تم إنشاء الموضوع بنجاح!');
                        
                        // إعادة تحميل الصفحة
                        window.location.reload();
                    } else {
                        newTopicForm.reportValidity();
                    }
                });
            }
            
            // إرسال رد على موضوع
            const replyToTopicForm = document.getElementById('replyToTopicForm');
            
            if (replyToTopicForm) {
                replyToTopicForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    // التحقق من صحة النموذج
                    if (this.checkValidity()) {
                        // إرسال الرد إلى الخادم
                        // هنا يمكن إضافة كود لإرسال طلب AJAX
                        
                        // إعادة تعيين النموذج
                        this.reset();
                        
                        // عرض رسالة نجاح
                        alert('تم إرسال الرد بنجاح!');
                        
                        // إعادة تحميل الصفحة
                        window.location.reload();
                    } else {
                        this.reportValidity();
                    }
                });
            }
            
            // أزرار محرر النص
            const editorButtons = document.querySelectorAll('.post-editor-toolbar button');
            
            if (editorButtons.length > 0) {
                editorButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        const textarea = this.closest('form').querySelector('textarea');
                        const icon = this.querySelector('i').className;
                        
                        let tag = '';
                        let placeholder = '';
                        
                        if (icon.includes('bold')) {
                            tag = '**';
                            placeholder = 'نص عريض';
                        } else if (icon.includes('italic')) {
                            tag = '*';
                            placeholder = 'نص مائل';
                        } else if (icon.includes('underline')) {
                            tag = '__';
                            placeholder = 'نص مسطر';
                        } else if (icon.includes('list-ul')) {
                            tag = '\n- ';
                            placeholder = 'عنصر قائمة';
                        } else if (icon.includes('list-ol')) {
                            tag = '\n1. ';
                            placeholder = 'عنصر قائمة';
                        } else if (icon.includes('link')) {
                            tag = '[';
                            placeholder = 'نص الرابط';
                            tag2 = '](';
                            placeholder2 = 'الرابط';
                            tag3 = ')';
                            
                            const selectionStart = textarea.selectionStart;
                            const selectionEnd = textarea.selectionEnd;
                            const selectedText = textarea.value.substring(selectionStart, selectionEnd);
                            
                            const newText = tag + (selectedText || placeholder) + tag2 + placeholder2 + tag3;
                            
                            textarea.value = textarea.value.substring(0, selectionStart) + newText + textarea.value.substring(selectionEnd);
                            
                            textarea.focus();
                            textarea.selectionStart = selectionStart + tag.length;
                            textarea.selectionEnd = selectionStart + tag.length + (selectedText.length || placeholder.length);
                            
                            return;
                        } else if (icon.includes('image')) {
                            tag = '![';
                            placeholder = 'وصف الصورة';
                            tag2 = '](';
                            placeholder2 = 'رابط الصورة';
                            tag3 = ')';
                            
                            const selectionStart = textarea.selectionStart;
                            const selectionEnd = textarea.selectionEnd;
                            const selectedText = textarea.value.substring(selectionStart, selectionEnd);
                            
                            const newText = tag + (selectedText || placeholder) + tag2 + placeholder2 + tag3;
                            
                            textarea.value = textarea.value.substring(0, selectionStart) + newText + textarea.value.substring(selectionEnd);
                            
                            textarea.focus();
                            textarea.selectionStart = selectionStart + tag.length;
                            textarea.selectionEnd = selectionStart + tag.length + (selectedText.length || placeholder.length);
                            
                            return;
                        } else if (icon.includes('code')) {
                            tag = '`';
                            placeholder = 'كود';
                        } else if (icon.includes('quote-right')) {
                            tag = '> ';
                            placeholder = 'اقتباس';
                        }
                        
                        const selectionStart = textarea.selectionStart;
                        const selectionEnd = textarea.selectionEnd;
                        const selectedText = textarea.value.substring(selectionStart, selectionEnd);
                        
                        const newText = tag + (selectedText || placeholder) + (tag === '> ' || tag === '\n- ' || tag === '\n1. ' ? '' : tag);
                        
                        textarea.value = textarea.value.substring(0, selectionStart) + newText + textarea.value.substring(selectionEnd);
                        
                        textarea.focus();
                        if (selectedText) {
                            textarea.selectionStart = selectionStart + tag.length;
                            textarea.selectionEnd = selectionStart + tag.length + selectedText.length;
                        } else {
                            textarea.selectionStart = selectionStart + tag.length;
                            textarea.selectionEnd = selectionStart + tag.length + placeholder.length;
                        }
                    });
                });
            }
            
            // اقتباس مشاركة
            const quoteButtons = document.querySelectorAll('.post-item-action[title="اقتباس"]');
            
            if (quoteButtons.length > 0) {
                quoteButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        const postItem = this.closest('.post-item');
                        const authorName = postItem.querySelector('.post-item-author-name').textContent;
                        const postContent = postItem.querySelector('.post-item-content').textContent.trim();
                        
                        const replyTextarea = document.querySelector('#replyToTopicForm textarea');
                        
                        const quote = `> **${authorName} قال:**\n> ${postContent.replace(/\n/g, '\n> ')}\n\n`;
                        
                        replyTextarea.value += quote;
                        
                        // التمرير إلى نموذج الرد
                        document.getElementById('replyForm').scrollIntoView({ behavior: 'smooth' });
                        
                        // تركيز على مربع النص
                        replyTextarea.focus();
                    });
                });
            }
            
            // الرد على مشاركة
            const replyButtons = document.querySelectorAll('.post-item-action[title="رد"]');
            
            if (replyButtons.length > 0) {
                replyButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        const postItem = this.closest('.post-item');
                        const authorName = postItem.querySelector('.post-item-author-name').textContent;
                        
                        const replyTextarea = document.querySelector('#replyToTopicForm textarea');
                        
                        const mention = `@${authorName} `;
                        
                        replyTextarea.value += mention;
                        
                        // التمرير إلى نموذج الرد
                        document.getElementById('replyForm').scrollIntoView({ behavior: 'smooth' });
                        
                        // تركيز على مربع النص
                        replyTextarea.focus();
                    });
                });
            }
        });
    </script>
</body>
</html>
