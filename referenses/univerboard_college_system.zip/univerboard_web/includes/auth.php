<?php
/**
 * ملف المصادقة لنظام UniverBoard
 * يحتوي على دوال المصادقة وإدارة الجلسات
 */

// استيراد الملفات اللازمة
require_once 'config.php';
require_once 'functions.php';

// بدء الجلسة إذا لم تكن قد بدأت
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

/**
 * دالة تسجيل الدخول
 * @param string $email البريد الإلكتروني
 * @param string $password كلمة المرور
 * @param string $userType نوع المستخدم
 * @return array نتيجة تسجيل الدخول
 */
function login($email, $password, $userType) {
    $db = getDbConnection();
    
    // التحقق من وجود المستخدم
    $query = "SELECT * FROM users WHERE email = :email AND user_type = :userType AND is_active = 1";
    $stmt = $db->prepare($query);
    $stmt->execute([
        'email' => $email,
        'userType' => $userType
    ]);
    
    $user = $stmt->fetch();
    
    if (!$user) {
        return [
            'success' => false,
            'message' => 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
        ];
    }
    
    // التحقق من كلمة المرور
    if (!verifyPassword($password, $user['password'])) {
        return [
            'success' => false,
            'message' => 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
        ];
    }
    
    // تحديث آخر تسجيل دخول
    $updateQuery = "UPDATE users SET last_login = NOW() WHERE id = :id";
    $updateStmt = $db->prepare($updateQuery);
    $updateStmt->execute(['id' => $user['id']]);
    
    // الحصول على معلومات إضافية حسب نوع المستخدم
    $additionalInfo = [];
    
    switch ($userType) {
        case 'student':
            $studentQuery = "SELECT * FROM students WHERE user_id = :userId";
            $studentStmt = $db->prepare($studentQuery);
            $studentStmt->execute(['userId' => $user['id']]);
            $additionalInfo = $studentStmt->fetch();
            break;
            
        case 'teacher':
            $teacherQuery = "SELECT * FROM teachers WHERE user_id = :userId";
            $teacherStmt = $db->prepare($teacherQuery);
            $teacherStmt->execute(['userId' => $user['id']]);
            $additionalInfo = $teacherStmt->fetch();
            break;
            
        case 'college_admin':
            $adminQuery = "SELECT * FROM college_admins WHERE user_id = :userId";
            $adminStmt = $db->prepare($adminQuery);
            $adminStmt->execute(['userId' => $user['id']]);
            $additionalInfo = $adminStmt->fetch();
            break;
            
        case 'system_admin':
            $adminQuery = "SELECT * FROM system_admins WHERE user_id = :userId";
            $adminStmt = $db->prepare($adminQuery);
            $adminStmt->execute(['userId' => $user['id']]);
            $additionalInfo = $adminStmt->fetch();
            break;
    }
    
    // إنشاء بيانات الجلسة
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_type'] = $user['user_type'];
    $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_language'] = $user['language'];
    $_SESSION['user_theme'] = $user['theme'];
    
    // إضافة معلومات إضافية حسب نوع المستخدم
    if (!empty($additionalInfo)) {
        switch ($userType) {
            case 'student':
                $_SESSION['student_id'] = $additionalInfo['student_id'];
                $_SESSION['college_id'] = $additionalInfo['college_id'];
                $_SESSION['department_id'] = $additionalInfo['department_id'];
                $_SESSION['program_id'] = $additionalInfo['program_id'];
                break;
                
            case 'teacher':
                $_SESSION['teacher_id'] = $additionalInfo['teacher_id'];
                $_SESSION['college_id'] = $additionalInfo['college_id'];
                $_SESSION['department_id'] = $additionalInfo['department_id'];
                break;
                
            case 'college_admin':
                $_SESSION['admin_id'] = $additionalInfo['admin_id'];
                $_SESSION['college_id'] = $additionalInfo['college_id'];
                break;
                
            case 'system_admin':
                $_SESSION['admin_id'] = $additionalInfo['admin_id'];
                break;
        }
    }
    
    return [
        'success' => true,
        'message' => 'تم تسجيل الدخول بنجاح',
        'user' => [
            'id' => $user['id'],
            'name' => $user['first_name'] . ' ' . $user['last_name'],
            'email' => $user['email'],
            'type' => $user['user_type']
        ]
    ];
}

/**
 * دالة تسجيل الخروج
 */
function logout() {
    // حذف متغيرات الجلسة
    $_SESSION = [];
    
    // حذف ملف تعريف الارتباط الخاص بالجلسة
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
    
    // إنهاء الجلسة
    session_destroy();
}

/**
 * دالة التحقق من تسجيل الدخول
 * @return bool نتيجة التحقق
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * دالة التحقق من نوع المستخدم
 * @param string|array $types نوع أو أنواع المستخدمين المسموح بها
 * @return bool نتيجة التحقق
 */
function isUserType($types) {
    if (!isLoggedIn()) {
        return false;
    }
    
    if (is_array($types)) {
        return in_array($_SESSION['user_type'], $types);
    }
    
    return $_SESSION['user_type'] === $types;
}

/**
 * دالة إعادة توجيه المستخدم غير المسجل
 * @param string $redirectUrl مسار إعادة التوجيه
 */
function requireLogin($redirectUrl = '/login.php') {
    if (!isLoggedIn()) {
        redirect($redirectUrl);
    }
}

/**
 * دالة إعادة توجيه المستخدم غير المصرح له
 * @param string|array $allowedTypes نوع أو أنواع المستخدمين المسموح بها
 * @param string $redirectUrl مسار إعادة التوجيه
 */
function requireUserType($allowedTypes, $redirectUrl = '/login.php') {
    if (!isUserType($allowedTypes)) {
        logout();
        redirect($redirectUrl);
    }
}

/**
 * دالة إرسال رمز إعادة تعيين كلمة المرور
 * @param string $email البريد الإلكتروني
 * @return array نتيجة العملية
 */
function sendPasswordResetToken($email) {
    $db = getDbConnection();
    
    // التحقق من وجود المستخدم
    $query = "SELECT * FROM users WHERE email = :email AND is_active = 1";
    $stmt = $db->prepare($query);
    $stmt->execute(['email' => $email]);
    
    $user = $stmt->fetch();
    
    if (!$user) {
        return [
            'success' => false,
            'message' => 'البريد الإلكتروني غير مسجل في النظام'
        ];
    }
    
    // إنشاء رمز إعادة التعيين
    $token = generateRandomToken();
    $expiry = date('Y-m-d H:i:s', time() + 3600); // صالح لمدة ساعة
    
    // حذف الرموز السابقة
    $deleteQuery = "DELETE FROM password_resets WHERE email = :email";
    $deleteStmt = $db->prepare($deleteQuery);
    $deleteStmt->execute(['email' => $email]);
    
    // إضافة الرمز الجديد
    $insertQuery = "INSERT INTO password_resets (email, token, created_at) VALUES (:email, :token, NOW())";
    $insertStmt = $db->prepare($insertQuery);
    $insertStmt->execute([
        'email' => $email,
        'token' => $token
    ]);
    
    // إرسال البريد الإلكتروني
    $resetLink = BASE_URL . '/reset-password.php?token=' . $token;
    $subject = 'إعادة تعيين كلمة المرور - ' . SITE_NAME;
    $body = '
        <h2>إعادة تعيين كلمة المرور</h2>
        <p>مرحباً ' . $user['first_name'] . ',</p>
        <p>لقد تلقينا طلباً لإعادة تعيين كلمة المرور الخاصة بحسابك.</p>
        <p>يرجى النقر على الرابط التالي لإعادة تعيين كلمة المرور:</p>
        <p><a href="' . $resetLink . '">' . $resetLink . '</a></p>
        <p>هذا الرابط صالح لمدة ساعة واحدة فقط.</p>
        <p>إذا لم تطلب إعادة تعيين كلمة المرور، يرجى تجاهل هذا البريد الإلكتروني.</p>
        <p>مع تحيات فريق ' . SITE_NAME . '</p>
    ';
    
    $emailSent = sendEmail($email, $subject, $body);
    
    if (!$emailSent) {
        return [
            'success' => false,
            'message' => 'حدث خطأ أثناء إرسال البريد الإلكتروني'
        ];
    }
    
    return [
        'success' => true,
        'message' => 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني'
    ];
}

/**
 * دالة التحقق من صحة رمز إعادة تعيين كلمة المرور
 * @param string $token الرمز
 * @return array نتيجة التحقق
 */
function verifyPasswordResetToken($token) {
    $db = getDbConnection();
    
    $query = "SELECT * FROM password_resets WHERE token = :token AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)";
    $stmt = $db->prepare($query);
    $stmt->execute(['token' => $token]);
    
    $reset = $stmt->fetch();
    
    if (!$reset) {
        return [
            'success' => false,
            'message' => 'رمز إعادة التعيين غير صالح أو منتهي الصلاحية'
        ];
    }
    
    return [
        'success' => true,
        'email' => $reset['email']
    ];
}

/**
 * دالة إعادة تعيين كلمة المرور
 * @param string $token الرمز
 * @param string $password كلمة المرور الجديدة
 * @return array نتيجة العملية
 */
function resetPassword($token, $password) {
    $tokenVerification = verifyPasswordResetToken($token);
    
    if (!$tokenVerification['success']) {
        return $tokenVerification;
    }
    
    $db = getDbConnection();
    
    // تحديث كلمة المرور
    $updateQuery = "UPDATE users SET password = :password WHERE email = :email";
    $updateStmt = $db->prepare($updateQuery);
    $updateStmt->execute([
        'password' => hashPassword($password),
        'email' => $tokenVerification['email']
    ]);
    
    // حذف الرمز
    $deleteQuery = "DELETE FROM password_resets WHERE token = :token";
    $deleteStmt = $db->prepare($deleteQuery);
    $deleteStmt->execute(['token' => $token]);
    
    return [
        'success' => true,
        'message' => 'تم إعادة تعيين كلمة المرور بنجاح'
    ];
}

/**
 * دالة إنشاء API token للمستخدم
 * @param int $userId معرف المستخدم
 * @return string رمز API
 */
function generateApiToken($userId) {
    $db = getDbConnection();
    
    // الحصول على معلومات المستخدم
    $query = "SELECT * FROM users WHERE id = :userId";
    $stmt = $db->prepare($query);
    $stmt->execute(['userId' => $userId]);
    
    $user = $stmt->fetch();
    
    if (!$user) {
        return null;
    }
    
    // إنشاء payload للرمز
    $payload = [
        'sub' => $user['id'],
        'name' => $user['first_name'] . ' ' . $user['last_name'],
        'email' => $user['email'],
        'type' => $user['user_type']
    ];
    
    // إضافة معلومات إضافية حسب نوع المستخدم
    switch ($user['user_type']) {
        case 'student':
            $studentQuery = "SELECT * FROM students WHERE user_id = :userId";
            $studentStmt = $db->prepare($studentQuery);
            $studentStmt->execute(['userId' => $user['id']]);
            $student = $studentStmt->fetch();
            
            if ($student) {
                $payload['student_id'] = $student['student_id'];
                $payload['college_id'] = $student['college_id'];
                $payload['department_id'] = $student['department_id'];
            }
            break;
            
        case 'teacher':
            $teacherQuery = "SELECT * FROM teachers WHERE user_id = :userId";
            $teacherStmt = $db->prepare($teacherQuery);
            $teacherStmt->execute(['userId' => $user['id']]);
            $teacher = $teacherStmt->fetch();
            
            if ($teacher) {
                $payload['teacher_id'] = $teacher['teacher_id'];
                $payload['college_id'] = $teacher['college_id'];
                $payload['department_id'] = $teacher['department_id'];
            }
            break;
            
        case 'college_admin':
            $adminQuery = "SELECT * FROM college_admins WHERE user_id = :userId";
            $adminStmt = $db->prepare($adminQuery);
            $adminStmt->execute(['userId' => $user['id']]);
            $admin = $adminStmt->fetch();
            
            if ($admin) {
                $payload['admin_id'] = $admin['admin_id'];
                $payload['college_id'] = $admin['college_id'];
            }
            break;
            
        case 'system_admin':
            $adminQuery = "SELECT * FROM system_admins WHERE user_id = :userId";
            $adminStmt = $db->prepare($adminQuery);
            $adminStmt->execute(['userId' => $user['id']]);
            $admin = $adminStmt->fetch();
            
            if ($admin) {
                $payload['admin_id'] = $admin['admin_id'];
            }
            break;
    }
    
    // إنشاء الرمز
    return generateJWT($payload);
}
