<?php
/**
 * ملف الدوال المساعدة لنظام UniverBoard
 * يحتوي على دوال عامة تستخدم في مختلف أجزاء النظام
 */

// استيراد ملف الإعدادات
require_once 'config.php';

/**
 * دالة تنظيف وتأمين المدخلات
 * @param string $data البيانات المراد تنظيفها
 * @return string البيانات بعد التنظيف
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * دالة تشفير كلمة المرور
 * @param string $password كلمة المرور المراد تشفيرها
 * @return string كلمة المرور المشفرة
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
}

/**
 * دالة التحقق من كلمة المرور
 * @param string $password كلمة المرور المدخلة
 * @param string $hash كلمة المرور المشفرة المخزنة
 * @return bool نتيجة التحقق
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * دالة إنشاء رمز JWT للمصادقة
 * @param array $payload البيانات المراد تضمينها في الرمز
 * @return string رمز JWT
 */
function generateJWT($payload) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    $header = base64_encode($header);
    
    $payload['iat'] = time(); // وقت الإصدار
    $payload['exp'] = time() + JWT_EXPIRY; // وقت انتهاء الصلاحية
    $payload = json_encode($payload);
    $payload = base64_encode($payload);
    
    $signature = hash_hmac('sha256', "$header.$payload", JWT_SECRET, true);
    $signature = base64_encode($signature);
    
    return "$header.$payload.$signature";
}

/**
 * دالة التحقق من صحة رمز JWT
 * @param string $jwt رمز JWT المراد التحقق منه
 * @return array|bool البيانات المضمنة في الرمز أو false في حالة الفشل
 */
function verifyJWT($jwt) {
    $parts = explode('.', $jwt);
    if (count($parts) !== 3) {
        return false;
    }
    
    list($header, $payload, $signature) = $parts;
    
    $verifySignature = hash_hmac('sha256', "$header.$payload", JWT_SECRET, true);
    $verifySignature = base64_encode($verifySignature);
    
    if ($signature !== $verifySignature) {
        return false;
    }
    
    $payload = json_decode(base64_decode($payload), true);
    
    // التحقق من انتهاء الصلاحية
    if (isset($payload['exp']) && $payload['exp'] < time()) {
        return false;
    }
    
    return $payload;
}

/**
 * دالة إنشاء رمز عشوائي
 * @param int $length طول الرمز
 * @return string الرمز العشوائي
 */
function generateRandomToken($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * دالة تحويل التاريخ إلى الصيغة العربية
 * @param string $date التاريخ بصيغة Y-m-d
 * @return string التاريخ بالصيغة العربية
 */
function formatDateArabic($date) {
    if (empty($date)) return '';
    
    $months = [
        '01' => 'يناير',
        '02' => 'فبراير',
        '03' => 'مارس',
        '04' => 'أبريل',
        '05' => 'مايو',
        '06' => 'يونيو',
        '07' => 'يوليو',
        '08' => 'أغسطس',
        '09' => 'سبتمبر',
        '10' => 'أكتوبر',
        '11' => 'نوفمبر',
        '12' => 'ديسمبر'
    ];
    
    $dateParts = explode('-', $date);
    if (count($dateParts) !== 3) return $date;
    
    $year = $dateParts[0];
    $month = $dateParts[1];
    $day = intval($dateParts[2]);
    
    return $day . ' ' . $months[$month] . ' ' . $year;
}

/**
 * دالة التحقق من صلاحيات المستخدم
 * @param int $userId معرف المستخدم
 * @param string $permission الصلاحية المطلوبة
 * @return bool نتيجة التحقق
 */
function hasPermission($userId, $permission) {
    $db = getDbConnection();
    
    $query = "SELECT r.permissions FROM users u
              JOIN user_roles ur ON u.id = ur.user_id
              JOIN roles r ON ur.role_id = r.id
              WHERE u.id = :userId";
    
    $stmt = $db->prepare($query);
    $stmt->execute(['userId' => $userId]);
    
    while ($row = $stmt->fetch()) {
        $permissions = json_decode($row['permissions'], true);
        if (in_array($permission, $permissions)) {
            return true;
        }
    }
    
    return false;
}

/**
 * دالة إرسال رسالة بريد إلكتروني
 * @param string $to البريد الإلكتروني للمستلم
 * @param string $subject عنوان الرسالة
 * @param string $body محتوى الرسالة
 * @return bool نتيجة الإرسال
 */
function sendEmail($to, $subject, $body) {
    // في بيئة الإنتاج، يجب استخدام مكتبة مثل PHPMailer
    // هذه دالة بسيطة للتوضيح فقط
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: " . MAIL_FROM_NAME . " <" . MAIL_USERNAME . ">" . "\r\n";
    
    return mail($to, $subject, $body, $headers);
}

/**
 * دالة تحويل النص إلى URL صديق
 * @param string $text النص المراد تحويله
 * @return string النص بعد التحويل
 */
function slugify($text) {
    // إزالة الأحرف الخاصة
    $text = preg_replace('~[^\p{L}\p{N}]+~u', '-', $text);
    // إزالة الشرطات المتكررة
    $text = preg_replace('~-+~', '-', $text);
    // إزالة الشرطات من البداية والنهاية
    $text = trim($text, '-');
    // تحويل إلى أحرف صغيرة
    $text = strtolower($text);
    
    return $text;
}

/**
 * دالة التحقق من نوع المستخدم
 * @param string $userType نوع المستخدم المطلوب
 * @return bool نتيجة التحقق
 */
function checkUserType($userType) {
    if (!isset($_SESSION['user_type'])) {
        return false;
    }
    
    return $_SESSION['user_type'] === $userType;
}

/**
 * دالة إعادة التوجيه
 * @param string $url المسار المراد التوجيه إليه
 */
function redirect($url) {
    header("Location: $url");
    exit;
}

/**
 * دالة عرض رسالة خطأ
 * @param string $message نص الرسالة
 */
function showError($message) {
    $_SESSION['error_message'] = $message;
}

/**
 * دالة عرض رسالة نجاح
 * @param string $message نص الرسالة
 */
function showSuccess($message) {
    $_SESSION['success_message'] = $message;
}

/**
 * دالة التحقق من وجود رسائل
 * @return bool نتيجة التحقق
 */
function hasMessages() {
    return isset($_SESSION['error_message']) || isset($_SESSION['success_message']);
}

/**
 * دالة عرض الرسائل
 * @return string HTML الرسائل
 */
function displayMessages() {
    $html = '';
    
    if (isset($_SESSION['error_message'])) {
        $html .= '<div class="alert alert-danger">' . $_SESSION['error_message'] . '</div>';
        unset($_SESSION['error_message']);
    }
    
    if (isset($_SESSION['success_message'])) {
        $html .= '<div class="alert alert-success">' . $_SESSION['success_message'] . '</div>';
        unset($_SESSION['success_message']);
    }
    
    return $html;
}

/**
 * دالة تحميل ملف
 * @param array $file معلومات الملف ($_FILES['file'])
 * @param string $destination مسار الوجهة
 * @param array $allowedTypes أنواع الملفات المسموح بها
 * @param int $maxSize الحجم الأقصى بالبايت
 * @return string|bool اسم الملف بعد التحميل أو false في حالة الفشل
 */
function uploadFile($file, $destination, $allowedTypes = [], $maxSize = 5242880) {
    // التحقق من وجود أخطاء
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    
    // التحقق من الحجم
    if ($file['size'] > $maxSize) {
        return false;
    }
    
    // التحقق من النوع
    $fileType = mime_content_type($file['tmp_name']);
    if (!empty($allowedTypes) && !in_array($fileType, $allowedTypes)) {
        return false;
    }
    
    // إنشاء اسم فريد للملف
    $fileName = uniqid() . '_' . basename($file['name']);
    $filePath = $destination . '/' . $fileName;
    
    // نقل الملف
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        return $fileName;
    }
    
    return false;
}
