<?php
/**
 * صفحة الملف الشخصي للطالب في نظام UniverBoard
 * تعرض معلومات الطالب الشخصية وتتيح تعديلها
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول الطالب
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات الطالب
$student_id = $_SESSION['user_id'];
$db = get_db_connection();
$student = get_student_info($db, $student_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// معالجة تحديث الملف الشخصي
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    // التحقق من البيانات المدخلة
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
    $bio = filter_input(INPUT_POST, 'bio', FILTER_SANITIZE_STRING);
    
    // التحقق من صحة البريد الإلكتروني
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = t('invalid_email');
    } else {
        // تحديث معلومات الطالب في قاعدة البيانات
        $update_result = update_student_profile($db, $student_id, $name, $email, $phone, $address, $bio);
        
        if ($update_result) {
            $success_message = t('profile_updated_successfully');
            // تحديث معلومات الطالب بعد التحديث
            $student = get_student_info($db, $student_id);
        } else {
            $error_message = t('profile_update_failed');
        }
    }
}

// معالجة تحديث كلمة المرور
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // التحقق من تطابق كلمة المرور الجديدة مع تأكيدها
    if ($new_password !== $confirm_password) {
        $error_message = t('password_mismatch');
    } 
    // التحقق من طول كلمة المرور
    elseif (strlen($new_password) < 8) {
        $error_message = t('password_too_short');
    } 
    else {
        // التحقق من صحة كلمة المرور الحالية
        $verify_result = verify_student_password($db, $student_id, $current_password);
        
        if ($verify_result) {
            // تحديث كلمة المرور
            $update_result = update_student_password($db, $student_id, $new_password);
            
            if ($update_result) {
                $success_message = t('password_updated_successfully');
            } else {
                $error_message = t('password_update_failed');
            }
        } else {
            $error_message = t('current_password_incorrect');
        }
    }
}

// معالجة تحديث صورة الملف الشخصي
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile_image'])) {
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_size = 2 * 1024 * 1024; // 2 ميجابايت
        
        // التحقق من نوع الملف وحجمه
        if (!in_array($_FILES['profile_image']['type'], $allowed_types)) {
            $error_message = t('invalid_image_type');
        } elseif ($_FILES['profile_image']['size'] > $max_size) {
            $error_message = t('image_too_large');
        } else {
            // إنشاء مجلد التحميل إذا لم يكن موجوداً
            $upload_dir = 'uploads/profile_images/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            // إنشاء اسم فريد للملف
            $file_extension = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
            $file_name = 'student_' . $student_id . '_' . time() . '.' . $file_extension;
            $file_path = $upload_dir . $file_name;
            
            // نقل الملف المؤقت إلى المجلد المطلوب
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $file_path)) {
                // تحديث مسار الصورة في قاعدة البيانات
                $update_result = update_student_profile_image($db, $student_id, $file_path);
                
                if ($update_result) {
                    $success_message = t('profile_image_updated_successfully');
                    // تحديث معلومات الطالب بعد التحديث
                    $student = get_student_info($db, $student_id);
                } else {
                    $error_message = t('profile_image_update_failed');
                }
            } else {
                $error_message = t('file_upload_failed');
            }
        }
    } else {
        $error_message = t('no_file_uploaded');
    }
}

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('profile'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .profile-container {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .theme-dark .profile-container {
            background-color: #212529;
        }
        
        .profile-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .profile-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .profile-title {
            margin-bottom: 0.5rem;
        }
        
        .profile-subtitle {
            color: var(--gray-color);
        }
        
        .profile-body {
            padding: 1.5rem;
        }
        
        .profile-image-container {
            position: relative;
            width: 150px;
            height: 150px;
            margin: 0 auto 1.5rem;
        }
        
        .profile-image {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 5px solid var(--primary-color);
        }
        
        .profile-image-edit {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 40px;
            height: 40px;
            background-color: var(--primary-color);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        [dir="rtl"] .profile-image-edit {
            right: auto;
            left: 0;
        }
        
        .profile-image-edit:hover {
            background-color: var(--secondary-color);
        }
        
        .profile-info {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        
        .profile-name {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }
        
        .profile-id {
            font-size: 1rem;
            color: var(--gray-color);
            margin-bottom: 0.5rem;
        }
        
        .profile-department {
            font-size: 1rem;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }
        
        .profile-status {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.8rem;
            background-color: #28a745;
            color: white;
        }
        
        .profile-tabs {
            margin-bottom: 1.5rem;
        }
        
        .profile-tab-content {
            padding: 1.5rem 0;
        }
        
        .profile-form-group {
            margin-bottom: 1.5rem;
        }
        
        .profile-form-label {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .profile-form-control {
            border-radius: 0.25rem;
            padding: 0.75rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .profile-form-control {
            background-color: #2c3034;
            border-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .profile-form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(0, 48, 73, 0.25);
        }
        
        .profile-form-submit {
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 0.25rem;
            padding: 0.75rem 1.5rem;
            font-weight: 600;
            transition: all 0.2s ease;
        }
        
        .profile-form-submit:hover {
            background-color: var(--secondary-color);
        }
        
        .profile-stats {
            display: flex;
            justify-content: space-around;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }
        
        .profile-stat {
            text-align: center;
            padding: 1rem;
            flex: 1;
            min-width: 120px;
        }
        
        .profile-stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 0.25rem;
        }
        
        .profile-stat-label {
            font-size: 0.9rem;
            color: var(--gray-color);
        }
        
        .profile-social {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        
        .profile-social-link {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }
        
        .profile-social-link:hover {
            background-color: var(--secondary-color);
            transform: translateY(-3px);
        }
        
        .profile-bio {
            margin-bottom: 1.5rem;
        }
        
        .profile-bio-title {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .profile-bio-text {
            color: var(--text-color);
            line-height: 1.6;
        }
        
        .profile-contact {
            margin-bottom: 1.5rem;
        }
        
        .profile-contact-title {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .profile-contact-item {
            display: flex;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        
        .profile-contact-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(0, 48, 73, 0.1);
            color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        
        [dir="rtl"] .profile-contact-icon {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .theme-dark .profile-contact-icon {
            background-color: rgba(102, 155, 188, 0.1);
        }
        
        .profile-contact-text {
            color: var(--text-color);
        }
        
        .profile-contact-label {
            font-size: 0.8rem;
            color: var(--gray-color);
            margin-bottom: 0.25rem;
        }
        
        .profile-contact-value {
            font-weight: 500;
        }
        
        .profile-academic {
            margin-bottom: 1.5rem;
        }
        
        .profile-academic-title {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .profile-academic-item {
            padding: 1rem;
            border-radius: 0.25rem;
            background-color: rgba(0, 48, 73, 0.05);
            margin-bottom: 0.5rem;
        }
        
        .theme-dark .profile-academic-item {
            background-color: rgba(102, 155, 188, 0.05);
        }
        
        .profile-academic-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
        }
        
        .profile-academic-name {
            font-weight: 600;
        }
        
        .profile-academic-year {
            color: var(--gray-color);
            font-size: 0.9rem;
        }
        
        .profile-academic-details {
            color: var(--text-color);
            font-size: 0.9rem;
        }
        
        .profile-academic-gpa {
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="student_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link active" href="student_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-book"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم إضافة محتوى جديد في مقرر برمجة الويب</p>
                                    <small class="text-muted">منذ 10 دقائق</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-tasks"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تذكير: موعد تسليم واجب قواعد البيانات غداً</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-success text-white rounded-circle">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تصحيح واجب البرمجة المتقدمة</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user1.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. محمد أحمد</p>
                                    <small class="text-muted">هل لديك استفسارات حول المشروع النهائي؟</small>
                                    <small class="text-muted d-block">منذ 15 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user2.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">أ. سارة خالد</p>
                                    <small class="text-muted">تم تحديد موعد المراجعة النهائية للاختبار</small>
                                    <small class="text-muted d-block">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $student['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $student['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $student['name']; ?></h6>
                            <small><?php echo $student['student_id']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="student_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="student_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <div>
                <h1 class="h3"><?php echo t('profile'); ?></h1>
                <p class="text-muted"><?php echo t('profile_subtitle'); ?></p>
            </div>
        </div>
        
        <?php if ($success_message): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-4">
                <!-- معلومات الملف الشخصي -->
                <div class="profile-container">
                    <div class="profile-header">
                        <h2 class="profile-title"><?php echo t('personal_info'); ?></h2>
                    </div>
                    <div class="profile-body">
                        <div class="profile-image-container">
                            <img src="<?php echo $student['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $student['name']; ?>" class="profile-image">
                            <div class="profile-image-edit" data-bs-toggle="modal" data-bs-target="#profileImageModal">
                                <i class="fas fa-camera"></i>
                            </div>
                        </div>
                        
                        <div class="profile-info">
                            <h3 class="profile-name"><?php echo $student['name']; ?></h3>
                            <p class="profile-id"><?php echo $student['student_id']; ?></p>
                            <p class="profile-department"><?php echo $student['department']; ?></p>
                            <span class="profile-status"><?php echo t('active'); ?></span>
                        </div>
                        
                        <div class="profile-stats">
                            <div class="profile-stat">
                                <div class="profile-stat-value">3.85</div>
                                <div class="profile-stat-label"><?php echo t('gpa'); ?></div>
                            </div>
                            <div class="profile-stat">
                                <div class="profile-stat-value">75</div>
                                <div class="profile-stat-label"><?php echo t('credits'); ?></div>
                            </div>
                            <div class="profile-stat">
                                <div class="profile-stat-value">5</div>
                                <div class="profile-stat-label"><?php echo t('courses'); ?></div>
                            </div>
                        </div>
                        
                        <div class="profile-social">
                            <a href="#" class="profile-social-link">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" class="profile-social-link">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="#" class="profile-social-link">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a href="#" class="profile-social-link">
                                <i class="fab fa-github"></i>
                            </a>
                        </div>
                        
                        <div class="profile-bio">
                            <h4 class="profile-bio-title"><?php echo t('bio'); ?></h4>
                            <p class="profile-bio-text">
                                <?php echo $student['bio'] ?: t('no_bio'); ?>
                            </p>
                        </div>
                        
                        <div class="profile-contact">
                            <h4 class="profile-contact-title"><?php echo t('contact_info'); ?></h4>
                            
                            <div class="profile-contact-item">
                                <div class="profile-contact-icon">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <div class="profile-contact-text">
                                    <div class="profile-contact-label"><?php echo t('email'); ?></div>
                                    <div class="profile-contact-value"><?php echo $student['email']; ?></div>
                                </div>
                            </div>
                            
                            <div class="profile-contact-item">
                                <div class="profile-contact-icon">
                                    <i class="fas fa-phone"></i>
                                </div>
                                <div class="profile-contact-text">
                                    <div class="profile-contact-label"><?php echo t('phone'); ?></div>
                                    <div class="profile-contact-value"><?php echo $student['phone'] ?: t('not_provided'); ?></div>
                                </div>
                            </div>
                            
                            <div class="profile-contact-item">
                                <div class="profile-contact-icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="profile-contact-text">
                                    <div class="profile-contact-label"><?php echo t('address'); ?></div>
                                    <div class="profile-contact-value"><?php echo $student['address'] ?: t('not_provided'); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- المعلومات الأكاديمية -->
                <div class="profile-container">
                    <div class="profile-header">
                        <h2 class="profile-title"><?php echo t('academic_info'); ?></h2>
                    </div>
                    <div class="profile-body">
                        <div class="profile-academic">
                            <div class="profile-academic-item">
                                <div class="profile-academic-header">
                                    <div class="profile-academic-name">كلية الحاسب والمعلومات</div>
                                    <div class="profile-academic-year">2022 - الآن</div>
                                </div>
                                <div class="profile-academic-details">
                                    قسم علوم الحاسب
                                </div>
                                <div class="profile-academic-gpa">
                                    المعدل التراكمي: 3.85
                                </div>
                            </div>
                            
                            <div class="profile-academic-item">
                                <div class="profile-academic-header">
                                    <div class="profile-academic-name">الثانوية العامة</div>
                                    <div class="profile-academic-year">2018 - 2022</div>
                                </div>
                                <div class="profile-academic-details">
                                    مدرسة الأمل الثانوية
                                </div>
                                <div class="profile-academic-gpa">
                                    النسبة: 98.5%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <!-- تعديل الملف الشخصي -->
                <div class="profile-container">
                    <div class="profile-header">
                        <h2 class="profile-title"><?php echo t('edit_profile'); ?></h2>
                    </div>
                    <div class="profile-body">
                        <ul class="nav nav-tabs profile-tabs" id="profileTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="personal-tab" data-bs-toggle="tab" data-bs-target="#personal" type="button" role="tab" aria-controls="personal" aria-selected="true">
                                    <?php echo t('personal_info'); ?>
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="password-tab" data-bs-toggle="tab" data-bs-target="#password" type="button" role="tab" aria-controls="password" aria-selected="false">
                                    <?php echo t('change_password'); ?>
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="preferences-tab" data-bs-toggle="tab" data-bs-target="#preferences" type="button" role="tab" aria-controls="preferences" aria-selected="false">
                                    <?php echo t('preferences'); ?>
                                </button>
                            </li>
                        </ul>
                        
                        <div class="tab-content profile-tab-content" id="profileTabsContent">
                            <!-- المعلومات الشخصية -->
                            <div class="tab-pane fade show active" id="personal" role="tabpanel" aria-labelledby="personal-tab">
                                <form action="" method="post">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="profile-form-group">
                                                <label for="name" class="profile-form-label"><?php echo t('full_name'); ?></label>
                                                <input type="text" id="name" name="name" class="form-control profile-form-control" value="<?php echo $student['name']; ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="profile-form-group">
                                                <label for="email" class="profile-form-label"><?php echo t('email'); ?></label>
                                                <input type="email" id="email" name="email" class="form-control profile-form-control" value="<?php echo $student['email']; ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="profile-form-group">
                                                <label for="phone" class="profile-form-label"><?php echo t('phone'); ?></label>
                                                <input type="tel" id="phone" name="phone" class="form-control profile-form-control" value="<?php echo $student['phone']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="profile-form-group">
                                                <label for="address" class="profile-form-label"><?php echo t('address'); ?></label>
                                                <input type="text" id="address" name="address" class="form-control profile-form-control" value="<?php echo $student['address']; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="profile-form-group">
                                        <label for="bio" class="profile-form-label"><?php echo t('bio'); ?></label>
                                        <textarea id="bio" name="bio" class="form-control profile-form-control" rows="5"><?php echo $student['bio']; ?></textarea>
                                    </div>
                                    
                                    <div class="profile-form-group">
                                        <button type="submit" name="update_profile" class="btn profile-form-submit">
                                            <?php echo t('save_changes'); ?>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            
                            <!-- تغيير كلمة المرور -->
                            <div class="tab-pane fade" id="password" role="tabpanel" aria-labelledby="password-tab">
                                <form action="" method="post">
                                    <div class="profile-form-group">
                                        <label for="current_password" class="profile-form-label"><?php echo t('current_password'); ?></label>
                                        <input type="password" id="current_password" name="current_password" class="form-control profile-form-control" required>
                                    </div>
                                    
                                    <div class="profile-form-group">
                                        <label for="new_password" class="profile-form-label"><?php echo t('new_password'); ?></label>
                                        <input type="password" id="new_password" name="new_password" class="form-control profile-form-control" required>
                                        <small class="text-muted"><?php echo t('password_requirements'); ?></small>
                                    </div>
                                    
                                    <div class="profile-form-group">
                                        <label for="confirm_password" class="profile-form-label"><?php echo t('confirm_password'); ?></label>
                                        <input type="password" id="confirm_password" name="confirm_password" class="form-control profile-form-control" required>
                                    </div>
                                    
                                    <div class="profile-form-group">
                                        <button type="submit" name="update_password" class="btn profile-form-submit">
                                            <?php echo t('change_password'); ?>
                                        </button>
                                    </div>
                                </form>
                            </div>
                            
                            <!-- التفضيلات -->
                            <div class="tab-pane fade" id="preferences" role="tabpanel" aria-labelledby="preferences-tab">
                                <form action="" method="post">
                                    <div class="profile-form-group">
                                        <label class="profile-form-label"><?php echo t('language'); ?></label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="language" id="language_ar" value="ar" <?php echo $lang === 'ar' ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="language_ar">
                                                العربية
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="language" id="language_en" value="en" <?php echo $lang === 'en' ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="language_en">
                                                English
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <div class="profile-form-group">
                                        <label class="profile-form-label"><?php echo t('theme'); ?></label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="theme" id="theme_light" value="light" <?php echo $theme === 'light' ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="theme_light">
                                                <?php echo t('light'); ?>
                                            </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="theme" id="theme_dark" value="dark" <?php echo $theme === 'dark' ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="theme_dark">
                                                <?php echo t('dark'); ?>
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <div class="profile-form-group">
                                        <label class="profile-form-label"><?php echo t('notifications'); ?></label>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="email_notifications" checked>
                                            <label class="form-check-label" for="email_notifications">
                                                <?php echo t('email_notifications'); ?>
                                            </label>
                                        </div>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="sms_notifications" checked>
                                            <label class="form-check-label" for="sms_notifications">
                                                <?php echo t('sms_notifications'); ?>
                                            </label>
                                        </div>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="browser_notifications" checked>
                                            <label class="form-check-label" for="browser_notifications">
                                                <?php echo t('browser_notifications'); ?>
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <div class="profile-form-group">
                                        <button type="submit" name="update_preferences" class="btn profile-form-submit">
                                            <?php echo t('save_preferences'); ?>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- الإحصائيات الأكاديمية -->
                <div class="profile-container">
                    <div class="profile-header">
                        <h2 class="profile-title"><?php echo t('academic_statistics'); ?></h2>
                    </div>
                    <div class="profile-body">
                        <div class="row">
                            <div class="col-md-6">
                                <canvas id="gpaChart" width="400" height="300"></canvas>
                            </div>
                            <div class="col-md-6">
                                <canvas id="coursesChart" width="400" height="300"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال تغيير صورة الملف الشخصي -->
    <div class="modal fade" id="profileImageModal" tabindex="-1" aria-labelledby="profileImageModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="profileImageModalLabel"><?php echo t('change_profile_image'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="profile_image" class="form-label"><?php echo t('select_image'); ?></label>
                            <input class="form-control" type="file" id="profile_image" name="profile_image" accept="image/*" required>
                            <small class="text-muted"><?php echo t('image_requirements'); ?></small>
                        </div>
                        <div class="d-grid">
                            <button type="submit" name="update_profile_image" class="btn btn-primary">
                                <?php echo t('upload_image'); ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // رسم بياني للمعدل التراكمي
            const gpaCtx = document.getElementById('gpaChart').getContext('2d');
            const gpaChart = new Chart(gpaCtx, {
                type: 'line',
                data: {
                    labels: ['الفصل الأول', 'الفصل الثاني', 'الفصل الثالث', 'الفصل الرابع', 'الفصل الخامس'],
                    datasets: [{
                        label: 'المعدل التراكمي',
                        data: [3.5, 3.6, 3.7, 3.8, 3.85],
                        backgroundColor: 'rgba(0, 48, 73, 0.2)',
                        borderColor: 'rgba(0, 48, 73, 1)',
                        borderWidth: 2,
                        tension: 0.3
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'تطور المعدل التراكمي'
                        },
                        legend: {
                            position: 'bottom'
                        }
                    },
                    scales: {
                        y: {
                            min: 2,
                            max: 4
                        }
                    }
                }
            });
            
            // رسم بياني للمقررات
            const coursesCtx = document.getElementById('coursesChart').getContext('2d');
            const coursesChart = new Chart(coursesCtx, {
                type: 'doughnut',
                data: {
                    labels: ['علوم الحاسب', 'رياضيات', 'متطلبات جامعة', 'اختياري'],
                    datasets: [{
                        data: [45, 15, 10, 5],
                        backgroundColor: [
                            'rgba(0, 48, 73, 0.7)',
                            'rgba(102, 155, 188, 0.7)',
                            'rgba(214, 40, 40, 0.7)',
                            'rgba(247, 127, 0, 0.7)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'توزيع الساعات المعتمدة'
                        },
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
            
            // تغيير اللغة
            document.querySelectorAll('input[name="language"]').forEach(function(radio) {
                radio.addEventListener('change', function() {
                    document.cookie = `lang=${this.value}; path=/; max-age=31536000`;
                    window.location.reload();
                });
            });
            
            // تغيير المظهر
            document.querySelectorAll('input[name="theme"]').forEach(function(radio) {
                radio.addEventListener('change', function() {
                    document.cookie = `theme=${this.value}; path=/; max-age=31536000`;
                    document.body.className = `theme-${this.value}`;
                });
            });
            
            // زر تبديل المظهر
            document.getElementById('themeToggle').addEventListener('click', function() {
                const currentTheme = document.body.className.includes('theme-dark') ? 'dark' : 'light';
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.cookie = `theme=${newTheme}; path=/; max-age=31536000`;
                document.body.className = `theme-${newTheme}`;
                
                this.innerHTML = `<i class="fas fa-${newTheme === 'dark' ? 'sun' : 'moon'}"></i>`;
                
                // تحديث زر الراديو في التفضيلات
                document.getElementById(`theme_${newTheme}`).checked = true;
            });
        });
    </script>
</body>
</html>
