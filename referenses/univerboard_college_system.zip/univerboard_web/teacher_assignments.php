<?php
/**
 * صفحة إدارة الواجبات للمعلم في نظام UniverBoard
 * تتيح للمعلم عرض وإدارة الواجبات لجميع المقررات التي يدرسها
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول المعلم
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'teacher') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات المعلم
$teacher_id = $_SESSION['user_id'];
$db = get_db_connection();
$teacher = get_teacher_info($db, $teacher_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// الحصول على المقررات التي يدرسها المعلم
$courses = get_teacher_courses($db, $teacher_id);

// الحصول على الواجبات لجميع المقررات
$assignments = get_teacher_assignments($db, $teacher_id);

// معالجة البحث والتصفية
$search_query = isset($_GET['search']) ? filter_input(INPUT_GET, 'search', FILTER_SANITIZE_STRING) : '';
$filter_course = isset($_GET['course']) ? filter_input(INPUT_GET, 'course', FILTER_SANITIZE_STRING) : '';
$filter_status = isset($_GET['status']) ? filter_input(INPUT_GET, 'status', FILTER_SANITIZE_STRING) : '';

// تطبيق البحث والتصفية على الواجبات
if (!empty($search_query) || !empty($filter_course) || !empty($filter_status)) {
    $filtered_assignments = [];
    foreach ($assignments as $assignment) {
        $match_search = empty($search_query) || stripos($assignment['title'], $search_query) !== false || stripos($assignment['description'], $search_query) !== false;
        $match_course = empty($filter_course) || $assignment['course_id'] === $filter_course;
        $match_status = empty($filter_status) || $assignment['status'] === $filter_status;
        
        if ($match_search && $match_course && $match_status) {
            $filtered_assignments[] = $assignment;
        }
    }
    $assignments = $filtered_assignments;
}

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('assignments'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .assignment-card {
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 1.5rem;
            transition: all 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .assignment-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
        }
        
        .assignment-card-header {
            padding: 1.25rem;
            background-color: var(--primary-color);
            color: white;
            position: relative;
        }
        
        .assignment-card-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .assignment-card-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }
        
        .assignment-card-body {
            padding: 1.25rem;
            flex-grow: 1;
        }
        
        .assignment-card-footer {
            padding: 1rem 1.25rem;
            background-color: rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .theme-dark .assignment-card-footer {
            background-color: rgba(255, 255, 255, 0.05);
        }
        
        .assignment-card-stat {
            display: flex;
            align-items: center;
        }
        
        .assignment-card-stat i {
            margin-right: 0.5rem;
            opacity: 0.7;
        }
        
        [dir="rtl"] .assignment-card-stat i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .assignment-card-badge {
            position: absolute;
            top: 0;
            right: 1rem;
            transform: translateY(-50%);
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        [dir="rtl"] .assignment-card-badge {
            right: auto;
            left: 1rem;
        }
        
        .assignment-card-badge.active {
            background-color: #28a745;
            color: white;
        }
        
        .assignment-card-badge.upcoming {
            background-color: #ffc107;
            color: #212529;
        }
        
        .assignment-card-badge.expired {
            background-color: #dc3545;
            color: white;
        }
        
        .assignment-card-badge.draft {
            background-color: #6c757d;
            color: white;
        }
        
        .assignment-card-actions {
            position: absolute;
            top: 1rem;
            right: 1rem;
        }
        
        [dir="rtl"] .assignment-card-actions {
            right: auto;
            left: 1rem;
        }
        
        .assignment-card-actions .dropdown-toggle::after {
            display: none;
        }
        
        .assignment-card-actions .dropdown-toggle {
            color: white;
            background: none;
            border: none;
            font-size: 1.25rem;
        }
        
        .assignment-card-actions .dropdown-menu {
            min-width: 200px;
        }
        
        .assignment-card-actions .dropdown-item {
            padding: 0.5rem 1rem;
            display: flex;
            align-items: center;
        }
        
        .assignment-card-actions .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .assignment-card-actions .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .assignment-list-item {
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 1rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: stretch;
        }
        
        .assignment-list-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
        }
        
        .assignment-list-color {
            width: 10px;
            background-color: var(--primary-color);
        }
        
        .assignment-list-content {
            padding: 1.25rem;
            flex-grow: 1;
            display: flex;
            align-items: center;
        }
        
        .assignment-list-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-right: 1.25rem;
            flex-shrink: 0;
        }
        
        [dir="rtl"] .assignment-list-icon {
            margin-right: 0;
            margin-left: 1.25rem;
        }
        
        .assignment-list-details {
            flex-grow: 1;
        }
        
        .assignment-list-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
            font-size: 1.1rem;
        }
        
        .assignment-list-subtitle {
            font-size: 0.9rem;
            color: var(--gray-color);
            margin-bottom: 0.5rem;
        }
        
        .assignment-list-stats {
            display: flex;
            align-items: center;
            font-size: 0.85rem;
            color: var(--gray-color);
        }
        
        .assignment-list-stat {
            display: flex;
            align-items: center;
            margin-right: 1rem;
        }
        
        [dir="rtl"] .assignment-list-stat {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .assignment-list-stat i {
            margin-right: 0.5rem;
            opacity: 0.7;
        }
        
        [dir="rtl"] .assignment-list-stat i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .assignment-list-actions {
            display: flex;
            align-items: center;
            padding: 1.25rem;
            background-color: rgba(0, 0, 0, 0.02);
        }
        
        .theme-dark .assignment-list-actions {
            background-color: rgba(255, 255, 255, 0.02);
        }
        
        .assignment-list-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 600;
            margin-right: 1rem;
        }
        
        [dir="rtl"] .assignment-list-badge {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .assignment-list-badge.active {
            background-color: #28a745;
            color: white;
        }
        
        .assignment-list-badge.upcoming {
            background-color: #ffc107;
            color: #212529;
        }
        
        .assignment-list-badge.expired {
            background-color: #dc3545;
            color: white;
        }
        
        .assignment-list-badge.draft {
            background-color: #6c757d;
            color: white;
        }
        
        .filter-card {
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            padding: 1.25rem;
            margin-bottom: 1.5rem;
        }
        
        .filter-title {
            font-weight: 600;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .filter-title {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .filter-group {
            margin-bottom: 1rem;
        }
        
        .filter-group:last-child {
            margin-bottom: 0;
        }
        
        .filter-label {
            font-weight: 500;
            margin-bottom: 0.5rem;
            display: block;
        }
        
        .filter-control {
            width: 100%;
            padding: 0.5rem;
            border-radius: 0.25rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .filter-control {
            background-color: var(--dark-bg);
            border-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .filter-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(0, 48, 73, 0.25);
        }
        
        .filter-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 1rem;
        }
        
        .view-toggle {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .view-toggle-btn {
            padding: 0.5rem 1rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
            background-color: white;
            color: var(--text-color);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .theme-dark .view-toggle-btn {
            background-color: var(--dark-bg);
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .view-toggle-btn:first-child {
            border-top-left-radius: 0.25rem;
            border-bottom-left-radius: 0.25rem;
        }
        
        .view-toggle-btn:last-child {
            border-top-right-radius: 0.25rem;
            border-bottom-right-radius: 0.25rem;
        }
        
        [dir="rtl"] .view-toggle-btn:first-child {
            border-radius: 0;
            border-top-right-radius: 0.25rem;
            border-bottom-right-radius: 0.25rem;
        }
        
        [dir="rtl"] .view-toggle-btn:last-child {
            border-radius: 0;
            border-top-left-radius: 0.25rem;
            border-bottom-left-radius: 0.25rem;
        }
        
        .view-toggle-btn.active {
            background-color: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        
        .view-toggle-btn i {
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .view-toggle-btn i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background-color: rgba(0, 0, 0, 0.02);
            border-radius: 0.5rem;
        }
        
        .theme-dark .empty-state {
            background-color: rgba(255, 255, 255, 0.02);
        }
        
        .empty-state-icon {
            font-size: 4rem;
            color: var(--gray-color);
            margin-bottom: 1.5rem;
        }
        
        .empty-state-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 1rem;
        }
        
        .empty-state-text {
            color: var(--gray-color);
            margin-bottom: 1.5rem;
        }
        
        .deadline-indicator {
            display: flex;
            align-items: center;
            margin-top: 0.5rem;
        }
        
        .deadline-indicator-icon {
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .deadline-indicator-icon {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .deadline-indicator-text {
            font-size: 0.85rem;
        }
        
        .deadline-indicator.upcoming {
            color: #28a745;
        }
        
        .deadline-indicator.near {
            color: #ffc107;
        }
        
        .deadline-indicator.expired {
            color: #dc3545;
        }
        
        .progress-small {
            height: 5px;
            margin-top: 0.5rem;
            margin-bottom: 0.5rem;
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="teacher_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="teacher_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_students.php">
                        <i class="fas fa-user-graduate"></i> <?php echo t('students'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="teacher_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="teacher_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-user-graduate"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">قام الطالب أحمد محمد بتسليم واجب جديد</p>
                                    <small class="text-muted">منذ 10 دقائق</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-calendar-alt"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تذكير: موعد محاضرة برمجة الويب غداً</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-info text-white rounded-circle">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">رسالة جديدة من رئيس القسم</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="teacher_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/student1.jpg" alt="Student" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">سارة أحمد</p>
                                    <small class="text-muted">هل يمكنني الحصول على مساعدة في المشروع النهائي؟</small>
                                    <small class="text-muted d-block">منذ 15 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/student2.jpg" alt="Student" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">محمد علي</p>
                                    <small class="text-muted">أستاذ، هل يمكنني تأجيل موعد تسليم الواجب؟</small>
                                    <small class="text-muted d-block">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="teacher_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $teacher['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $teacher['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $teacher['name']; ?></h6>
                            <small><?php echo $teacher['title']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="teacher_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="teacher_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <div>
                <h1 class="h3"><?php echo t('assignments'); ?></h1>
                <p class="text-muted"><?php echo t('manage_your_assignments'); ?></p>
            </div>
            <div>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createAssignmentModal">
                    <i class="fas fa-plus me-1"></i> <?php echo t('create_new_assignment'); ?>
                </button>
            </div>
        </div>
        
        <!-- أدوات البحث والتصفية -->
        <div class="row mb-4">
            <div class="col-md-8">
                <form action="" method="get" class="d-flex">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="<?php echo t('search_assignments'); ?>" name="search" value="<?php echo htmlspecialchars($search_query); ?>">
                        <button class="btn btn-primary" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>
            <div class="col-md-4">
                <div class="view-toggle float-end">
                    <button class="view-toggle-btn active" data-view="grid">
                        <i class="fas fa-th"></i> <?php echo t('grid'); ?>
                    </button>
                    <button class="view-toggle-btn" data-view="list">
                        <i class="fas fa-list"></i> <?php echo t('list'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- فلاتر جانبية -->
            <div class="col-lg-3">
                <div class="filter-card">
                    <h5 class="filter-title"><?php echo t('filters'); ?></h5>
                    <form action="" method="get">
                        <?php if (!empty($search_query)): ?>
                            <input type="hidden" name="search" value="<?php echo htmlspecialchars($search_query); ?>">
                        <?php endif; ?>
                        
                        <div class="filter-group">
                            <label class="filter-label"><?php echo t('course'); ?></label>
                            <select name="course" class="filter-control">
                                <option value=""><?php echo t('all_courses'); ?></option>
                                <?php foreach ($courses as $course): ?>
                                    <option value="<?php echo $course['id']; ?>" <?php echo $filter_course === $course['id'] ? 'selected' : ''; ?>>
                                        <?php echo $course['name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label class="filter-label"><?php echo t('status'); ?></label>
                            <select name="status" class="filter-control">
                                <option value=""><?php echo t('all_statuses'); ?></option>
                                <option value="active" <?php echo $filter_status === 'active' ? 'selected' : ''; ?>><?php echo t('active'); ?></option>
                                <option value="upcoming" <?php echo $filter_status === 'upcoming' ? 'selected' : ''; ?>><?php echo t('upcoming'); ?></option>
                                <option value="expired" <?php echo $filter_status === 'expired' ? 'selected' : ''; ?>><?php echo t('expired'); ?></option>
                                <option value="draft" <?php echo $filter_status === 'draft' ? 'selected' : ''; ?>><?php echo t('draft'); ?></option>
                            </select>
                        </div>
                        
                        <div class="filter-actions">
                            <button type="submit" class="btn btn-primary btn-sm">
                                <?php echo t('apply_filters'); ?>
                            </button>
                            <a href="teacher_assignments.php" class="btn btn-outline-secondary btn-sm">
                                <?php echo t('clear_filters'); ?>
                            </a>
                        </div>
                    </form>
                </div>
                
                <div class="filter-card">
                    <h5 class="filter-title"><?php echo t('quick_stats'); ?></h5>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span><?php echo t('active_assignments'); ?></span>
                            <span class="fw-bold">
                                <?php
                                $active_count = 0;
                                foreach ($assignments as $assignment) {
                                    if ($assignment['status'] === 'active') {
                                        $active_count++;
                                    }
                                }
                                echo $active_count;
                                ?>
                            </span>
                        </div>
                        <div class="progress" style="height: 5px;">
                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo count($assignments) > 0 ? ($active_count / count($assignments) * 100) : 0; ?>%;" aria-valuenow="<?php echo $active_count; ?>" aria-valuemin="0" aria-valuemax="<?php echo count($assignments); ?>"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span><?php echo t('upcoming_assignments'); ?></span>
                            <span class="fw-bold">
                                <?php
                                $upcoming_count = 0;
                                foreach ($assignments as $assignment) {
                                    if ($assignment['status'] === 'upcoming') {
                                        $upcoming_count++;
                                    }
                                }
                                echo $upcoming_count;
                                ?>
                            </span>
                        </div>
                        <div class="progress" style="height: 5px;">
                            <div class="progress-bar bg-warning" role="progressbar" style="width: <?php echo count($assignments) > 0 ? ($upcoming_count / count($assignments) * 100) : 0; ?>%;" aria-valuenow="<?php echo $upcoming_count; ?>" aria-valuemin="0" aria-valuemax="<?php echo count($assignments); ?>"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span><?php echo t('expired_assignments'); ?></span>
                            <span class="fw-bold">
                                <?php
                                $expired_count = 0;
                                foreach ($assignments as $assignment) {
                                    if ($assignment['status'] === 'expired') {
                                        $expired_count++;
                                    }
                                }
                                echo $expired_count;
                                ?>
                            </span>
                        </div>
                        <div class="progress" style="height: 5px;">
                            <div class="progress-bar bg-danger" role="progressbar" style="width: <?php echo count($assignments) > 0 ? ($expired_count / count($assignments) * 100) : 0; ?>%;" aria-valuenow="<?php echo $expired_count; ?>" aria-valuemin="0" aria-valuemax="<?php echo count($assignments); ?>"></div>
                        </div>
                    </div>
                    
                    <div>
                        <div class="d-flex justify-content-between mb-1">
                            <span><?php echo t('draft_assignments'); ?></span>
                            <span class="fw-bold">
                                <?php
                                $draft_count = 0;
                                foreach ($assignments as $assignment) {
                                    if ($assignment['status'] === 'draft') {
                                        $draft_count++;
                                    }
                                }
                                echo $draft_count;
                                ?>
                            </span>
                        </div>
                        <div class="progress" style="height: 5px;">
                            <div class="progress-bar bg-secondary" role="progressbar" style="width: <?php echo count($assignments) > 0 ? ($draft_count / count($assignments) * 100) : 0; ?>%;" aria-valuenow="<?php echo $draft_count; ?>" aria-valuemin="0" aria-valuemax="<?php echo count($assignments); ?>"></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- قائمة الواجبات -->
            <div class="col-lg-9">
                <?php if (count($assignments) > 0): ?>
                    <!-- عرض الشبكة -->
                    <div class="view-content" id="gridView">
                        <div class="row">
                            <?php foreach ($assignments as $assignment): ?>
                                <div class="col-md-6 col-lg-4 mb-4">
                                    <div class="assignment-card">
                                        <div class="assignment-card-header">
                                            <h5 class="assignment-card-title"><?php echo $assignment['title']; ?></h5>
                                            <div class="assignment-card-subtitle">
                                                <?php
                                                foreach ($courses as $course) {
                                                    if ($course['id'] === $assignment['course_id']) {
                                                        echo $course['name'];
                                                        break;
                                                    }
                                                }
                                                ?>
                                            </div>
                                            <div class="assignment-card-actions">
                                                <div class="dropdown">
                                                    <button class="dropdown-toggle" type="button" id="assignmentActions<?php echo $assignment['id']; ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="fas fa-ellipsis-v"></i>
                                                    </button>
                                                    <ul class="dropdown-menu" aria-labelledby="assignmentActions<?php echo $assignment['id']; ?>">
                                                        <li>
                                                            <a class="dropdown-item" href="teacher_assignment_details.php?id=<?php echo $assignment['id']; ?>">
                                                                <i class="fas fa-eye"></i> <?php echo t('view_details'); ?>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a class="dropdown-item" href="teacher_assignment_edit.php?id=<?php echo $assignment['id']; ?>">
                                                                <i class="fas fa-edit"></i> <?php echo t('edit_assignment'); ?>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a class="dropdown-item" href="teacher_assignment_submissions.php?id=<?php echo $assignment['id']; ?>">
                                                                <i class="fas fa-file-upload"></i> <?php echo t('view_submissions'); ?>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a class="dropdown-item" href="teacher_assignment_grades.php?id=<?php echo $assignment['id']; ?>">
                                                                <i class="fas fa-chart-line"></i> <?php echo t('manage_grades'); ?>
                                                            </a>
                                                        </li>
                                                        <li><hr class="dropdown-divider"></li>
                                                        <li>
                                                            <a class="dropdown-item text-danger" href="#" data-bs-toggle="modal" data-bs-target="#deleteAssignmentModal" data-assignment-id="<?php echo $assignment['id']; ?>" data-assignment-title="<?php echo $assignment['title']; ?>">
                                                                <i class="fas fa-trash-alt"></i> <?php echo t('delete_assignment'); ?>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="assignment-card-body">
                                            <div class="position-relative">
                                                <span class="assignment-card-badge <?php echo $assignment['status']; ?>">
                                                    <?php echo t($assignment['status']); ?>
                                                </span>
                                            </div>
                                            <p class="mt-3"><?php echo substr($assignment['description'], 0, 100); ?>...</p>
                                            
                                            <?php
                                            // تحديد نوع مؤشر الموعد النهائي
                                            $deadline_class = 'upcoming';
                                            $deadline_icon = 'fa-clock';
                                            $deadline_text = t('days_remaining', ['days' => $assignment['days_remaining']]);
                                            
                                            if ($assignment['days_remaining'] <= 0) {
                                                $deadline_class = 'expired';
                                                $deadline_icon = 'fa-times-circle';
                                                $deadline_text = t('deadline_passed');
                                            } elseif ($assignment['days_remaining'] <= 3) {
                                                $deadline_class = 'near';
                                                $deadline_icon = 'fa-exclamation-circle';
                                                $deadline_text = t('deadline_approaching', ['days' => $assignment['days_remaining']]);
                                            }
                                            ?>
                                            
                                            <div class="deadline-indicator <?php echo $deadline_class; ?>">
                                                <i class="fas <?php echo $deadline_icon; ?> deadline-indicator-icon"></i>
                                                <span class="deadline-indicator-text"><?php echo $deadline_text; ?></span>
                                            </div>
                                            
                                            <div class="mt-3">
                                                <div class="d-flex justify-content-between">
                                                    <small><?php echo t('submissions'); ?></small>
                                                    <small><?php echo $assignment['submissions_count']; ?>/<?php echo $assignment['students_count']; ?></small>
                                                </div>
                                                <div class="progress progress-small">
                                                    <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo $assignment['students_count'] > 0 ? ($assignment['submissions_count'] / $assignment['students_count'] * 100) : 0; ?>%;" aria-valuenow="<?php echo $assignment['submissions_count']; ?>" aria-valuemin="0" aria-valuemax="<?php echo $assignment['students_count']; ?>"></div>
                                                </div>
                                            </div>
                                            
                                            <div class="mt-2">
                                                <div class="d-flex justify-content-between">
                                                    <small><?php echo t('graded'); ?></small>
                                                    <small><?php echo $assignment['graded_count']; ?>/<?php echo $assignment['submissions_count']; ?></small>
                                                </div>
                                                <div class="progress progress-small">
                                                    <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $assignment['submissions_count'] > 0 ? ($assignment['graded_count'] / $assignment['submissions_count'] * 100) : 0; ?>%;" aria-valuenow="<?php echo $assignment['graded_count']; ?>" aria-valuemin="0" aria-valuemax="<?php echo $assignment['submissions_count']; ?>"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="assignment-card-footer">
                                            <div class="assignment-card-stat">
                                                <i class="fas fa-calendar-alt"></i> <?php echo $assignment['due_date']; ?>
                                            </div>
                                            <a href="teacher_assignment_details.php?id=<?php echo $assignment['id']; ?>" class="btn btn-sm btn-primary"><?php echo t('manage'); ?></a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- عرض القائمة -->
                    <div class="view-content d-none" id="listView">
                        <?php foreach ($assignments as $assignment): ?>
                            <div class="assignment-list-item">
                                <div class="assignment-list-color"></div>
                                <div class="assignment-list-content">
                                    <div class="assignment-list-icon">
                                        <i class="fas fa-tasks"></i>
                                    </div>
                                    <div class="assignment-list-details">
                                        <h5 class="assignment-list-title"><?php echo $assignment['title']; ?></h5>
                                        <div class="assignment-list-subtitle">
                                            <?php
                                            foreach ($courses as $course) {
                                                if ($course['id'] === $assignment['course_id']) {
                                                    echo $course['name'];
                                                    break;
                                                }
                                            }
                                            ?>
                                        </div>
                                        <div class="assignment-list-stats">
                                            <div class="assignment-list-stat">
                                                <i class="fas fa-calendar-alt"></i> <?php echo $assignment['due_date']; ?>
                                            </div>
                                            <div class="assignment-list-stat">
                                                <i class="fas fa-file-upload"></i> <?php echo $assignment['submissions_count']; ?>/<?php echo $assignment['students_count']; ?> <?php echo t('submissions'); ?>
                                            </div>
                                            <div class="assignment-list-stat">
                                                <i class="fas fa-check-circle"></i> <?php echo $assignment['graded_count']; ?>/<?php echo $assignment['submissions_count']; ?> <?php echo t('graded'); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="assignment-list-actions">
                                    <span class="assignment-list-badge <?php echo $assignment['status']; ?>">
                                        <?php echo t($assignment['status']); ?>
                                    </span>
                                    <a href="teacher_assignment_details.php?id=<?php echo $assignment['id']; ?>" class="btn btn-sm btn-primary"><?php echo t('manage'); ?></a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <!-- حالة عدم وجود واجبات -->
                    <div class="empty-state">
                        <div class="empty-state-icon">
                            <i class="fas fa-tasks"></i>
                        </div>
                        <h3 class="empty-state-title"><?php echo t('no_assignments_found'); ?></h3>
                        <p class="empty-state-text"><?php echo t('no_assignments_message'); ?></p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createAssignmentModal">
                            <i class="fas fa-plus me-1"></i> <?php echo t('create_new_assignment'); ?>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- مودال إنشاء واجب جديد -->
    <div class="modal fade" id="createAssignmentModal" tabindex="-1" aria-labelledby="createAssignmentModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="createAssignmentModalLabel"><?php echo t('create_new_assignment'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="createAssignmentForm">
                        <div class="row mb-3">
                            <div class="col-md-8">
                                <label for="assignmentTitle" class="form-label"><?php echo t('assignment_title'); ?> <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="assignmentTitle" name="title" required>
                            </div>
                            <div class="col-md-4">
                                <label for="assignmentCourse" class="form-label"><?php echo t('course'); ?> <span class="text-danger">*</span></label>
                                <select class="form-select" id="assignmentCourse" name="course_id" required>
                                    <option value=""><?php echo t('select_course'); ?></option>
                                    <?php foreach ($courses as $course): ?>
                                        <option value="<?php echo $course['id']; ?>"><?php echo $course['name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="assignmentDescription" class="form-label"><?php echo t('description'); ?> <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="assignmentDescription" name="description" rows="4" required></textarea>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="assignmentStartDate" class="form-label"><?php echo t('start_date'); ?> <span class="text-danger">*</span></label>
                                <input type="datetime-local" class="form-control" id="assignmentStartDate" name="start_date" required>
                            </div>
                            <div class="col-md-6">
                                <label for="assignmentDueDate" class="form-label"><?php echo t('due_date'); ?> <span class="text-danger">*</span></label>
                                <input type="datetime-local" class="form-control" id="assignmentDueDate" name="due_date" required>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="assignmentTotalMarks" class="form-label"><?php echo t('total_marks'); ?> <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="assignmentTotalMarks" name="total_marks" min="1" required>
                            </div>
                            <div class="col-md-6">
                                <label for="assignmentStatus" class="form-label"><?php echo t('status'); ?> <span class="text-danger">*</span></label>
                                <select class="form-select" id="assignmentStatus" name="status" required>
                                    <option value=""><?php echo t('select_status'); ?></option>
                                    <option value="active"><?php echo t('active'); ?></option>
                                    <option value="upcoming"><?php echo t('upcoming'); ?></option>
                                    <option value="draft"><?php echo t('draft'); ?></option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="assignmentAttachments" class="form-label"><?php echo t('attachments'); ?></label>
                            <input type="file" class="form-control" id="assignmentAttachments" name="attachments[]" multiple>
                            <div class="form-text"><?php echo t('attachments_hint'); ?></div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label"><?php echo t('assignment_options'); ?></label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="assignmentAllowLateSubmission" name="allow_late_submission">
                                <label class="form-check-label" for="assignmentAllowLateSubmission">
                                    <?php echo t('allow_late_submission'); ?>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="assignmentAllowResubmission" name="allow_resubmission">
                                <label class="form-check-label" for="assignmentAllowResubmission">
                                    <?php echo t('allow_resubmission'); ?>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="assignmentSendNotification" name="send_notification" checked>
                                <label class="form-check-label" for="assignmentSendNotification">
                                    <?php echo t('send_notification_to_students'); ?>
                                </label>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="button" class="btn btn-primary" id="createAssignmentBtn"><?php echo t('create_assignment'); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال حذف واجب -->
    <div class="modal fade" id="deleteAssignmentModal" tabindex="-1" aria-labelledby="deleteAssignmentModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteAssignmentModalLabel"><?php echo t('delete_assignment'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p><?php echo t('delete_assignment_confirmation'); ?> <strong id="deleteAssignmentTitleSpan"></strong>؟</p>
                    <p class="text-danger"><?php echo t('delete_assignment_warning'); ?></p>
                    <div class="mb-3">
                        <label for="deleteConfirmation" class="form-label"><?php echo t('type_delete_to_confirm'); ?></label>
                        <input type="text" class="form-control" id="deleteConfirmation" placeholder="delete">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="button" class="btn btn-danger" id="deleteAssignmentBtn" disabled><?php echo t('delete'); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // زر تبديل المظهر
            document.getElementById('themeToggle').addEventListener('click', function() {
                const currentTheme = document.body.className.includes('theme-dark') ? 'dark' : 'light';
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.cookie = `theme=${newTheme}; path=/; max-age=31536000`;
                document.body.className = `theme-${newTheme}`;
                
                this.innerHTML = `<i class="fas fa-${newTheme === 'dark' ? 'sun' : 'moon'}"></i>`;
            });
            
            // تبديل طريقة العرض (شبكة/قائمة)
            document.querySelectorAll('.view-toggle-btn').forEach(button => {
                button.addEventListener('click', function() {
                    // إزالة الفئة النشطة من جميع الأزرار
                    document.querySelectorAll('.view-toggle-btn').forEach(btn => {
                        btn.classList.remove('active');
                    });
                    
                    // إضافة الفئة النشطة إلى الزر المحدد
                    this.classList.add('active');
                    
                    // تحديث طريقة العرض
                    const view = this.getAttribute('data-view');
                    
                    if (view === 'grid') {
                        document.getElementById('gridView').classList.remove('d-none');
                        document.getElementById('listView').classList.add('d-none');
                    } else if (view === 'list') {
                        document.getElementById('gridView').classList.add('d-none');
                        document.getElementById('listView').classList.remove('d-none');
                    }
                });
            });
            
            // مودال حذف واجب
            const deleteAssignmentModal = document.getElementById('deleteAssignmentModal');
            if (deleteAssignmentModal) {
                deleteAssignmentModal.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    const assignmentId = button.getAttribute('data-assignment-id');
                    const assignmentTitle = button.getAttribute('data-assignment-title');
                    
                    document.getElementById('deleteAssignmentTitleSpan').textContent = assignmentTitle;
                    
                    // تعطيل زر الحذف حتى يتم تأكيد الحذف
                    document.getElementById('deleteAssignmentBtn').disabled = true;
                    document.getElementById('deleteConfirmation').value = '';
                    
                    // تمكين زر الحذف عند كتابة "delete"
                    document.getElementById('deleteConfirmation').addEventListener('input', function() {
                        document.getElementById('deleteAssignmentBtn').disabled = this.value !== 'delete';
                    });
                    
                    // إجراء الحذف عند النقر على زر الحذف
                    document.getElementById('deleteAssignmentBtn').onclick = function() {
                        if (document.getElementById('deleteConfirmation').value === 'delete') {
                            // هنا يمكن إضافة كود لحذف الواجب
                            alert('تم حذف الواجب: ' + assignmentTitle);
                            
                            // إغلاق المودال
                            const modal = bootstrap.Modal.getInstance(deleteAssignmentModal);
                            modal.hide();
                        }
                    };
                });
            }
            
            // إنشاء واجب جديد
            document.getElementById('createAssignmentBtn').addEventListener('click', function() {
                const form = document.getElementById('createAssignmentForm');
                
                // التحقق من صحة النموذج
                if (form.checkValidity()) {
                    // هنا يمكن إضافة كود لإنشاء الواجب
                    alert('تم إنشاء الواجب بنجاح!');
                    
                    // إغلاق المودال
                    const modal = bootstrap.Modal.getInstance(document.getElementById('createAssignmentModal'));
                    modal.hide();
                } else {
                    form.reportValidity();
                }
            });
        });
    </script>
</body>
</html>
