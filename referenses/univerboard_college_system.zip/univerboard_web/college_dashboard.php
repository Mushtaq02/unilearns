<?php
/**
 * صفحة لوحة تحكم الكلية في نظام UniverBoard
 * تعرض ملخص البيانات والإحصائيات الخاصة بالكلية
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول مسؤول الكلية
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'college_admin') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات مسؤول الكلية
$admin_id = $_SESSION['user_id'];
$db = get_db_connection();
$admin = get_college_admin_info($db, $admin_id);
$college_id = $admin['college_id'];
$college = get_college_info($db, $college_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// الحصول على إحصائيات الكلية
$stats = get_college_statistics($db, $college_id);

// الحصول على آخر الأنشطة في الكلية
$recent_activities = get_college_recent_activities($db, $college_id, 10);

// الحصول على قائمة الأقسام في الكلية
$departments = get_college_departments($db, $college_id);

// الحصول على قائمة البرامج الأكاديمية في الكلية
$programs = get_college_programs($db, $college_id);

// الحصول على قائمة المعلمين في الكلية
$teachers = get_college_teachers($db, $college_id, 5);

// الحصول على قائمة الطلاب في الكلية
$students = get_college_students($db, $college_id, 5);

// الحصول على قائمة المقررات في الكلية
$courses = get_college_courses($db, $college_id, 5);

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('college_dashboard'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            width: 250px;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .dashboard-header {
            margin-bottom: 2rem;
        }
        
        .dashboard-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .dashboard-subtitle {
            color: var(--gray-color);
        }
        
        .dashboard-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            padding: 1.5rem;
            height: 100%;
            transition: all 0.3s ease;
        }
        
        .theme-dark .dashboard-card {
            background-color: var(--dark-bg);
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .dashboard-card:hover {
            box-shadow: 0 5px 15px rgba(255, 255, 255, 0.05);
        }
        
        .stat-card {
            display: flex;
            align-items: center;
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            margin-right: 1rem;
            color: white;
        }
        
        [dir="rtl"] .stat-icon {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .stat-icon-students {
            background-color: #4CAF50;
        }
        
        .stat-icon-teachers {
            background-color: #2196F3;
        }
        
        .stat-icon-courses {
            background-color: #FF9800;
        }
        
        .stat-icon-departments {
            background-color: #9C27B0;
        }
        
        .stat-info {
            flex-grow: 1;
        }
        
        .stat-value {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .stat-label {
            color: var(--gray-color);
            font-size: 0.85rem;
        }
        
        .chart-container {
            position: relative;
            height: 300px;
        }
        
        .activity-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .activity-item {
            display: flex;
            align-items: flex-start;
            padding: 1rem 0;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .theme-dark .activity-item {
            border-color: rgba(255, 255, 255, 0.05);
        }
        
        .activity-item:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            margin-right: 1rem;
            color: white;
            flex-shrink: 0;
        }
        
        [dir="rtl"] .activity-icon {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .activity-icon-add {
            background-color: #4CAF50;
        }
        
        .activity-icon-update {
            background-color: #2196F3;
        }
        
        .activity-icon-delete {
            background-color: #F44336;
        }
        
        .activity-icon-info {
            background-color: #9C27B0;
        }
        
        .activity-content {
            flex-grow: 1;
        }
        
        .activity-title {
            font-weight: 500;
            margin-bottom: 0.25rem;
        }
        
        .activity-time {
            font-size: 0.75rem;
            color: var(--gray-color);
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin: 0;
        }
        
        .section-action {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
        }
        
        .section-action:hover {
            text-decoration: underline;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        .table {
            width: 100%;
            margin-bottom: 0;
        }
        
        .table th {
            font-weight: 600;
            border-top: none;
        }
        
        .table td, .table th {
            padding: 0.75rem;
            vertical-align: middle;
        }
        
        .table-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .table-avatar {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .badge-department {
            background-color: rgba(0, 48, 73, 0.1);
            color: var(--primary-color);
            font-weight: 500;
            padding: 0.35rem 0.65rem;
            border-radius: 0.25rem;
        }
        
        .theme-dark .badge-department {
            background-color: rgba(0, 48, 73, 0.3);
        }
        
        .badge-program {
            background-color: rgba(102, 155, 188, 0.1);
            color: #669bbc;
            font-weight: 500;
            padding: 0.35rem 0.65rem;
            border-radius: 0.25rem;
        }
        
        .theme-dark .badge-program {
            background-color: rgba(102, 155, 188, 0.3);
        }
        
        .college-info {
            display: flex;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .college-logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 1.5rem;
            border: 3px solid white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        [dir="rtl"] .college-logo {
            margin-right: 0;
            margin-left: 1.5rem;
        }
        
        .theme-dark .college-logo {
            border-color: var(--dark-bg);
        }
        
        .college-details {
            flex-grow: 1;
        }
        
        .college-name {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .college-meta {
            color: var(--gray-color);
            font-size: 0.9rem;
        }
        
        .college-meta i {
            margin-right: 0.25rem;
        }
        
        [dir="rtl"] .college-meta i {
            margin-right: 0;
            margin-left: 0.25rem;
        }
        
        .quick-actions {
            display: flex;
            gap: 0.5rem;
        }
        
        .quick-action-btn {
            padding: 0.5rem 1rem;
            border-radius: 0.25rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            transition: all 0.2s ease;
        }
        
        .quick-action-btn i {
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .quick-action-btn i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #002135;
            border-color: #002135;
        }
        
        .btn-secondary {
            background-color: #669bbc;
            border-color: #669bbc;
        }
        
        .btn-secondary:hover {
            background-color: #5589a7;
            border-color: #5589a7;
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link active" href="college_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_departments.php">
                        <i class="fas fa-building"></i> <?php echo t('departments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_programs.php">
                        <i class="fas fa-graduation-cap"></i> <?php echo t('academic_programs'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_teachers.php">
                        <i class="fas fa-chalkboard-teacher"></i> <?php echo t('teachers'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_students.php">
                        <i class="fas fa-user-graduate"></i> <?php echo t('students'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('reports'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="college_reports_academic.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('academic_reports'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_reports_attendance.php">
                        <i class="fas fa-clipboard-check"></i> <?php echo t('attendance_reports'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_reports_performance.php">
                        <i class="fas fa-chart-bar"></i> <?php echo t('performance_reports'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="college_announcements.php">
                        <i class="fas fa-bullhorn"></i> <?php echo t('announcements'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('settings'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="college_profile.php">
                        <i class="fas fa-university"></i> <?php echo t('college_profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">5</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-user-graduate"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تسجيل 15 طالب جديد في قسم علوم الحاسب</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-calendar-alt"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تحديث جدول الامتحانات النهائية</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-info text-white rounded-circle">
                                        <i class="fas fa-chalkboard-teacher"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تعيين د. محمد أحمد كرئيس لقسم الهندسة المدنية</p>
                                    <small class="text-muted">منذ 3 ساعات</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-success text-white rounded-circle">
                                        <i class="fas fa-book"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم إضافة 3 مقررات جديدة لبرنامج هندسة البرمجيات</p>
                                    <small class="text-muted">منذ 5 ساعات</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-danger text-white rounded-circle">
                                        <i class="fas fa-exclamation-triangle"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تنبيه: نسبة الحضور في مقرر الرياضيات 101 أقل من 70%</p>
                                    <small class="text-muted">منذ 6 ساعات</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="college_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/dean.jpg" alt="Dean" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. عبدالله العمري</p>
                                    <small class="text-muted">نرجو مراجعة الميزانية المقترحة للعام القادم</small>
                                    <small class="text-muted d-block">منذ 20 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/department_head.jpg" alt="Department Head" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. سارة الأحمد</p>
                                    <small class="text-muted">هل يمكننا مناقشة توزيع المقررات للفصل القادم؟</small>
                                    <small class="text-muted d-block">منذ ساعتين</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/admin.jpg" alt="Admin" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">أ. محمد الشمري</p>
                                    <small class="text-muted">تم الانتهاء من تجهيز القاعات الدراسية الجديدة</small>
                                    <small class="text-muted d-block">منذ 4 ساعات</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="college_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $admin['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $admin['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $admin['name']; ?></h6>
                            <small><?php echo t('college_admin'); ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="college_profile.php">
                            <i class="fas fa-university"></i> <?php echo t('college_profile'); ?>
                        </a>
                        <a class="dropdown-item" href="college_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- معلومات الكلية -->
        <div class="college-info mt-4">
            <img src="<?php echo $college['logo'] ?: 'assets/images/college-logo.png'; ?>" alt="<?php echo $college['name']; ?>" class="college-logo">
            <div class="college-details">
                <h1 class="college-name"><?php echo $college['name']; ?></h1>
                <div class="college-meta">
                    <span><i class="fas fa-map-marker-alt"></i> <?php echo $college['location']; ?></span>
                    <span class="mx-2">|</span>
                    <span><i class="fas fa-phone"></i> <?php echo $college['phone']; ?></span>
                    <span class="mx-2">|</span>
                    <span><i class="fas fa-envelope"></i> <?php echo $college['email']; ?></span>
                </div>
            </div>
            <div class="quick-actions">
                <a href="college_announcements.php?action=new" class="btn btn-primary quick-action-btn">
                    <i class="fas fa-bullhorn"></i> <?php echo t('new_announcement'); ?>
                </a>
                <a href="college_reports_academic.php" class="btn btn-secondary quick-action-btn">
                    <i class="fas fa-chart-line"></i> <?php echo t('view_reports'); ?>
                </a>
            </div>
        </div>
        
        <!-- الإحصائيات -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="dashboard-card">
                    <div class="stat-card">
                        <div class="stat-icon stat-icon-students">
                            <i class="fas fa-user-graduate"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-value"><?php echo number_format($stats['students_count']); ?></div>
                            <div class="stat-label"><?php echo t('students'); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="dashboard-card">
                    <div class="stat-card">
                        <div class="stat-icon stat-icon-teachers">
                            <i class="fas fa-chalkboard-teacher"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-value"><?php echo number_format($stats['teachers_count']); ?></div>
                            <div class="stat-label"><?php echo t('teachers'); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="dashboard-card">
                    <div class="stat-card">
                        <div class="stat-icon stat-icon-courses">
                            <i class="fas fa-book"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-value"><?php echo number_format($stats['courses_count']); ?></div>
                            <div class="stat-label"><?php echo t('courses'); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="dashboard-card">
                    <div class="stat-card">
                        <div class="stat-icon stat-icon-departments">
                            <i class="fas fa-building"></i>
                        </div>
                        <div class="stat-info">
                            <div class="stat-value"><?php echo number_format($stats['departments_count']); ?></div>
                            <div class="stat-label"><?php echo t('departments'); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- الرسوم البيانية والإحصائيات -->
        <div class="row g-4 mb-4">
            <div class="col-md-8">
                <div class="dashboard-card">
                    <div class="section-header">
                        <h3 class="section-title"><?php echo t('students_distribution'); ?></h3>
                        <a href="college_reports_academic.php" class="section-action"><?php echo t('view_details'); ?></a>
                    </div>
                    <div class="chart-container">
                        <canvas id="studentsChart"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="dashboard-card">
                    <div class="section-header">
                        <h3 class="section-title"><?php echo t('recent_activities'); ?></h3>
                        <a href="college_activities.php" class="section-action"><?php echo t('view_all'); ?></a>
                    </div>
                    <ul class="activity-list">
                        <?php foreach ($recent_activities as $activity): ?>
                            <li class="activity-item">
                                <div class="activity-icon activity-icon-<?php echo $activity['type']; ?>">
                                    <i class="fas fa-<?php echo get_activity_icon($activity['type']); ?>"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-title"><?php echo $activity['title']; ?></div>
                                    <div class="activity-time"><?php echo format_time_ago($activity['timestamp']); ?></div>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- الأقسام والبرامج -->
        <div class="row g-4 mb-4">
            <div class="col-md-6">
                <div class="dashboard-card">
                    <div class="section-header">
                        <h3 class="section-title"><?php echo t('departments'); ?></h3>
                        <a href="college_departments.php" class="section-action"><?php echo t('view_all'); ?></a>
                    </div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th><?php echo t('department_name'); ?></th>
                                    <th><?php echo t('head'); ?></th>
                                    <th><?php echo t('students'); ?></th>
                                    <th><?php echo t('programs'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($departments as $department): ?>
                                    <tr>
                                        <td>
                                            <span class="badge-department"><?php echo $department['name']; ?></span>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?php echo $department['head_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $department['head_name']; ?>" class="table-avatar">
                                                <span><?php echo $department['head_name']; ?></span>
                                            </div>
                                        </td>
                                        <td><?php echo number_format($department['students_count']); ?></td>
                                        <td><?php echo number_format($department['programs_count']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="dashboard-card">
                    <div class="section-header">
                        <h3 class="section-title"><?php echo t('academic_programs'); ?></h3>
                        <a href="college_programs.php" class="section-action"><?php echo t('view_all'); ?></a>
                    </div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th><?php echo t('program_name'); ?></th>
                                    <th><?php echo t('department'); ?></th>
                                    <th><?php echo t('students'); ?></th>
                                    <th><?php echo t('courses'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($programs as $program): ?>
                                    <tr>
                                        <td>
                                            <span class="badge-program"><?php echo $program['name']; ?></span>
                                        </td>
                                        <td><?php echo $program['department_name']; ?></td>
                                        <td><?php echo number_format($program['students_count']); ?></td>
                                        <td><?php echo number_format($program['courses_count']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- المعلمين والطلاب والمقررات -->
        <div class="row g-4">
            <div class="col-md-4">
                <div class="dashboard-card">
                    <div class="section-header">
                        <h3 class="section-title"><?php echo t('teachers'); ?></h3>
                        <a href="college_teachers.php" class="section-action"><?php echo t('view_all'); ?></a>
                    </div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th><?php echo t('name'); ?></th>
                                    <th><?php echo t('department'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($teachers as $teacher): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?php echo $teacher['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $teacher['name']; ?>" class="table-avatar">
                                                <span><?php echo $teacher['name']; ?></span>
                                            </div>
                                        </td>
                                        <td><?php echo $teacher['department_name']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="dashboard-card">
                    <div class="section-header">
                        <h3 class="section-title"><?php echo t('students'); ?></h3>
                        <a href="college_students.php" class="section-action"><?php echo t('view_all'); ?></a>
                    </div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th><?php echo t('name'); ?></th>
                                    <th><?php echo t('program'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($students as $student): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="<?php echo $student['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $student['name']; ?>" class="table-avatar">
                                                <span><?php echo $student['name']; ?></span>
                                            </div>
                                        </td>
                                        <td><?php echo $student['program_name']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="dashboard-card">
                    <div class="section-header">
                        <h3 class="section-title"><?php echo t('courses'); ?></h3>
                        <a href="college_courses.php" class="section-action"><?php echo t('view_all'); ?></a>
                    </div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th><?php echo t('course_name'); ?></th>
                                    <th><?php echo t('code'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($courses as $course): ?>
                                    <tr>
                                        <td><?php echo $course['name']; ?></td>
                                        <td><?php echo $course['code']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // زر تبديل المظهر
            document.getElementById('themeToggle').addEventListener('click', function() {
                const currentTheme = document.body.className.includes('theme-dark') ? 'dark' : 'light';
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.cookie = `theme=${newTheme}; path=/; max-age=31536000`;
                document.body.className = `theme-${newTheme}`;
                
                this.innerHTML = `<i class="fas fa-${newTheme === 'dark' ? 'sun' : 'moon'}"></i>`;
                
                // تحديث الرسوم البيانية
                updateChartsTheme(newTheme);
            });
            
            // إنشاء الرسوم البيانية
            const studentsChartCtx = document.getElementById('studentsChart').getContext('2d');
            
            // تحديد ألوان الرسوم البيانية بناءً على المظهر
            const currentTheme = document.body.className.includes('theme-dark') ? 'dark' : 'light';
            const chartColors = getChartColors(currentTheme);
            
            // بيانات توزيع الطلاب حسب الأقسام
            const studentsChart = new Chart(studentsChartCtx, {
                type: 'bar',
                data: {
                    labels: [
                        'علوم الحاسب',
                        'هندسة البرمجيات',
                        'نظم المعلومات',
                        'تقنية المعلومات',
                        'الذكاء الاصطناعي'
                    ],
                    datasets: [{
                        label: '<?php echo t("students_count"); ?>',
                        data: [320, 280, 210, 190, 150],
                        backgroundColor: chartColors.backgroundColors,
                        borderColor: chartColors.borderColors,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: chartColors.gridColor
                            },
                            ticks: {
                                color: chartColors.textColor
                            }
                        },
                        x: {
                            grid: {
                                color: chartColors.gridColor
                            },
                            ticks: {
                                color: chartColors.textColor
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            labels: {
                                color: chartColors.textColor
                            }
                        }
                    }
                }
            });
            
            // دالة لتحديث ألوان الرسوم البيانية عند تغيير المظهر
            function updateChartsTheme(theme) {
                const colors = getChartColors(theme);
                
                studentsChart.options.scales.y.grid.color = colors.gridColor;
                studentsChart.options.scales.x.grid.color = colors.gridColor;
                studentsChart.options.scales.y.ticks.color = colors.textColor;
                studentsChart.options.scales.x.ticks.color = colors.textColor;
                studentsChart.options.plugins.legend.labels.color = colors.textColor;
                
                studentsChart.data.datasets[0].backgroundColor = colors.backgroundColors;
                studentsChart.data.datasets[0].borderColor = colors.borderColors;
                
                studentsChart.update();
            }
            
            // دالة للحصول على ألوان الرسوم البيانية بناءً على المظهر
            function getChartColors(theme) {
                if (theme === 'dark') {
                    return {
                        backgroundColors: [
                            'rgba(78, 115, 223, 0.5)',
                            'rgba(28, 200, 138, 0.5)',
                            'rgba(246, 194, 62, 0.5)',
                            'rgba(231, 74, 59, 0.5)',
                            'rgba(54, 185, 204, 0.5)'
                        ],
                        borderColors: [
                            'rgba(78, 115, 223, 1)',
                            'rgba(28, 200, 138, 1)',
                            'rgba(246, 194, 62, 1)',
                            'rgba(231, 74, 59, 1)',
                            'rgba(54, 185, 204, 1)'
                        ],
                        gridColor: 'rgba(255, 255, 255, 0.1)',
                        textColor: 'rgba(255, 255, 255, 0.7)'
                    };
                } else {
                    return {
                        backgroundColors: [
                            'rgba(78, 115, 223, 0.5)',
                            'rgba(28, 200, 138, 0.5)',
                            'rgba(246, 194, 62, 0.5)',
                            'rgba(231, 74, 59, 0.5)',
                            'rgba(54, 185, 204, 0.5)'
                        ],
                        borderColors: [
                            'rgba(78, 115, 223, 1)',
                            'rgba(28, 200, 138, 1)',
                            'rgba(246, 194, 62, 1)',
                            'rgba(231, 74, 59, 1)',
                            'rgba(54, 185, 204, 1)'
                        ],
                        gridColor: 'rgba(0, 0, 0, 0.1)',
                        textColor: 'rgba(0, 0, 0, 0.7)'
                    };
                }
            }
        });
    </script>
</body>
</html>
