<?php
/**
 * صفحة إدارة الجدول الدراسي في نظام UniverBoard
 * تتيح لمسؤول الكلية إدارة الجداول الدراسية وجداول الامتحانات
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول مسؤول الكلية
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'college_admin') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات مسؤول الكلية
$admin_id = $_SESSION['user_id'];
$db = get_db_connection();
$admin = get_college_admin_info($db, $admin_id);
$college_id = $admin['college_id'];
$college = get_college_info($db, $college_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// تحديد نوع الجدول (دراسي أو امتحانات)
$schedule_type = isset($_GET['type']) && $_GET['type'] === 'exams' ? 'exams' : 'classes';

// تحديد الفلاتر (القسم، البرنامج، المستوى، المعلم)
$selected_department_id = isset($_GET['department_id']) ? filter_input(INPUT_GET, 'department_id', FILTER_SANITIZE_NUMBER_INT) : null;
$selected_program_id = isset($_GET['program_id']) ? filter_input(INPUT_GET, 'program_id', FILTER_SANITIZE_NUMBER_INT) : null;
$selected_level = isset($_GET['level']) ? filter_input(INPUT_GET, 'level', FILTER_SANITIZE_NUMBER_INT) : null;
$selected_teacher_id = isset($_GET['teacher_id']) ? filter_input(INPUT_GET, 'teacher_id', FILTER_SANITIZE_NUMBER_INT) : null;

// معالجة إضافة حدث جديد في الجدول
if (isset($_POST['add_schedule_event'])) {
    $event_type = filter_input(INPUT_POST, 'event_type', FILTER_SANITIZE_STRING); // 'class' or 'exam'
    $course_id = filter_input(INPUT_POST, 'course_id', FILTER_SANITIZE_NUMBER_INT);
    $teacher_id = filter_input(INPUT_POST, 'teacher_id', FILTER_SANITIZE_NUMBER_INT);
    $day_of_week = filter_input(INPUT_POST, 'day_of_week', FILTER_SANITIZE_STRING);
    $start_time = filter_input(INPUT_POST, 'start_time', FILTER_SANITIZE_STRING);
    $end_time = filter_input(INPUT_POST, 'end_time', FILTER_SANITIZE_STRING);
    $location = filter_input(INPUT_POST, 'location', FILTER_SANITIZE_STRING);
    $exam_date = filter_input(INPUT_POST, 'exam_date', FILTER_SANITIZE_STRING);
    $exam_duration = filter_input(INPUT_POST, 'exam_duration', FILTER_SANITIZE_NUMBER_INT);

    if ($event_type === 'class') {
        $result = add_class_schedule($db, $college_id, $course_id, $teacher_id, $day_of_week, $start_time, $end_time, $location);
    } elseif ($event_type === 'exam') {
        $result = add_exam_schedule($db, $college_id, $course_id, $teacher_id, $exam_date, $start_time, $end_time, $location, $exam_duration);
    }

    if (isset($result) && $result) {
        $success_message = t('schedule_event_added_successfully');
    } else {
        $error_message = t('failed_to_add_schedule_event');
    }
}

// معالجة تحديث حدث في الجدول
if (isset($_POST['update_schedule_event'])) {
    $event_id = filter_input(INPUT_POST, 'event_id', FILTER_SANITIZE_NUMBER_INT);
    $event_type = filter_input(INPUT_POST, 'event_type', FILTER_SANITIZE_STRING);
    $course_id = filter_input(INPUT_POST, 'course_id', FILTER_SANITIZE_NUMBER_INT);
    $teacher_id = filter_input(INPUT_POST, 'teacher_id', FILTER_SANITIZE_NUMBER_INT);
    $day_of_week = filter_input(INPUT_POST, 'day_of_week', FILTER_SANITIZE_STRING);
    $start_time = filter_input(INPUT_POST, 'start_time', FILTER_SANITIZE_STRING);
    $end_time = filter_input(INPUT_POST, 'end_time', FILTER_SANITIZE_STRING);
    $location = filter_input(INPUT_POST, 'location', FILTER_SANITIZE_STRING);
    $exam_date = filter_input(INPUT_POST, 'exam_date', FILTER_SANITIZE_STRING);
    $exam_duration = filter_input(INPUT_POST, 'exam_duration', FILTER_SANITIZE_NUMBER_INT);

    if ($event_type === 'class') {
        $result = update_class_schedule($db, $event_id, $course_id, $teacher_id, $day_of_week, $start_time, $end_time, $location);
    } elseif ($event_type === 'exam') {
        $result = update_exam_schedule($db, $event_id, $course_id, $teacher_id, $exam_date, $start_time, $end_time, $location, $exam_duration);
    }

    if (isset($result) && $result) {
        $success_message = t('schedule_event_updated_successfully');
    } else {
        $error_message = t('failed_to_update_schedule_event');
    }
}

// معالجة حذف حدث من الجدول
if (isset($_POST['delete_schedule_event'])) {
    $event_id = filter_input(INPUT_POST, 'event_id', FILTER_SANITIZE_NUMBER_INT);
    $event_type = filter_input(INPUT_POST, 'event_type', FILTER_SANITIZE_STRING);

    if ($event_type === 'class') {
        $result = delete_class_schedule($db, $event_id);
    } elseif ($event_type === 'exam') {
        $result = delete_exam_schedule($db, $event_id);
    }

    if (isset($result) && $result) {
        $success_message = t('schedule_event_deleted_successfully');
    } else {
        $error_message = t('failed_to_delete_schedule_event');
    }
}

// الحصول على قائمة الأقسام في الكلية
$departments = get_college_departments($db, $college_id);

// الحصول على قائمة البرامج في الكلية (بناءً على القسم المحدد إن وجد)
if ($selected_department_id) {
    $programs = get_department_programs($db, $selected_department_id);
} else {
    $programs = get_college_programs($db, $college_id);
}

// الحصول على قائمة المعلمين في الكلية (بناءً على القسم المحدد إن وجد)
if ($selected_department_id) {
    $teachers = get_department_teachers($db, $selected_department_id);
} else {
    $teachers = get_college_teachers($db, $college_id);
}

// الحصول على قائمة المقررات في الكلية (بناءً على القسم والبرنامج والمستوى إن وجد)
$course_filters = [
    'college_id' => $college_id,
    'department_id' => $selected_department_id,
    'program_id' => $selected_program_id,
    'level' => $selected_level
];
$courses = get_college_courses($db, $course_filters);

// الحصول على بيانات الجدول بناءً على الفلاتر ونوع الجدول
$schedule_filters = [
    'college_id' => $college_id,
    'department_id' => $selected_department_id,
    'program_id' => $selected_program_id,
    'level' => $selected_level,
    'teacher_id' => $selected_teacher_id
];

if ($schedule_type === 'classes') {
    $schedule_data = get_class_schedule($db, $schedule_filters);
} else {
    $schedule_data = get_exam_schedule($db, $schedule_filters);
}

// إغلاق اتصال قاعدة البيانات
$db->close();

// أيام الأسبوع للجدول الدراسي
$days_of_week = [
    'الأحد' => t('sunday'),
    'الاثنين' => t('monday'),
    'الثلاثاء' => t('tuesday'),
    'الأربعاء' => t('wednesday'),
    'الخميس' => t('thursday')
];

// فترات زمنية للجدول الدراسي
$time_slots = [
    '08:00 - 09:00',
    '09:00 - 10:00',
    '10:00 - 11:00',
    '11:00 - 12:00',
    '12:00 - 13:00',
    '13:00 - 14:00',
    '14:00 - 15:00',
    '15:00 - 16:00'
];

// تنظيم بيانات الجدول الدراسي للعرض
$formatted_class_schedule = [];
foreach ($time_slots as $slot) {
    foreach ($days_of_week as $day_key => $day_name) {
        $formatted_class_schedule[$slot][$day_key] = [];
    }
}

if ($schedule_type === 'classes') {
    foreach ($schedule_data as $event) {
        $slot_key = date('H:i', strtotime($event['start_time'])) . ' - ' . date('H:i', strtotime($event['end_time']));
        if (isset($formatted_class_schedule[$slot_key][$event['day_of_week']])) {
            $formatted_class_schedule[$slot_key][$event['day_of_week']][] = $event;
        }
    }
}

?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('schedule'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- FullCalendar -->
    <link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css' rel='stylesheet' />
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        /* نفس تنسيقات القائمة الجانبية وشريط التنقل العلوي من الصفحات السابقة */
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
            width: 250px;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .page-header {
            margin-bottom: 2rem;
        }
        
        .page-title {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .page-subtitle {
            color: var(--gray-color);
        }
        
        .card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
            border: none;
        }
        
        .theme-dark .card {
            background-color: var(--dark-bg);
        }
        
        .card-header {
            background-color: transparent;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1.25rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .theme-dark .card-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .card-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin: 0;
        }
        
        .card-body {
            padding: 1.5rem;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #002135;
            border-color: #002135;
        }
        
        .btn-secondary {
            background-color: #669bbc;
            border-color: #669bbc;
        }
        
        .btn-secondary:hover {
            background-color: #5589a7;
            border-color: #5589a7;
        }
        
        .filter-container {
            margin-bottom: 1.5rem;
        }
        
        .schedule-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }
        
        .schedule-table th, .schedule-table td {
            border: 1px solid rgba(0, 0, 0, 0.1);
            padding: 0.75rem;
            text-align: center;
            vertical-align: top;
            height: 100px;
        }
        
        .theme-dark .schedule-table th, .theme-dark .schedule-table td {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .schedule-table th {
            background-color: rgba(0, 0, 0, 0.03);
            font-weight: 600;
        }
        
        .theme-dark .schedule-table th {
            background-color: rgba(255, 255, 255, 0.03);
        }
        
        .schedule-table .time-slot {
            font-weight: 500;
            font-size: 0.9rem;
            white-space: nowrap;
        }
        
        .schedule-event {
            background-color: rgba(0, 48, 73, 0.1);
            border-radius: 0.25rem;
            padding: 0.5rem;
            margin-bottom: 0.5rem;
            font-size: 0.85rem;
            cursor: pointer;
            transition: background-color 0.2s ease;
            position: relative;
        }
        
        .theme-dark .schedule-event {
            background-color: rgba(0, 48, 73, 0.3);
        }
        
        .schedule-event:hover {
            background-color: rgba(0, 48, 73, 0.2);
        }
        
        .theme-dark .schedule-event:hover {
            background-color: rgba(0, 48, 73, 0.5);
        }
        
        .schedule-event-course {
            font-weight: 600;
            display: block;
            margin-bottom: 0.25rem;
        }
        
        .schedule-event-teacher, .schedule-event-location {
            display: block;
            font-size: 0.8rem;
            color: var(--gray-color);
        }
        
        .schedule-event-actions {
            position: absolute;
            top: 5px;
            right: 5px;
            display: none;
            gap: 3px;
        }
        
        [dir="rtl"] .schedule-event-actions {
            right: auto;
            left: 5px;
        }
        
        .schedule-event:hover .schedule-event-actions {
            display: flex;
        }
        
        .schedule-event-action {
            background-color: rgba(255, 255, 255, 0.7);
            border: none;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 0.7rem;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-color);
            padding: 0;
        }
        
        .theme-dark .schedule-event-action {
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
        }
        
        .schedule-event-action.edit {
            color: #ffc107;
        }
        
        .schedule-event-action.delete {
            color: #dc3545;
        }
        
        #examCalendar {
            max-width: 1100px;
            margin: 0 auto;
        }
        
        .fc-event {
            cursor: pointer;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            font-weight: 500;
            margin-bottom: 0.5rem;
        }
        
        .form-control {
            padding: 0.75rem;
            border-radius: 0.5rem;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .form-control {
            background-color: var(--dark-bg);
            border-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .form-control:focus {
            box-shadow: 0 0 0 0.25rem rgba(0, 48, 73, 0.25);
            border-color: var(--primary-color);
        }
        
        .modal-content {
            border-radius: 0.5rem;
            border: none;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .modal-content {
            background-color: var(--dark-bg);
        }
        
        .modal-header {
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1.25rem 1.5rem;
        }
        
        .theme-dark .modal-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .modal-title {
            font-weight: 600;
        }
        
        .modal-body {
            padding: 1.5rem;
        }
        
        .modal-footer {
            border-top: 1px solid rgba(0, 0, 0, 0.1);
            padding: 1.25rem 1.5rem;
        }
        
        .theme-dark .modal-footer {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .nav-tabs .nav-link {
            color: var(--gray-color);
            border: none;
            border-bottom: 2px solid transparent;
            padding: 0.75rem 1.25rem;
        }
        
        .nav-tabs .nav-link.active {
            color: var(--primary-color);
            border-bottom-color: var(--primary-color);
            background-color: transparent;
        }
        
        .tab-content {
            padding-top: 1.5rem;
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo<?php echo $theme === 'dark' ? '-white' : ''; ?>.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="college_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_departments.php">
                        <i class="fas fa-building"></i> <?php echo t('departments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_programs.php">
                        <i class="fas fa-graduation-cap"></i> <?php echo t('academic_programs'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_teachers.php">
                        <i class="fas fa-chalkboard-teacher"></i> <?php echo t('teachers'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_students.php">
                        <i class="fas fa-user-graduate"></i> <?php echo t('students'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="college_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('reports'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="college_reports_academic.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('academic_reports'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_reports_attendance.php">
                        <i class="fas fa-clipboard-check"></i> <?php echo t('attendance_reports'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_reports_performance.php">
                        <i class="fas fa-chart-bar"></i> <?php echo t('performance_reports'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="college_announcements.php">
                        <i class="fas fa-bullhorn"></i> <?php echo t('announcements'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('settings'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="college_profile.php">
                        <i class="fas fa-university"></i> <?php echo t('college_profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="college_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <!-- نفس عناصر شريط التنقل العلوي من الصفحات السابقة -->
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">5</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-user-graduate"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تسجيل 15 طالب جديد في قسم علوم الحاسب</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-calendar-alt"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تحديث جدول الامتحانات النهائية</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-info text-white rounded-circle">
                                        <i class="fas fa-chalkboard-teacher"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تعيين د. محمد أحمد كرئيس لقسم الهندسة المدنية</p>
                                    <small class="text-muted">منذ 3 ساعات</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="college_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/dean.jpg" alt="Dean" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. عبدالله العمري</p>
                                    <small class="text-muted">نرجو مراجعة الميزانية المقترحة للعام القادم</small>
                                    <small class="text-muted d-block">منذ 20 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/department_head.jpg" alt="Department Head" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. سارة الأحمد</p>
                                    <small class="text-muted">هل يمكننا مناقشة توزيع المقررات للفصل القادم؟</small>
                                    <small class="text-muted d-block">منذ ساعتين</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="college_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $admin['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $admin['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $admin['name']; ?></h6>
                            <small><?php echo t('college_admin'); ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="college_profile.php">
                            <i class="fas fa-university"></i> <?php echo t('college_profile'); ?>
                        </a>
                        <a class="dropdown-item" href="college_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar&type=<?php echo $schedule_type; ?>">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en&type=<?php echo $schedule_type; ?>">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="page-header mt-4">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="page-title"><?php echo t('schedule'); ?></h1>
                    <p class="page-subtitle"><?php echo t('manage_college_schedule'); ?></p>
                </div>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addScheduleEventModal">
                    <i class="fas fa-plus me-1"></i> <?php echo t('add_schedule_event'); ?>
                </button>
            </div>
        </div>
        
        <!-- رسائل النجاح والخطأ -->
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $success_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $error_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <!-- فلتر الجدول -->
        <div class="filter-container">
            <div class="card">
                <div class="card-body">
                    <form action="" method="get" class="row g-3">
                        <input type="hidden" name="type" value="<?php echo $schedule_type; ?>">
                        <div class="col-md-3">
                            <label for="department_filter" class="form-label"><?php echo t('filter_by_department'); ?></label>
                            <select class="form-select" id="department_filter" name="department_id" onchange="updateProgramsAndTeachersFilter()">
                                <option value=""><?php echo t('all_departments'); ?></option>
                                <?php foreach ($departments as $department): ?>
                                    <option value="<?php echo $department['id']; ?>" <?php echo $selected_department_id == $department['id'] ? 'selected' : ''; ?>>
                                        <?php echo $department['name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="program_filter" class="form-label"><?php echo t('filter_by_program'); ?></label>
                            <select class="form-select" id="program_filter" name="program_id">
                                <option value=""><?php echo t('all_programs'); ?></option>
                                <?php foreach ($programs as $program): ?>
                                    <option value="<?php echo $program['id']; ?>" <?php echo $selected_program_id == $program['id'] ? 'selected' : ''; ?>>
                                        <?php echo $program['name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label for="level_filter" class="form-label"><?php echo t('filter_by_level'); ?></label>
                            <select class="form-select" id="level_filter" name="level">
                                <option value=""><?php echo t('all_levels'); ?></option>
                                <?php for ($i = 1; $i <= 8; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo $selected_level == $i ? 'selected' : ''; ?>><?php echo t('level') . ' ' . $i; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label for="teacher_filter" class="form-label"><?php echo t('filter_by_teacher'); ?></label>
                            <select class="form-select" id="teacher_filter" name="teacher_id">
                                <option value=""><?php echo t('all_teachers'); ?></option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?php echo $teacher['id']; ?>" <?php echo $selected_teacher_id == $teacher['id'] ? 'selected' : ''; ?>>
                                        <?php echo $teacher['name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-filter me-1"></i> <?php echo t('filter'); ?>
                            </button>
                            <a href="college_schedule.php?type=<?php echo $schedule_type; ?>" class="btn btn-secondary">
                                <i class="fas fa-sync-alt me-1"></i> <?php echo t('reset'); ?>
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- عرض الجدول -->
        <div class="card">
            <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $schedule_type === 'classes' ? 'active' : ''; ?>" href="?type=classes<?php echo build_query_string(['type']); ?>">
                            <?php echo t('class_schedule'); ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $schedule_type === 'exams' ? 'active' : ''; ?>" href="?type=exams<?php echo build_query_string(['type']); ?>">
                            <?php echo t('exam_schedule'); ?>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content">
                    <div class="tab-pane fade <?php echo $schedule_type === 'classes' ? 'show active' : ''; ?>" id="classScheduleTab">
                        <div class="table-responsive">
                            <table class="schedule-table">
                                <thead>
                                    <tr>
                                        <th><?php echo t('time'); ?></th>
                                        <?php foreach ($days_of_week as $day_key => $day_name): ?>
                                            <th><?php echo $day_name; ?></th>
                                        <?php endforeach; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($time_slots as $slot): ?>
                                        <tr>
                                            <td class="time-slot"><?php echo $slot; ?></td>
                                            <?php foreach ($days_of_week as $day_key => $day_name): ?>
                                                <td>
                                                    <?php if (!empty($formatted_class_schedule[$slot][$day_key])): ?>
                                                        <?php foreach ($formatted_class_schedule[$slot][$day_key] as $event): ?>
                                                            <div class="schedule-event" 
                                                                 data-bs-toggle="modal" 
                                                                 data-bs-target="#editScheduleEventModal" 
                                                                 data-event-id="<?php echo $event['id']; ?>" 
                                                                 data-event-type="class">
                                                                <span class="schedule-event-course"><?php echo $event['course_name']; ?> (<?php echo $event['course_code']; ?>)</span>
                                                                <span class="schedule-event-teacher"><i class="fas fa-chalkboard-teacher me-1"></i><?php echo $event['teacher_name']; ?></span>
                                                                <span class="schedule-event-location"><i class="fas fa-map-marker-alt me-1"></i><?php echo $event['location']; ?></span>
                                                                <div class="schedule-event-actions">
                                                                    <button class="schedule-event-action edit" 
                                                                            data-bs-toggle="modal" 
                                                                            data-bs-target="#editScheduleEventModal" 
                                                                            data-event-id="<?php echo $event['id']; ?>" 
                                                                            data-event-type="class">
                                                                        <i class="fas fa-edit"></i>
                                                                    </button>
                                                                    <button class="schedule-event-action delete" 
                                                                            data-bs-toggle="modal" 
                                                                            data-bs-target="#deleteScheduleEventModal" 
                                                                            data-event-id="<?php echo $event['id']; ?>" 
                                                                            data-event-type="class" 
                                                                            data-event-name="<?php echo $event['course_name']; ?>">
                                                                        <i class="fas fa-trash"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; ?>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade <?php echo $schedule_type === 'exams' ? 'show active' : ''; ?>" id="examScheduleTab">
                        <div id='examCalendar'></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال إضافة حدث جديد في الجدول -->
    <div class="modal fade" id="addScheduleEventModal" tabindex="-1" aria-labelledby="addScheduleEventModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addScheduleEventModalLabel"><?php echo t('add_new_schedule_event'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="post">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="addEventType" class="form-label"><?php echo t('event_type'); ?> <span class="text-danger">*</span></label>
                            <select class="form-select" id="addEventType" name="event_type" required onchange="toggleAddEventFields()">
                                <option value="class" <?php echo $schedule_type === 'classes' ? 'selected' : ''; ?>><?php echo t('class'); ?></option>
                                <option value="exam" <?php echo $schedule_type === 'exams' ? 'selected' : ''; ?>><?php echo t('exam'); ?></option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="addCourseId" class="form-label"><?php echo t('course'); ?> <span class="text-danger">*</span></label>
                            <select class="form-select" id="addCourseId" name="course_id" required>
                                <option value=""><?php echo t('select_course'); ?></option>
                                <?php foreach ($courses as $course): ?>
                                    <option value="<?php echo $course['id']; ?>"><?php echo $course['name']; ?> (<?php echo $course['code']; ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="addTeacherId" class="form-label"><?php echo t('teacher'); ?> <span class="text-danger">*</span></label>
                            <select class="form-select" id="addTeacherId" name="teacher_id" required>
                                <option value=""><?php echo t('select_teacher'); ?></option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?php echo $teacher['id']; ?>"><?php echo $teacher['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div id="addClassFields">
                            <div class="form-group">
                                <label for="addDayOfWeek" class="form-label"><?php echo t('day_of_week'); ?> <span class="text-danger">*</span></label>
                                <select class="form-select" id="addDayOfWeek" name="day_of_week">
                                    <?php foreach ($days_of_week as $day_key => $day_name): ?>
                                        <option value="<?php echo $day_key; ?>"><?php echo $day_name; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div id="addExamFields" style="display: none;">
                            <div class="form-group">
                                <label for="addExamDate" class="form-label"><?php echo t('exam_date'); ?> <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="addExamDate" name="exam_date">
                            </div>
                            <div class="form-group">
                                <label for="addExamDuration" class="form-label"><?php echo t('exam_duration_minutes'); ?></label>
                                <input type="number" class="form-control" id="addExamDuration" name="exam_duration" min="30" step="15">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="addStartTime" class="form-label"><?php echo t('start_time'); ?> <span class="text-danger">*</span></label>
                                    <input type="time" class="form-control" id="addStartTime" name="start_time" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="addEndTime" class="form-label"><?php echo t('end_time'); ?> <span class="text-danger">*</span></label>
                                    <input type="time" class="form-control" id="addEndTime" name="end_time" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="addLocation" class="form-label"><?php echo t('location'); ?> <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="addLocation" name="location" required placeholder="<?php echo t('e.g., Hall A1, Lab B2'); ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                        <button type="submit" name="add_schedule_event" class="btn btn-primary"><?php echo t('add_event'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- مودال تعديل حدث في الجدول -->
    <div class="modal fade" id="editScheduleEventModal" tabindex="-1" aria-labelledby="editScheduleEventModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editScheduleEventModalLabel"><?php echo t('edit_schedule_event'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="post">
                    <div class="modal-body">
                        <input type="hidden" id="editEventId" name="event_id">
                        <input type="hidden" id="editEventType" name="event_type">
                        
                        <div class="form-group">
                            <label for="editCourseId" class="form-label"><?php echo t('course'); ?> <span class="text-danger">*</span></label>
                            <select class="form-select" id="editCourseId" name="course_id" required>
                                <option value=""><?php echo t('select_course'); ?></option>
                                <?php foreach ($courses as $course): ?>
                                    <option value="<?php echo $course['id']; ?>"><?php echo $course['name']; ?> (<?php echo $course['code']; ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="editTeacherId" class="form-label"><?php echo t('teacher'); ?> <span class="text-danger">*</span></label>
                            <select class="form-select" id="editTeacherId" name="teacher_id" required>
                                <option value=""><?php echo t('select_teacher'); ?></option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?php echo $teacher['id']; ?>"><?php echo $teacher['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div id="editClassFields">
                            <div class="form-group">
                                <label for="editDayOfWeek" class="form-label"><?php echo t('day_of_week'); ?> <span class="text-danger">*</span></label>
                                <select class="form-select" id="editDayOfWeek" name="day_of_week">
                                    <?php foreach ($days_of_week as $day_key => $day_name): ?>
                                        <option value="<?php echo $day_key; ?>"><?php echo $day_name; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div id="editExamFields" style="display: none;">
                            <div class="form-group">
                                <label for="editExamDate" class="form-label"><?php echo t('exam_date'); ?> <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="editExamDate" name="exam_date">
                            </div>
                            <div class="form-group">
                                <label for="editExamDuration" class="form-label"><?php echo t('exam_duration_minutes'); ?></label>
                                <input type="number" class="form-control" id="editExamDuration" name="exam_duration" min="30" step="15">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="editStartTime" class="form-label"><?php echo t('start_time'); ?> <span class="text-danger">*</span></label>
                                    <input type="time" class="form-control" id="editStartTime" name="start_time" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="editEndTime" class="form-label"><?php echo t('end_time'); ?> <span class="text-danger">*</span></label>
                                    <input type="time" class="form-control" id="editEndTime" name="end_time" required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="editLocation" class="form-label"><?php echo t('location'); ?> <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="editLocation" name="location" required placeholder="<?php echo t('e.g., Hall A1, Lab B2'); ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                        <button type="submit" name="update_schedule_event" class="btn btn-primary"><?php echo t('save_changes'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- مودال حذف حدث من الجدول -->
    <div class="modal fade" id="deleteScheduleEventModal" tabindex="-1" aria-labelledby="deleteScheduleEventModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteScheduleEventModalLabel"><?php echo t('delete_schedule_event'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p><?php echo t('delete_schedule_event_confirmation'); ?> <strong id="deleteEventName"></strong>؟</p>
                </div>
                <form action="" method="post">
                    <input type="hidden" id="deleteEventId" name="event_id">
                    <input type="hidden" id="deleteEventType" name="event_type">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                        <button type="submit" name="delete_schedule_event" class="btn btn-danger"><?php echo t('delete'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- FullCalendar -->
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/locales-all.min.js'></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // زر تبديل المظهر
            document.getElementById('themeToggle').addEventListener('click', function() {
                const currentTheme = document.body.className.includes('theme-dark') ? 'dark' : 'light';
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.cookie = `theme=${newTheme}; path=/; max-age=31536000`;
                document.body.className = `theme-${newTheme}`;
                
                this.innerHTML = `<i class="fas fa-${newTheme === 'dark' ? 'sun' : 'moon'}"></i>`;
                
                // إعادة تهيئة التقويم إذا كان معروضًا
                if (calendar && document.getElementById('examCalendar').offsetParent !== null) {
                    calendar.destroy();
                    initializeCalendar();
                }
            });
            
            // تبديل الحقول بناءً على نوع الحدث (إضافة)
            toggleAddEventFields();
            
            // تهيئة تقويم الامتحانات إذا كان التبويب نشطًا
            let calendar = null;
            const examTab = document.getElementById('examScheduleTab');
            if (examTab.classList.contains('active')) {
                initializeCalendar();
            }
            
            // إعادة تهيئة التقويم عند التبديل إلى تبويب الامتحانات
            const examTabLink = document.querySelector('a[href*="type=exams"]');
            if (examTabLink) {
                examTabLink.addEventListener('shown.bs.tab', function (event) {
                    if (!calendar) {
                        initializeCalendar();
                    } else {
                        calendar.render(); // إعادة رسم التقويم لضمان العرض الصحيح
                    }
                });
            }
            
            // مودال تعديل الحدث
            $('#editScheduleEventModal').on('show.bs.modal', function(event) {
                const button = $(event.relatedTarget);
                const eventId = button.data('event-id');
                const eventType = button.data('event-type');
                
                $('#editEventId').val(eventId);
                $('#editEventType').val(eventType);
                
                // هنا يجب إضافة طلب AJAX للحصول على تفاصيل الحدث بناءً على eventId و eventType
                // لأغراض العرض، سنستخدم بيانات وهمية
                
                // مثال لبيانات وهمية لحدث محاضرة
                const classEventData = {
                    id: 101,
                    type: 'class',
                    course_id: 5,
                    teacher_id: 12,
                    day_of_week: 'الاثنين',
                    start_time: '10:00:00',
                    end_time: '12:00:00',
                    location: 'قاعة المحاضرات 3'
                };
                
                // مثال لبيانات وهمية لحدث امتحان
                const examEventData = {
                    id: 205,
                    type: 'exam',
                    course_id: 8,
                    teacher_id: 15,
                    exam_date: '2025-06-15',
                    start_time: '09:00:00',
                    end_time: '11:00:00',
                    location: 'مختبر الحاسب 1',
                    exam_duration: 120
                };
                
                const eventData = eventType === 'class' ? classEventData : examEventData;
                
                if (eventData) {
                    $('#editCourseId').val(eventData.course_id);
                    $('#editTeacherId').val(eventData.teacher_id);
                    $('#editStartTime').val(eventData.start_time.substring(0, 5));
                    $('#editEndTime').val(eventData.end_time.substring(0, 5));
                    $('#editLocation').val(eventData.location);
                    
                    if (eventType === 'class') {
                        $('#editDayOfWeek').val(eventData.day_of_week);
                        $('#editClassFields').show();
                        $('#editExamFields').hide();
                        $('#editExamDate').val('');
                        $('#editExamDuration').val('');
                    } else {
                        $('#editExamDate').val(eventData.exam_date);
                        $('#editExamDuration').val(eventData.exam_duration);
                        $('#editClassFields').hide();
                        $('#editExamFields').show();
                        $('#editDayOfWeek').val('');
                    }
                }
            });
            
            // مودال حذف الحدث
            $('#deleteScheduleEventModal').on('show.bs.modal', function(event) {
                const button = $(event.relatedTarget);
                const eventId = button.data('event-id');
                const eventType = button.data('event-type');
                const eventName = button.data('event-name');
                
                $('#deleteEventId').val(eventId);
                $('#deleteEventType').val(eventType);
                $('#deleteEventName').text(eventName);
            });
        });
        
        // دالة لتهيئة تقويم الامتحانات
        function initializeCalendar() {
            const calendarEl = document.getElementById('examCalendar');
            const examEvents = <?php echo json_encode($schedule_type === 'exams' ? $schedule_data : []); ?>;
            const formattedEvents = examEvents.map(event => ({
                id: event.id,
                title: `${event.course_name} (${event.course_code}) - ${t('exam')}`,
                start: `${event.exam_date}T${event.start_time}`,
                end: `${event.exam_date}T${event.end_time}`,
                extendedProps: {
                    type: 'exam',
                    teacher: event.teacher_name,
                    location: event.location,
                    duration: event.exam_duration
                },
                backgroundColor: '#dc3545', // لون أحمر للامتحانات
                borderColor: '#dc3545'
            }));
            
            calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
                },
                locale: '<?php echo $lang; ?>',
                events: formattedEvents,
                editable: false, // يمكن تفعيل السحب والإفلات إذا لزم الأمر
                selectable: true,
                eventClick: function(info) {
                    // فتح مودال التعديل عند النقر على حدث الامتحان
                    const editModal = new bootstrap.Modal(document.getElementById('editScheduleEventModal'));
                    // ملء بيانات المودال بناءً على info.event
                    $('#editEventId').val(info.event.id);
                    $('#editEventType').val('exam');
                    // ... (ملء بقية الحقول)
                    $('#editCourseId').val(info.event.extendedProps.course_id); // تحتاج لإضافة course_id للبيانات
                    $('#editTeacherId').val(info.event.extendedProps.teacher_id); // تحتاج لإضافة teacher_id للبيانات
                    $('#editExamDate').val(info.event.startStr.substring(0, 10));
                    $('#editStartTime').val(info.event.startStr.substring(11, 16));
                    $('#editEndTime').val(info.event.endStr.substring(11, 16));
                    $('#editLocation').val(info.event.extendedProps.location);
                    $('#editExamDuration').val(info.event.extendedProps.duration);
                    
                    $('#editClassFields').hide();
                    $('#editExamFields').show();
                    
                    editModal.show();
                },
                dateClick: function(info) {
                    // فتح مودال الإضافة عند النقر على يوم فارغ
                    const addModal = new bootstrap.Modal(document.getElementById('addScheduleEventModal'));
                    $('#addEventType').val('exam');
                    toggleAddEventFields();
                    $('#addExamDate').val(info.dateStr);
                    addModal.show();
                }
            });
            
            calendar.render();
        }
        
        // تبديل الحقول في مودال الإضافة بناءً على نوع الحدث
        function toggleAddEventFields() {
            const eventType = document.getElementById('addEventType').value;
            const classFields = document.getElementById('addClassFields');
            const examFields = document.getElementById('addExamFields');
            const dayOfWeekInput = document.getElementById('addDayOfWeek');
            const examDateInput = document.getElementById('addExamDate');
            
            if (eventType === 'class') {
                classFields.style.display = 'block';
                examFields.style.display = 'none';
                dayOfWeekInput.required = true;
                examDateInput.required = false;
            } else {
                classFields.style.display = 'none';
                examFields.style.display = 'block';
                dayOfWeekInput.required = false;
                examDateInput.required = true;
            }
        }
        
        // تحديث قائمة البرامج والمعلمين بناءً على القسم المحدد (للفلتر)
        function updateProgramsAndTeachersFilter() {
            const departmentId = document.getElementById('department_filter').value;
            const programSelect = document.getElementById('program_filter');
            const teacherSelect = document.getElementById('teacher_filter');
            
            // إعادة تعيين قائمة البرامج
            programSelect.innerHTML = `<option value=""><?php echo t('all_programs'); ?></option>`;
            // إعادة تعيين قائمة المعلمين
            teacherSelect.innerHTML = `<option value=""><?php echo t('all_teachers'); ?></option>`;
            
            if (departmentId) {
                // هنا يجب إضافة طلب AJAX للحصول على البرامج والمعلمين حسب القسم
                // لأغراض العرض، سنستخدم بيانات وهمية
                
                const allPrograms = <?php echo json_encode(get_college_programs(get_db_connection(), $college_id)); ?>;
                const filteredPrograms = allPrograms.filter(p => p.department_id == departmentId);
                filteredPrograms.forEach(program => {
                    const option = document.createElement('option');
                    option.value = program.id;
                    option.textContent = program.name;
                    programSelect.appendChild(option);
                });
                
                const allTeachers = <?php echo json_encode(get_college_teachers(get_db_connection(), $college_id)); ?>;
                const filteredTeachers = allTeachers.filter(t => t.department_id == departmentId);
                filteredTeachers.forEach(teacher => {
                    const option = document.createElement('option');
                    option.value = teacher.id;
                    option.textContent = teacher.name;
                    teacherSelect.appendChild(option);
                });
            } else {
                // إذا لم يتم تحديد قسم، عرض جميع البرامج والمعلمين المتاحين للكلية
                const allPrograms = <?php echo json_encode(get_college_programs(get_db_connection(), $college_id)); ?>;
                allPrograms.forEach(program => {
                    const option = document.createElement('option');
                    option.value = program.id;
                    option.textContent = program.name;
                    programSelect.appendChild(option);
                });
                
                const allTeachers = <?php echo json_encode(get_college_teachers(get_db_connection(), $college_id)); ?>;
                allTeachers.forEach(teacher => {
                    const option = document.createElement('option');
                    option.value = teacher.id;
                    option.textContent = teacher.name;
                    teacherSelect.appendChild(option);
                });
            }
        }
        
        // دالة لبناء query string مع الحفاظ على الفلاتر الحالية
        function build_query_string(exclude = []) {
            const params = new URLSearchParams(window.location.search);
            let queryString = '';
            for (const [key, value] of params.entries()) {
                if (!exclude.includes(key)) {
                    queryString += `&${key}=${value}`;
                }
            }
            return queryString;
        }
    </script>
</body>
</html>
