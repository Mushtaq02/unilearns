<?php
/**
 * صفحة لوحة تحكم الطالب في نظام UniverBoard
 * تعرض ملخص المقررات والواجبات والإشعارات والتقويم الأكاديمي
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول الطالب
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات الطالب
$student_id = $_SESSION['user_id'];
$db = get_db_connection();
$student = get_student_info($db, $student_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// الحصول على المقررات المسجلة للطالب
$courses = get_student_courses($db, $student_id);

// الحصول على الواجبات القادمة
$upcoming_assignments = get_upcoming_assignments($db, $student_id);

// الحصول على الاختبارات القادمة
$upcoming_exams = get_upcoming_exams($db, $student_id);

// الحصول على الإشعارات الأخيرة
$notifications = get_recent_notifications($db, $student_id);

// الحصول على إحصائيات الطالب
$stats = get_student_stats($db, $student_id);

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('student_dashboard'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <!-- FullCalendar -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.0/main.min.css">
    
    <style>
        .dashboard-card {
            transition: all 0.3s ease;
            border-radius: 0.5rem;
            overflow: hidden;
            height: 100%;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .dashboard-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }
        
        .stat-card {
            text-align: center;
            padding: 1.5rem;
            border-radius: 0.5rem;
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .stat-label {
            font-size: 1rem;
            color: var(--gray-color);
        }
        
        .course-card {
            border-radius: 0.5rem;
            overflow: hidden;
            transition: all 0.3s ease;
            margin-bottom: 1rem;
        }
        
        .course-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        
        .course-header {
            padding: 1rem;
            color: white;
        }
        
        .course-body {
            padding: 1rem;
        }
        
        .course-footer {
            padding: 0.5rem 1rem;
            background-color: rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .task-item {
            padding: 0.75rem;
            border-radius: 0.5rem;
            margin-bottom: 0.75rem;
            transition: all 0.3s ease;
        }
        
        .task-item:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.05);
        }
        
        .notification-item {
            padding: 0.75rem;
            border-radius: 0.5rem;
            margin-bottom: 0.75rem;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
        }
        
        .notification-item:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.05);
        }
        
        .notification-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            color: white;
        }
        
        [dir="rtl"] .notification-icon {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .notification-content {
            flex: 1;
        }
        
        .progress-thin {
            height: 0.5rem;
            border-radius: 0.25rem;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link active" href="student_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <?php if (count($notifications) > 0): ?>
                        <span class="badge bg-danger"><?php echo count($notifications); ?></span>
                        <?php endif; ?>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <?php if (count($notifications) > 0): ?>
                            <?php foreach ($notifications as $notification): ?>
                                <a class="dropdown-item" href="<?php echo $notification['link']; ?>">
                                    <div class="d-flex align-items-center">
                                        <div class="notification-icon bg-<?php echo $notification['type']; ?>">
                                            <i class="fas fa-<?php echo $notification['icon']; ?>"></i>
                                        </div>
                                        <div class="notification-content">
                                            <p class="mb-1"><?php echo $notification['title']; ?></p>
                                            <small class="text-muted"><?php echo $notification['time']; ?></small>
                                        </div>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="dropdown-item text-center"><?php echo t('no_notifications'); ?></div>
                        <?php endif; ?>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user1.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. محمد أحمد</p>
                                    <small class="text-muted">تم تحديث درجات الاختبار النصفي</small>
                                    <small class="text-muted d-block">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user2.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">أ. سارة خالد</p>
                                    <small class="text-muted">تذكير بموعد تسليم المشروع النهائي</small>
                                    <small class="text-muted d-block">منذ ساعتين</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user3.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">إدارة الكلية</p>
                                    <small class="text-muted">إشعار بموعد التسجيل للفصل القادم</small>
                                    <small class="text-muted d-block">أمس</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $student['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $student['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $student['name']; ?></h6>
                            <small><?php echo $student['student_id']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="student_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="student_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <div>
                <h1 class="h3"><?php echo t('welcome'); ?>, <?php echo $student['first_name']; ?>!</h1>
                <p class="text-muted"><?php echo t('dashboard_subtitle'); ?></p>
            </div>
            <div>
                <span class="badge bg-primary"><?php echo t('semester'); ?>: <?php echo t('current_semester'); ?></span>
            </div>
        </div>
        
        <!-- إحصائيات سريعة -->
        <div class="row mb-4">
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="stat-card bg-primary bg-opacity-10">
                    <div class="stat-icon text-primary">
                        <i class="fas fa-book"></i>
                    </div>
                    <div class="stat-value text-primary"><?php echo $stats['courses_count']; ?></div>
                    <div class="stat-label"><?php echo t('registered_courses'); ?></div>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="stat-card bg-success bg-opacity-10">
                    <div class="stat-icon text-success">
                        <i class="fas fa-tasks"></i>
                    </div>
                    <div class="stat-value text-success"><?php echo $stats['assignments_count']; ?></div>
                    <div class="stat-label"><?php echo t('pending_assignments'); ?></div>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="stat-card bg-warning bg-opacity-10">
                    <div class="stat-icon text-warning">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-value text-warning"><?php echo $stats['exams_count']; ?></div>
                    <div class="stat-label"><?php echo t('upcoming_exams'); ?></div>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6 mb-3">
                <div class="stat-card bg-info bg-opacity-10">
                    <div class="stat-icon text-info">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-value text-info"><?php echo $stats['gpa']; ?></div>
                    <div class="stat-label"><?php echo t('current_gpa'); ?></div>
                </div>
            </div>
        </div>
        
        <!-- المحتوى الرئيسي -->
        <div class="row">
            <!-- العمود الأيسر -->
            <div class="col-lg-8">
                <!-- المقررات المسجلة -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><?php echo t('registered_courses'); ?></h5>
                        <a href="student_courses.php" class="btn btn-sm btn-primary"><?php echo t('view_all'); ?></a>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php if (count($courses) > 0): ?>
                                <?php foreach ($courses as $course): ?>
                                    <div class="col-md-6 mb-3">
                                        <div class="course-card">
                                            <div class="course-header" style="background-color: <?php echo $course['color']; ?>">
                                                <h5 class="mb-0"><?php echo $course['code']; ?> - <?php echo $course['name']; ?></h5>
                                                <small><?php echo $course['instructor']; ?></small>
                                            </div>
                                            <div class="course-body">
                                                <p class="mb-2"><?php echo substr($course['description'], 0, 100); ?>...</p>
                                                <div class="d-flex justify-content-between align-items-center mb-2">
                                                    <small class="text-muted"><?php echo t('progress'); ?>:</small>
                                                    <small class="text-muted"><?php echo $course['progress']; ?>%</small>
                                                </div>
                                                <div class="progress progress-thin mb-0">
                                                    <div class="progress-bar" role="progressbar" style="width: <?php echo $course['progress']; ?>%; background-color: <?php echo $course['color']; ?>" aria-valuenow="<?php echo $course['progress']; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                            <div class="course-footer">
                                                <small class="text-muted"><?php echo $course['schedule']; ?></small>
                                                <a href="student_course_details.php?id=<?php echo $course['id']; ?>" class="btn btn-sm btn-outline-primary"><?php echo t('view_course'); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="col-12">
                                    <div class="alert alert-info">
                                        <?php echo t('no_courses_registered'); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- الواجبات والاختبارات القادمة -->
                <div class="row">
                    <!-- الواجبات القادمة -->
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0"><?php echo t('upcoming_assignments'); ?></h5>
                                <a href="student_assignments.php" class="btn btn-sm btn-primary"><?php echo t('view_all'); ?></a>
                            </div>
                            <div class="card-body">
                                <?php if (count($upcoming_assignments) > 0): ?>
                                    <?php foreach ($upcoming_assignments as $assignment): ?>
                                        <div class="task-item border-start border-3" style="border-color: <?php echo $assignment['course_color']; ?> !important;">
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <h6 class="mb-0"><?php echo $assignment['title']; ?></h6>
                                                <span class="badge bg-<?php echo $assignment['status_color']; ?>"><?php echo $assignment['status']; ?></span>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <small class="text-muted"><?php echo $assignment['course_code']; ?> - <?php echo $assignment['course_name']; ?></small>
                                                <small class="text-<?php echo $assignment['due_color']; ?>"><?php echo $assignment['due_date']; ?></small>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="alert alert-info">
                                        <?php echo t('no_upcoming_assignments'); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- الاختبارات القادمة -->
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0"><?php echo t('upcoming_exams'); ?></h5>
                                <a href="student_exams.php" class="btn btn-sm btn-primary"><?php echo t('view_all'); ?></a>
                            </div>
                            <div class="card-body">
                                <?php if (count($upcoming_exams) > 0): ?>
                                    <?php foreach ($upcoming_exams as $exam): ?>
                                        <div class="task-item border-start border-3" style="border-color: <?php echo $exam['course_color']; ?> !important;">
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <h6 class="mb-0"><?php echo $exam['title']; ?></h6>
                                                <span class="badge bg-<?php echo $exam['type_color']; ?>"><?php echo $exam['type']; ?></span>
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <small class="text-muted"><?php echo $exam['course_code']; ?> - <?php echo $exam['course_name']; ?></small>
                                                <small class="text-<?php echo $exam['date_color']; ?>"><?php echo $exam['date']; ?></small>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="alert alert-info">
                                        <?php echo t('no_upcoming_exams'); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- التقويم الأكاديمي -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0"><?php echo t('academic_calendar'); ?></h5>
                    </div>
                    <div class="card-body">
                        <div id="calendar"></div>
                    </div>
                </div>
            </div>
            
            <!-- العمود الأيمن -->
            <div class="col-lg-4">
                <!-- الملف الشخصي -->
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <img src="<?php echo $student['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $student['name']; ?>" class="rounded-circle mb-3" width="100" height="100">
                        <h5 class="mb-1"><?php echo $student['name']; ?></h5>
                        <p class="text-muted mb-3"><?php echo $student['student_id']; ?></p>
                        <div class="d-flex justify-content-center mb-3">
                            <div class="px-3 border-end">
                                <h6 class="mb-0"><?php echo $student['level']; ?></h6>
                                <small class="text-muted"><?php echo t('level'); ?></small>
                            </div>
                            <div class="px-3 border-end">
                                <h6 class="mb-0"><?php echo $student['completed_hours']; ?></h6>
                                <small class="text-muted"><?php echo t('completed_hours'); ?></small>
                            </div>
                            <div class="px-3">
                                <h6 class="mb-0"><?php echo $student['remaining_hours']; ?></h6>
                                <small class="text-muted"><?php echo t('remaining_hours'); ?></small>
                            </div>
                        </div>
                        <a href="student_profile.php" class="btn btn-outline-primary btn-sm"><?php echo t('view_profile'); ?></a>
                    </div>
                </div>
                
                <!-- الإشعارات الأخيرة -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><?php echo t('recent_notifications'); ?></h5>
                        <a href="student_notifications.php" class="btn btn-sm btn-primary"><?php echo t('view_all'); ?></a>
                    </div>
                    <div class="card-body">
                        <?php if (count($notifications) > 0): ?>
                            <?php foreach ($notifications as $notification): ?>
                                <div class="notification-item">
                                    <div class="notification-icon bg-<?php echo $notification['type']; ?>">
                                        <i class="fas fa-<?php echo $notification['icon']; ?>"></i>
                                    </div>
                                    <div class="notification-content">
                                        <h6 class="mb-1"><?php echo $notification['title']; ?></h6>
                                        <p class="mb-1 small"><?php echo $notification['message']; ?></p>
                                        <small class="text-muted"><?php echo $notification['time']; ?></small>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="alert alert-info">
                                <?php echo t('no_notifications'); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- روابط سريعة -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0"><?php echo t('quick_links'); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="list-group">
                            <a href="student_registration.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                <?php echo t('course_registration'); ?>
                                <i class="fas fa-chevron-right"></i>
                            </a>
                            <a href="student_schedule.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                <?php echo t('class_schedule'); ?>
                                <i class="fas fa-chevron-right"></i>
                            </a>
                            <a href="student_grades.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                <?php echo t('grades_report'); ?>
                                <i class="fas fa-chevron-right"></i>
                            </a>
                            <a href="student_transcript.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                <?php echo t('academic_transcript'); ?>
                                <i class="fas fa-chevron-right"></i>
                            </a>
                            <a href="student_support.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                <?php echo t('technical_support'); ?>
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <!-- الإعلانات -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0"><?php echo t('announcements'); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-primary">
                            <h6 class="alert-heading"><?php echo t('registration_period'); ?></h6>
                            <p class="mb-0 small">تبدأ فترة التسجيل للفصل الدراسي القادم من 15 إلى 30 يونيو 2025. يرجى مراجعة المرشد الأكاديمي قبل التسجيل.</p>
                        </div>
                        <div class="alert alert-info">
                            <h6 class="alert-heading"><?php echo t('library_hours'); ?></h6>
                            <p class="mb-0 small">تم تمديد ساعات عمل المكتبة خلال فترة الاختبارات النهائية من الساعة 8 صباحاً حتى 10 مساءً.</p>
                        </div>
                        <div class="alert alert-success">
                            <h6 class="alert-heading"><?php echo t('new_courses'); ?></h6>
                            <p class="mb-0 small">تم إضافة مقررات جديدة في تخصص علوم الحاسب للفصل الدراسي القادم. يمكنك الاطلاع عليها من خلال دليل المقررات.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- FullCalendar -->
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.0/main.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.0/locales-all.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تهيئة التقويم
            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                locale: '<?php echo $lang; ?>',
                direction: '<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,listWeek'
                },
                events: [
                    {
                        title: 'الاختبار النصفي - مقدمة في قواعد البيانات',
                        start: '2025-05-25',
                        backgroundColor: '#003049',
                        borderColor: '#003049'
                    },
                    {
                        title: 'تسليم مشروع برمجة الويب',
                        start: '2025-05-28',
                        backgroundColor: '#669bbc',
                        borderColor: '#669bbc'
                    },
                    {
                        title: 'محاضرة خاصة - الذكاء الاصطناعي',
                        start: '2025-05-22',
                        backgroundColor: '#f77f00',
                        borderColor: '#f77f00'
                    },
                    {
                        title: 'اجتماع مجلس الطلاب',
                        start: '2025-05-23T14:30:00',
                        backgroundColor: '#d62828',
                        borderColor: '#d62828'
                    },
                    {
                        title: 'ورشة عمل - مهارات العرض',
                        start: '2025-05-26T10:00:00',
                        end: '2025-05-26T12:00:00',
                        backgroundColor: '#457b9d',
                        borderColor: '#457b9d'
                    },
                    {
                        title: 'بدء التسجيل للفصل الصيفي',
                        start: '2025-06-15',
                        backgroundColor: '#2a9d8f',
                        borderColor: '#2a9d8f'
                    }
                ],
                eventClick: function(info) {
                    alert(info.event.title);
                }
            });
            calendar.render();
            
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
        });
    </script>
</body>
</html>
