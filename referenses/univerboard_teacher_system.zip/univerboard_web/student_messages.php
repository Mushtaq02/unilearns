<?php
/**
 * صفحة الرسائل للطالب في نظام UniverBoard
 * تعرض المحادثات والرسائل وتتيح إرسال رسائل جديدة
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول الطالب
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات الطالب
$student_id = $_SESSION['user_id'];
$db = get_db_connection();
$student = get_student_info($db, $student_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// الحصول على المحادثات
$conversations = get_student_conversations($db, $student_id);

// الحصول على الرسائل للمحادثة المحددة
$selected_conversation_id = isset($_GET['conversation_id']) ? intval($_GET['conversation_id']) : 0;
$messages = [];
$conversation_info = null;

if ($selected_conversation_id > 0) {
    $messages = get_conversation_messages($db, $selected_conversation_id, $student_id);
    $conversation_info = get_conversation_info($db, $selected_conversation_id);
    
    // تحديث حالة الرسائل إلى مقروءة
    update_messages_status($db, $selected_conversation_id, $student_id);
}

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('messages'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .messages-container {
            display: flex;
            height: calc(100vh - 200px);
            min-height: 500px;
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .conversations-list {
            width: 300px;
            border-right: 1px solid rgba(0, 0, 0, 0.1);
            overflow-y: auto;
            background-color: #f8f9fa;
        }
        
        [dir="rtl"] .conversations-list {
            border-right: none;
            border-left: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .conversations-list {
            background-color: #2c3034;
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .conversation-item {
            padding: 1rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
        }
        
        .theme-dark .conversation-item {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .conversation-item:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .theme-dark .conversation-item:hover {
            background-color: rgba(255, 255, 255, 0.05);
        }
        
        .conversation-item.active {
            background-color: rgba(0, 48, 73, 0.1);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .conversation-item.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .theme-dark .conversation-item.active {
            background-color: rgba(102, 155, 188, 0.1);
        }
        
        .conversation-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 1rem;
        }
        
        [dir="rtl"] .conversation-avatar {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .conversation-info {
            flex: 1;
            min-width: 0;
        }
        
        .conversation-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .conversation-preview {
            color: var(--gray-color);
            font-size: 0.9rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .conversation-meta {
            text-align: right;
            min-width: 50px;
        }
        
        [dir="rtl"] .conversation-meta {
            text-align: left;
        }
        
        .conversation-time {
            font-size: 0.8rem;
            color: var(--gray-color);
            margin-bottom: 0.25rem;
        }
        
        .conversation-badge {
            display: inline-block;
            min-width: 20px;
            height: 20px;
            border-radius: 10px;
            background-color: var(--primary-color);
            color: white;
            font-size: 0.7rem;
            text-align: center;
            line-height: 20px;
            padding: 0 6px;
        }
        
        .conversation-status {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            position: absolute;
            bottom: 1rem;
            right: 1rem;
        }
        
        [dir="rtl"] .conversation-status {
            right: auto;
            left: 1rem;
        }
        
        .conversation-status.online {
            background-color: #28a745;
        }
        
        .conversation-status.offline {
            background-color: #dc3545;
        }
        
        .messages-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            background-color: white;
        }
        
        .theme-dark .messages-content {
            background-color: #212529;
        }
        
        .messages-header {
            padding: 1rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .theme-dark .messages-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .messages-title {
            display: flex;
            align-items: center;
        }
        
        .messages-title img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 1rem;
        }
        
        [dir="rtl"] .messages-title img {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .messages-title-info h5 {
            margin-bottom: 0.25rem;
        }
        
        .messages-title-info p {
            margin-bottom: 0;
            font-size: 0.9rem;
            color: var(--gray-color);
        }
        
        .messages-actions {
            display: flex;
            gap: 0.5rem;
        }
        
        .messages-actions button {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(0, 0, 0, 0.05);
            border: none;
            color: var(--text-color);
            transition: all 0.2s ease;
        }
        
        .theme-dark .messages-actions button {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .messages-actions button:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        .messages-body {
            flex: 1;
            padding: 1rem;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }
        
        .message {
            max-width: 70%;
            margin-bottom: 1rem;
            position: relative;
        }
        
        .message.sent {
            align-self: flex-end;
        }
        
        .message.received {
            align-self: flex-start;
        }
        
        .message-content {
            padding: 0.75rem 1rem;
            border-radius: 1rem;
            position: relative;
        }
        
        .message.sent .message-content {
            background-color: var(--primary-color);
            color: white;
            border-bottom-right-radius: 0;
        }
        
        .message.received .message-content {
            background-color: #f0f2f5;
            color: var(--text-color);
            border-bottom-left-radius: 0;
        }
        
        .theme-dark .message.received .message-content {
            background-color: #343a40;
        }
        
        .message-time {
            font-size: 0.7rem;
            color: rgba(255, 255, 255, 0.7);
            text-align: right;
            margin-top: 0.25rem;
        }
        
        .message.received .message-time {
            color: var(--gray-color);
            text-align: left;
        }
        
        [dir="rtl"] .message.received .message-time {
            text-align: right;
        }
        
        [dir="rtl"] .message.sent .message-time {
            text-align: left;
        }
        
        .message-status {
            font-size: 0.7rem;
            color: rgba(255, 255, 255, 0.7);
            margin-left: 0.25rem;
        }
        
        [dir="rtl"] .message-status {
            margin-left: 0;
            margin-right: 0.25rem;
        }
        
        .message-date {
            text-align: center;
            margin: 1rem 0;
            position: relative;
        }
        
        .message-date span {
            background-color: rgba(0, 0, 0, 0.05);
            padding: 0.25rem 1rem;
            border-radius: 1rem;
            font-size: 0.8rem;
            color: var(--gray-color);
        }
        
        .theme-dark .message-date span {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .messages-footer {
            padding: 1rem;
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .messages-footer {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .message-form {
            display: flex;
            align-items: center;
        }
        
        .message-input {
            flex: 1;
            border: none;
            background-color: rgba(0, 0, 0, 0.05);
            border-radius: 2rem;
            padding: 0.75rem 1rem;
            margin-right: 0.5rem;
            resize: none;
        }
        
        [dir="rtl"] .message-input {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .theme-dark .message-input {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .message-input:focus {
            outline: none;
            box-shadow: 0 0 0 2px rgba(0, 48, 73, 0.2);
        }
        
        .message-actions {
            display: flex;
            gap: 0.5rem;
        }
        
        .message-actions button {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(0, 0, 0, 0.05);
            border: none;
            color: var(--text-color);
            transition: all 0.2s ease;
        }
        
        .theme-dark .message-actions button {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .message-actions button:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        .message-actions button.send {
            background-color: var(--primary-color);
            color: white;
        }
        
        .message-actions button.send:hover {
            background-color: #002033;
        }
        
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            padding: 2rem;
            text-align: center;
        }
        
        .empty-state i {
            font-size: 4rem;
            color: var(--gray-color);
            margin-bottom: 1.5rem;
        }
        
        .empty-state h4 {
            margin-bottom: 1rem;
        }
        
        .empty-state p {
            color: var(--gray-color);
            margin-bottom: 1.5rem;
            max-width: 400px;
        }
        
        .new-message-btn {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            z-index: 10;
            transition: all 0.2s ease;
        }
        
        [dir="rtl"] .new-message-btn {
            right: auto;
            left: 2rem;
        }
        
        .new-message-btn:hover {
            background-color: #002033;
            transform: scale(1.05);
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
            
            .messages-container {
                flex-direction: column;
                height: auto;
            }
            
            .conversations-list {
                width: 100%;
                max-height: 300px;
                border-right: none;
                border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            }
            
            [dir="rtl"] .conversations-list {
                border-left: none;
            }
            
            .messages-content {
                height: 500px;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .search-box {
            position: relative;
            margin-bottom: 1rem;
        }
        
        .search-box input {
            width: 100%;
            padding: 0.75rem 1rem 0.75rem 3rem;
            border: none;
            border-radius: 0.5rem;
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        [dir="rtl"] .search-box input {
            padding: 0.75rem 3rem 0.75rem 1rem;
        }
        
        .theme-dark .search-box input {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .search-box input:focus {
            outline: none;
            box-shadow: 0 0 0 2px rgba(0, 48, 73, 0.2);
        }
        
        .search-box i {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-color);
        }
        
        [dir="rtl"] .search-box i {
            left: auto;
            right: 1rem;
        }
        
        .file-preview {
            display: flex;
            align-items: center;
            padding: 0.5rem;
            background-color: rgba(0, 0, 0, 0.05);
            border-radius: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .theme-dark .file-preview {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .file-preview i {
            font-size: 1.5rem;
            margin-right: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .file-preview i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .file-info {
            flex: 1;
        }
        
        .file-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .file-size {
            font-size: 0.8rem;
            color: var(--gray-color);
        }
        
        .file-actions {
            display: flex;
            gap: 0.5rem;
        }
        
        .file-actions button {
            background: none;
            border: none;
            color: var(--gray-color);
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .file-actions button:hover {
            color: var(--primary-color);
        }
        
        .message-file {
            display: flex;
            align-items: center;
            background-color: rgba(255, 255, 255, 0.1);
            padding: 0.5rem;
            border-radius: 0.5rem;
            margin-top: 0.5rem;
        }
        
        .message-file i {
            font-size: 1.5rem;
            margin-right: 0.5rem;
        }
        
        [dir="rtl"] .message-file i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .message-file-info {
            flex: 1;
        }
        
        .message-file-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
            color: white;
        }
        
        .message-file-size {
            font-size: 0.8rem;
            color: rgba(255, 255, 255, 0.7);
        }
        
        .message.received .message-file-name {
            color: var(--text-color);
        }
        
        .message.received .message-file-size {
            color: var(--gray-color);
        }
        
        .message-file-actions a {
            color: rgba(255, 255, 255, 0.7);
            transition: all 0.2s ease;
        }
        
        .message-file-actions a:hover {
            color: white;
        }
        
        .message.received .message-file-actions a {
            color: var(--gray-color);
        }
        
        .message.received .message-file-actions a:hover {
            color: var(--text-color);
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="student_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link active" href="student_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-book"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم إضافة محتوى جديد في مقرر برمجة الويب</p>
                                    <small class="text-muted">منذ 10 دقائق</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-tasks"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تذكير: موعد تسليم واجب قواعد البيانات غداً</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-success text-white rounded-circle">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تصحيح واجب البرمجة المتقدمة</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user1.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. محمد أحمد</p>
                                    <small class="text-muted">هل لديك استفسارات حول المشروع النهائي؟</small>
                                    <small class="text-muted d-block">منذ 15 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user2.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">أ. سارة خالد</p>
                                    <small class="text-muted">تم تحديد موعد المراجعة النهائية للاختبار</small>
                                    <small class="text-muted d-block">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $student['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $student['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $student['name']; ?></h6>
                            <small><?php echo $student['student_id']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="student_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="student_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <div>
                <h1 class="h3"><?php echo t('messages'); ?></h1>
                <p class="text-muted"><?php echo t('messages_subtitle'); ?></p>
            </div>
        </div>
        
        <!-- حاوية الرسائل -->
        <div class="messages-container">
            <!-- قائمة المحادثات -->
            <div class="conversations-list">
                <div class="search-box p-3">
                    <input type="text" placeholder="<?php echo t('search_conversations'); ?>" id="conversationSearch">
                    <i class="fas fa-search"></i>
                </div>
                
                <?php if (count($conversations) > 0): ?>
                    <?php foreach ($conversations as $conversation): ?>
                        <a href="student_messages.php?conversation_id=<?php echo $conversation['id']; ?>" class="text-decoration-none">
                            <div class="conversation-item d-flex align-items-center <?php echo $selected_conversation_id === $conversation['id'] ? 'active' : ''; ?>">
                                <img src="<?php echo $conversation['avatar']; ?>" alt="<?php echo $conversation['name']; ?>" class="conversation-avatar">
                                <div class="conversation-info">
                                    <div class="conversation-name"><?php echo $conversation['name']; ?></div>
                                    <div class="conversation-preview"><?php echo $conversation['last_message']; ?></div>
                                </div>
                                <div class="conversation-meta">
                                    <div class="conversation-time"><?php echo $conversation['time']; ?></div>
                                    <?php if ($conversation['unread_count'] > 0): ?>
                                        <div class="conversation-badge"><?php echo $conversation['unread_count']; ?></div>
                                    <?php endif; ?>
                                </div>
                                <div class="conversation-status <?php echo $conversation['online'] ? 'online' : 'offline'; ?>"></div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="p-3 text-center text-muted">
                        <p><?php echo t('no_conversations'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- محتوى الرسائل -->
            <div class="messages-content">
                <?php if ($selected_conversation_id > 0 && $conversation_info): ?>
                    <!-- رأس الرسائل -->
                    <div class="messages-header">
                        <div class="messages-title">
                            <img src="<?php echo $conversation_info['avatar']; ?>" alt="<?php echo $conversation_info['name']; ?>">
                            <div class="messages-title-info">
                                <h5><?php echo $conversation_info['name']; ?></h5>
                                <p><?php echo $conversation_info['status']; ?></p>
                            </div>
                        </div>
                        <div class="messages-actions">
                            <button type="button" title="<?php echo t('voice_call'); ?>">
                                <i class="fas fa-phone-alt"></i>
                            </button>
                            <button type="button" title="<?php echo t('video_call'); ?>">
                                <i class="fas fa-video"></i>
                            </button>
                            <button type="button" title="<?php echo t('info'); ?>" data-bs-toggle="modal" data-bs-target="#conversationInfoModal">
                                <i class="fas fa-info-circle"></i>
                            </button>
                        </div>
                    </div>
                    
                    <!-- جسم الرسائل -->
                    <div class="messages-body" id="messagesBody">
                        <?php
                        $current_date = '';
                        foreach ($messages as $message):
                            $message_date = date('Y-m-d', strtotime($message['timestamp']));
                            if ($message_date !== $current_date):
                                $current_date = $message_date;
                        ?>
                            <div class="message-date">
                                <span><?php echo format_date($message_date); ?></span>
                            </div>
                        <?php endif; ?>
                            
                            <div class="message <?php echo $message['is_sent'] ? 'sent' : 'received'; ?>">
                                <div class="message-content">
                                    <?php echo $message['content']; ?>
                                    
                                    <?php if (isset($message['file'])): ?>
                                        <div class="message-file">
                                            <i class="fas fa-file-<?php echo $message['file']['icon']; ?>"></i>
                                            <div class="message-file-info">
                                                <div class="message-file-name"><?php echo $message['file']['name']; ?></div>
                                                <div class="message-file-size"><?php echo $message['file']['size']; ?></div>
                                            </div>
                                            <div class="message-file-actions">
                                                <a href="<?php echo $message['file']['url']; ?>" download>
                                                    <i class="fas fa-download"></i>
                                                </a>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="message-time">
                                    <?php echo date('H:i', strtotime($message['timestamp'])); ?>
                                    <?php if ($message['is_sent']): ?>
                                        <span class="message-status">
                                            <i class="fas <?php echo $message['is_read'] ? 'fa-check-double' : 'fa-check'; ?>"></i>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- تذييل الرسائل -->
                    <div class="messages-footer">
                        <form id="messageForm" class="message-form">
                            <input type="hidden" name="conversation_id" value="<?php echo $selected_conversation_id; ?>">
                            <textarea class="message-input" name="message" placeholder="<?php echo t('type_message'); ?>" rows="1"></textarea>
                            <div class="message-actions">
                                <button type="button" id="attachFile" title="<?php echo t('attach_file'); ?>">
                                    <i class="fas fa-paperclip"></i>
                                </button>
                                <button type="button" id="recordVoice" title="<?php echo t('voice_message'); ?>">
                                    <i class="fas fa-microphone"></i>
                                </button>
                                <button type="submit" class="send" title="<?php echo t('send'); ?>">
                                    <i class="fas fa-paper-plane"></i>
                                </button>
                            </div>
                            <input type="file" id="fileInput" style="display: none;">
                        </form>
                        
                        <div id="filePreview" style="display: none;"></div>
                    </div>
                <?php else: ?>
                    <!-- حالة فارغة -->
                    <div class="empty-state">
                        <i class="fas fa-comments"></i>
                        <h4><?php echo t('select_conversation'); ?></h4>
                        <p><?php echo t('select_conversation_message'); ?></p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#newMessageModal">
                            <i class="fas fa-plus-circle me-1"></i> <?php echo t('new_message'); ?>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- زر رسالة جديدة -->
        <a href="#" class="new-message-btn" data-bs-toggle="modal" data-bs-target="#newMessageModal">
            <i class="fas fa-pen"></i>
        </a>
    </div>
    
    <!-- مودال معلومات المحادثة -->
    <div class="modal fade" id="conversationInfoModal" tabindex="-1" aria-labelledby="conversationInfoModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="conversationInfoModalLabel"><?php echo t('conversation_info'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php if ($conversation_info): ?>
                        <div class="text-center mb-4">
                            <img src="<?php echo $conversation_info['avatar']; ?>" alt="<?php echo $conversation_info['name']; ?>" class="rounded-circle" width="100" height="100">
                            <h5 class="mt-3"><?php echo $conversation_info['name']; ?></h5>
                            <p class="text-muted"><?php echo $conversation_info['title']; ?></p>
                            <div class="d-flex justify-content-center gap-2">
                                <a href="#" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-envelope me-1"></i> <?php echo t('email'); ?>
                                </a>
                                <a href="#" class="btn btn-sm btn-outline-success">
                                    <i class="fas fa-phone-alt me-1"></i> <?php echo t('call'); ?>
                                </a>
                            </div>
                        </div>
                        
                        <div class="list-group list-group-flush">
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <i class="fas fa-envelope me-2 text-primary"></i> <?php echo t('email'); ?>
                                </div>
                                <div><?php echo $conversation_info['email']; ?></div>
                            </div>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <i class="fas fa-phone-alt me-2 text-success"></i> <?php echo t('phone'); ?>
                                </div>
                                <div><?php echo $conversation_info['phone']; ?></div>
                            </div>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <i class="fas fa-building me-2 text-info"></i> <?php echo t('department'); ?>
                                </div>
                                <div><?php echo $conversation_info['department']; ?></div>
                            </div>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <i class="fas fa-clock me-2 text-warning"></i> <?php echo t('office_hours'); ?>
                                </div>
                                <div><?php echo $conversation_info['office_hours']; ?></div>
                            </div>
                        </div>
                        
                        <div class="mt-4">
                            <h6><?php echo t('shared_files'); ?></h6>
                            <div class="list-group list-group-flush">
                                <?php if (isset($conversation_info['files']) && count($conversation_info['files']) > 0): ?>
                                    <?php foreach ($conversation_info['files'] as $file): ?>
                                        <a href="<?php echo $file['url']; ?>" class="list-group-item list-group-item-action d-flex align-items-center" download>
                                            <i class="fas fa-file-<?php echo $file['icon']; ?> me-3 text-primary"></i>
                                            <div>
                                                <div><?php echo $file['name']; ?></div>
                                                <small class="text-muted"><?php echo $file['size']; ?> - <?php echo $file['date']; ?></small>
                                            </div>
                                        </a>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="list-group-item text-center text-muted">
                                        <p><?php echo t('no_shared_files'); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('close'); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال رسالة جديدة -->
    <div class="modal fade" id="newMessageModal" tabindex="-1" aria-labelledby="newMessageModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newMessageModalLabel"><?php echo t('new_message'); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="newMessageForm">
                        <div class="mb-3">
                            <label for="recipient" class="form-label"><?php echo t('to'); ?></label>
                            <select class="form-select" id="recipient" name="recipient" required>
                                <option value=""><?php echo t('select_recipient'); ?></option>
                                <option value="teacher"><?php echo t('teachers'); ?></option>
                                <option value="student"><?php echo t('students'); ?></option>
                                <option value="admin"><?php echo t('administrators'); ?></option>
                            </select>
                        </div>
                        
                        <div class="mb-3" id="recipientListContainer" style="display: none;">
                            <label for="recipientList" class="form-label"><?php echo t('select_recipient'); ?></label>
                            <select class="form-select" id="recipientList" name="recipient_id">
                                <option value=""><?php echo t('loading'); ?>...</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="subject" class="form-label"><?php echo t('subject'); ?></label>
                            <input type="text" class="form-control" id="subject" name="subject" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="message" class="form-label"><?php echo t('message'); ?></label>
                            <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="attachment" class="form-label"><?php echo t('attachment'); ?> (<?php echo t('optional'); ?>)</label>
                            <input type="file" class="form-control" id="attachment" name="attachment">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('cancel'); ?></button>
                    <button type="button" class="btn btn-primary" id="sendNewMessage"><?php echo t('send'); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // تمرير إلى أسفل محادثة الرسائل
            const messagesBody = document.getElementById('messagesBody');
            if (messagesBody) {
                messagesBody.scrollTop = messagesBody.scrollHeight;
            }
            
            // البحث في المحادثات
            const conversationSearch = document.getElementById('conversationSearch');
            if (conversationSearch) {
                conversationSearch.addEventListener('input', function() {
                    const searchTerm = this.value.toLowerCase();
                    const conversations = document.querySelectorAll('.conversation-item');
                    
                    conversations.forEach(conversation => {
                        const name = conversation.querySelector('.conversation-name').textContent.toLowerCase();
                        const preview = conversation.querySelector('.conversation-preview').textContent.toLowerCase();
                        
                        if (name.includes(searchTerm) || preview.includes(searchTerm)) {
                            conversation.closest('a').style.display = 'block';
                        } else {
                            conversation.closest('a').style.display = 'none';
                        }
                    });
                });
            }
            
            // إرسال رسالة جديدة
            const messageForm = document.getElementById('messageForm');
            if (messageForm) {
                messageForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const messageInput = this.querySelector('.message-input');
                    const message = messageInput.value.trim();
                    const conversationId = this.querySelector('input[name="conversation_id"]').value;
                    
                    if (message) {
                        // إرسال الرسالة إلى الخادم
                        // هنا يمكن إضافة كود لإرسال طلب AJAX
                        
                        // إضافة الرسالة إلى المحادثة
                        const messagesBody = document.getElementById('messagesBody');
                        const newMessage = document.createElement('div');
                        newMessage.className = 'message sent';
                        newMessage.innerHTML = `
                            <div class="message-content">
                                ${message}
                            </div>
                            <div class="message-time">
                                ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                <span class="message-status">
                                    <i class="fas fa-check"></i>
                                </span>
                            </div>
                        `;
                        messagesBody.appendChild(newMessage);
                        
                        // تمرير إلى أسفل المحادثة
                        messagesBody.scrollTop = messagesBody.scrollHeight;
                        
                        // مسح حقل الإدخال
                        messageInput.value = '';
                    }
                });
            }
            
            // إرفاق ملف
            const attachFileButton = document.getElementById('attachFile');
            const fileInput = document.getElementById('fileInput');
            const filePreview = document.getElementById('filePreview');
            
            if (attachFileButton && fileInput && filePreview) {
                attachFileButton.addEventListener('click', function() {
                    fileInput.click();
                });
                
                fileInput.addEventListener('change', function() {
                    if (this.files.length > 0) {
                        const file = this.files[0];
                        const fileSize = formatFileSize(file.size);
                        const fileIcon = getFileIcon(file.name);
                        
                        filePreview.innerHTML = `
                            <div class="file-preview">
                                <i class="fas fa-file-${fileIcon}"></i>
                                <div class="file-info">
                                    <div class="file-name">${file.name}</div>
                                    <div class="file-size">${fileSize}</div>
                                </div>
                                <div class="file-actions">
                                    <button type="button" id="removeFile">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        `;
                        filePreview.style.display = 'block';
                        
                        // إزالة الملف
                        document.getElementById('removeFile').addEventListener('click', function() {
                            fileInput.value = '';
                            filePreview.innerHTML = '';
                            filePreview.style.display = 'none';
                        });
                    }
                });
            }
            
            // تسجيل رسالة صوتية
            const recordVoiceButton = document.getElementById('recordVoice');
            if (recordVoiceButton) {
                recordVoiceButton.addEventListener('click', function() {
                    alert('سيتم تنفيذ تسجيل الرسائل الصوتية قريباً');
                });
            }
            
            // إرسال رسالة جديدة من المودال
            const newMessageForm = document.getElementById('newMessageForm');
            const sendNewMessageButton = document.getElementById('sendNewMessage');
            
            if (newMessageForm && sendNewMessageButton) {
                sendNewMessageButton.addEventListener('click', function() {
                    // التحقق من صحة النموذج
                    if (newMessageForm.checkValidity()) {
                        // إرسال الرسالة إلى الخادم
                        // هنا يمكن إضافة كود لإرسال طلب AJAX
                        
                        // إغلاق المودال
                        const modal = bootstrap.Modal.getInstance(document.getElementById('newMessageModal'));
                        modal.hide();
                        
                        // إعادة تعيين النموذج
                        newMessageForm.reset();
                        
                        // عرض رسالة نجاح
                        alert('تم إرسال الرسالة بنجاح!');
                    } else {
                        newMessageForm.reportValidity();
                    }
                });
            }
            
            // تحميل قائمة المستلمين عند تغيير نوع المستلم
            const recipientSelect = document.getElementById('recipient');
            const recipientListContainer = document.getElementById('recipientListContainer');
            const recipientList = document.getElementById('recipientList');
            
            if (recipientSelect && recipientListContainer && recipientList) {
                recipientSelect.addEventListener('change', function() {
                    const recipientType = this.value;
                    
                    if (recipientType) {
                        // إظهار قائمة المستلمين
                        recipientListContainer.style.display = 'block';
                        
                        // تحميل قائمة المستلمين من الخادم
                        // هنا يمكن إضافة كود لإرسال طلب AJAX
                        
                        // محاكاة تحميل البيانات
                        setTimeout(function() {
                            let options = '';
                            
                            if (recipientType === 'teacher') {
                                options = `
                                    <option value="1">د. محمد أحمد - أستاذ علوم الحاسب</option>
                                    <option value="2">د. سارة خالد - أستاذة الرياضيات</option>
                                    <option value="3">د. أحمد محمود - أستاذ قواعد البيانات</option>
                                    <option value="4">د. فاطمة علي - أستاذة البرمجة</option>
                                `;
                            } else if (recipientType === 'student') {
                                options = `
                                    <option value="5">عمر خالد - طالب علوم الحاسب</option>
                                    <option value="6">نورا أحمد - طالبة علوم الحاسب</option>
                                    <option value="7">محمد سعيد - طالب هندسة البرمجيات</option>
                                    <option value="8">ليلى محمود - طالبة نظم المعلومات</option>
                                `;
                            } else if (recipientType === 'admin') {
                                options = `
                                    <option value="9">أ. خالد محمد - مدير النظام</option>
                                    <option value="10">أ. سمية أحمد - مسؤولة شؤون الطلاب</option>
                                    <option value="11">أ. عبدالله علي - مسؤول الدعم الفني</option>
                                `;
                            }
                            
                            recipientList.innerHTML = options;
                        }, 500);
                    } else {
                        // إخفاء قائمة المستلمين
                        recipientListContainer.style.display = 'none';
                    }
                });
            }
            
            // دالة تنسيق حجم الملف
            function formatFileSize(bytes) {
                if (bytes === 0) return '0 Bytes';
                
                const k = 1024;
                const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                
                return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
            }
            
            // دالة الحصول على أيقونة الملف
            function getFileIcon(filename) {
                const extension = filename.split('.').pop().toLowerCase();
                
                const iconMap = {
                    'pdf': 'pdf',
                    'doc': 'word',
                    'docx': 'word',
                    'xls': 'excel',
                    'xlsx': 'excel',
                    'ppt': 'powerpoint',
                    'pptx': 'powerpoint',
                    'jpg': 'image',
                    'jpeg': 'image',
                    'png': 'image',
                    'gif': 'image',
                    'zip': 'archive',
                    'rar': 'archive',
                    'txt': 'alt',
                    'mp3': 'audio',
                    'mp4': 'video'
                };
                
                return iconMap[extension] || 'alt';
            }
        });
        
        // دالة تنسيق التاريخ
        function format_date(date_str) {
            const date = new Date(date_str);
            const today = new Date();
            const yesterday = new Date(today);
            yesterday.setDate(yesterday.getDate() - 1);
            
            if (date.toDateString() === today.toDateString()) {
                return 'اليوم';
            } else if (date.toDateString() === yesterday.toDateString()) {
                return 'أمس';
            } else {
                const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                return date.toLocaleDateString('ar-EG', options);
            }
        }
    </script>
</body>
</html>
