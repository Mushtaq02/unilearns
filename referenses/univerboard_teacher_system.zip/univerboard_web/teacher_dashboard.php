<?php
/**
 * صفحة لوحة تحكم المعلم في نظام UniverBoard
 * تعرض ملخص المقررات والإحصائيات والمهام القادمة للمعلم
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول المعلم
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'teacher') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات المعلم
$teacher_id = $_SESSION['user_id'];
$db = get_db_connection();
$teacher = get_teacher_info($db, $teacher_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// الحصول على المقررات التي يدرسها المعلم
$courses = get_teacher_courses($db, $teacher_id);

// الحصول على الإحصائيات
$stats = get_teacher_stats($db, $teacher_id);

// الحصول على المهام القادمة
$upcoming_tasks = get_teacher_upcoming_tasks($db, $teacher_id);

// الحصول على آخر الإشعارات
$notifications = get_teacher_notifications($db, $teacher_id, 5);

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('teacher_dashboard'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        .dashboard-card {
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            height: 100%;
            overflow: hidden;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
        }
        
        .dashboard-card-header {
            padding: 1.25rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .theme-dark .dashboard-card-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .dashboard-card-title {
            font-weight: 600;
            margin-bottom: 0;
        }
        
        .dashboard-card-body {
            padding: 1.25rem;
        }
        
        .dashboard-stat-card {
            border-radius: 0.5rem;
            padding: 1.5rem;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            transition: all 0.3s ease;
        }
        
        .dashboard-stat-card:hover {
            transform: translateY(-5px);
        }
        
        .dashboard-stat-card.primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .dashboard-stat-card.secondary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .dashboard-stat-card.success {
            background-color: #28a745;
            color: white;
        }
        
        .dashboard-stat-card.info {
            background-color: #17a2b8;
            color: white;
        }
        
        .dashboard-stat-card.warning {
            background-color: #ffc107;
            color: #212529;
        }
        
        .dashboard-stat-card.danger {
            background-color: #dc3545;
            color: white;
        }
        
        .dashboard-stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }
        
        .dashboard-stat-label {
            font-size: 1rem;
            opacity: 0.8;
        }
        
        .dashboard-stat-icon {
            font-size: 3rem;
            opacity: 0.2;
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            right: 1rem;
        }
        
        [dir="rtl"] .dashboard-stat-icon {
            right: auto;
            left: 1rem;
        }
        
        .course-card {
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 1.5rem;
            transition: all 0.3s ease;
        }
        
        .course-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
        }
        
        .course-card-header {
            padding: 1.25rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .course-card-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .course-card-subtitle {
            font-size: 0.9rem;
            opacity: 0.8;
        }
        
        .course-card-body {
            padding: 1.25rem;
        }
        
        .course-card-footer {
            padding: 1rem 1.25rem;
            background-color: rgba(0, 0, 0, 0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .theme-dark .course-card-footer {
            background-color: rgba(255, 255, 255, 0.05);
        }
        
        .course-card-stat {
            display: flex;
            align-items: center;
        }
        
        .course-card-stat i {
            margin-right: 0.5rem;
            opacity: 0.7;
        }
        
        [dir="rtl"] .course-card-stat i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .task-item {
            padding: 1rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: flex-start;
        }
        
        .theme-dark .task-item {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .task-item:last-child {
            border-bottom: none;
        }
        
        .task-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        
        [dir="rtl"] .task-icon {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .task-icon.assignment {
            background-color: rgba(255, 193, 7, 0.2);
            color: #ffc107;
        }
        
        .task-icon.exam {
            background-color: rgba(220, 53, 69, 0.2);
            color: #dc3545;
        }
        
        .task-icon.meeting {
            background-color: rgba(13, 110, 253, 0.2);
            color: #0d6efd;
        }
        
        .task-icon.deadline {
            background-color: rgba(40, 167, 69, 0.2);
            color: #28a745;
        }
        
        .task-content {
            flex-grow: 1;
        }
        
        .task-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .task-course {
            font-size: 0.85rem;
            color: var(--gray-color);
            margin-bottom: 0.25rem;
        }
        
        .task-date {
            font-size: 0.85rem;
            color: var(--gray-color);
            display: flex;
            align-items: center;
        }
        
        .task-date i {
            margin-right: 0.5rem;
            font-size: 0.8rem;
        }
        
        [dir="rtl"] .task-date i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .notification-item {
            padding: 1rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: flex-start;
        }
        
        .theme-dark .notification-item {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .notification-item:last-child {
            border-bottom: none;
        }
        
        .notification-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        
        [dir="rtl"] .notification-icon {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .notification-icon.message {
            background-color: rgba(13, 110, 253, 0.2);
            color: #0d6efd;
        }
        
        .notification-icon.assignment {
            background-color: rgba(255, 193, 7, 0.2);
            color: #ffc107;
        }
        
        .notification-icon.grade {
            background-color: rgba(40, 167, 69, 0.2);
            color: #28a745;
        }
        
        .notification-icon.announcement {
            background-color: rgba(108, 117, 125, 0.2);
            color: #6c757d;
        }
        
        .notification-icon.warning {
            background-color: rgba(220, 53, 69, 0.2);
            color: #dc3545;
        }
        
        .notification-content {
            flex-grow: 1;
        }
        
        .notification-text {
            margin-bottom: 0.25rem;
        }
        
        .notification-time {
            font-size: 0.85rem;
            color: var(--gray-color);
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link active" href="teacher_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_students.php">
                        <i class="fas fa-user-graduate"></i> <?php echo t('students'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="teacher_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="teacher_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="teacher_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-user-graduate"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">قام الطالب أحمد محمد بتسليم واجب جديد</p>
                                    <small class="text-muted">منذ 10 دقائق</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-calendar-alt"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تذكير: موعد محاضرة برمجة الويب غداً</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-info text-white rounded-circle">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">رسالة جديدة من رئيس القسم</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="teacher_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/student1.jpg" alt="Student" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">سارة أحمد</p>
                                    <small class="text-muted">هل يمكنني الحصول على مساعدة في المشروع النهائي؟</small>
                                    <small class="text-muted d-block">منذ 15 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/student2.jpg" alt="Student" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">محمد علي</p>
                                    <small class="text-muted">أستاذ، هل يمكنني تأجيل موعد تسليم الواجب؟</small>
                                    <small class="text-muted d-block">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="teacher_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $teacher['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $teacher['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $teacher['name']; ?></h6>
                            <small><?php echo $teacher['title']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="teacher_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="teacher_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <div>
                <h1 class="h3"><?php echo t('welcome_back'); ?>, <?php echo $teacher['name']; ?></h1>
                <p class="text-muted"><?php echo t('teacher_dashboard_subtitle'); ?></p>
            </div>
            <div>
                <button class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i> <?php echo t('create_new_course'); ?>
                </button>
            </div>
        </div>
        
        <!-- الإحصائيات -->
        <div class="row mb-4">
            <div class="col-md-3 mb-4">
                <div class="dashboard-stat-card primary position-relative">
                    <div class="dashboard-stat-value"><?php echo $stats['courses_count']; ?></div>
                    <div class="dashboard-stat-label"><?php echo t('active_courses'); ?></div>
                    <i class="fas fa-book-open dashboard-stat-icon"></i>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="dashboard-stat-card secondary position-relative">
                    <div class="dashboard-stat-value"><?php echo $stats['students_count']; ?></div>
                    <div class="dashboard-stat-label"><?php echo t('total_students'); ?></div>
                    <i class="fas fa-user-graduate dashboard-stat-icon"></i>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="dashboard-stat-card success position-relative">
                    <div class="dashboard-stat-value"><?php echo $stats['assignments_count']; ?></div>
                    <div class="dashboard-stat-label"><?php echo t('active_assignments'); ?></div>
                    <i class="fas fa-tasks dashboard-stat-icon"></i>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="dashboard-stat-card info position-relative">
                    <div class="dashboard-stat-value"><?php echo $stats['messages_count']; ?></div>
                    <div class="dashboard-stat-label"><?php echo t('unread_messages'); ?></div>
                    <i class="fas fa-envelope dashboard-stat-icon"></i>
                </div>
            </div>
        </div>
        
        <div class="row">
            <!-- المقررات النشطة -->
            <div class="col-lg-8 mb-4">
                <div class="dashboard-card">
                    <div class="dashboard-card-header">
                        <h5 class="dashboard-card-title"><?php echo t('active_courses'); ?></h5>
                        <a href="teacher_courses.php" class="btn btn-sm btn-outline-primary"><?php echo t('view_all'); ?></a>
                    </div>
                    <div class="dashboard-card-body">
                        <div class="row">
                            <?php if (count($courses) > 0): ?>
                                <?php foreach ($courses as $course): ?>
                                    <div class="col-md-6">
                                        <div class="course-card">
                                            <div class="course-card-header">
                                                <h5 class="course-card-title"><?php echo $course['name']; ?></h5>
                                                <div class="course-card-subtitle"><?php echo $course['code']; ?> - <?php echo $course['semester']; ?></div>
                                            </div>
                                            <div class="course-card-body">
                                                <p><?php echo substr($course['description'], 0, 100); ?>...</p>
                                                <div class="progress mb-3" style="height: 5px;">
                                                    <div class="progress-bar bg-primary" role="progressbar" style="width: <?php echo $course['progress']; ?>%;" aria-valuenow="<?php echo $course['progress']; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <small class="text-muted"><?php echo t('progress'); ?>: <?php echo $course['progress']; ?>%</small>
                                                    <small class="text-muted"><?php echo $course['weeks_completed']; ?>/<?php echo $course['total_weeks']; ?> <?php echo t('weeks'); ?></small>
                                                </div>
                                            </div>
                                            <div class="course-card-footer">
                                                <div class="course-card-stat">
                                                    <i class="fas fa-user-graduate"></i> <?php echo $course['students_count']; ?> <?php echo t('students'); ?>
                                                </div>
                                                <a href="teacher_course_details.php?id=<?php echo $course['id']; ?>" class="btn btn-sm btn-primary"><?php echo t('manage'); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="col-12">
                                    <div class="alert alert-info">
                                        <?php echo t('no_active_courses'); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- المهام القادمة -->
            <div class="col-lg-4 mb-4">
                <div class="dashboard-card">
                    <div class="dashboard-card-header">
                        <h5 class="dashboard-card-title"><?php echo t('upcoming_tasks'); ?></h5>
                        <a href="teacher_schedule.php" class="btn btn-sm btn-outline-primary"><?php echo t('view_all'); ?></a>
                    </div>
                    <div class="dashboard-card-body p-0">
                        <?php if (count($upcoming_tasks) > 0): ?>
                            <?php foreach ($upcoming_tasks as $task): ?>
                                <div class="task-item">
                                    <div class="task-icon <?php echo $task['type']; ?>">
                                        <?php if ($task['type'] === 'assignment'): ?>
                                            <i class="fas fa-tasks"></i>
                                        <?php elseif ($task['type'] === 'exam'): ?>
                                            <i class="fas fa-file-alt"></i>
                                        <?php elseif ($task['type'] === 'meeting'): ?>
                                            <i class="fas fa-users"></i>
                                        <?php elseif ($task['type'] === 'deadline'): ?>
                                            <i class="fas fa-clock"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="task-content">
                                        <h6 class="task-title"><?php echo $task['title']; ?></h6>
                                        <div class="task-course"><?php echo $task['course_name']; ?></div>
                                        <div class="task-date">
                                            <i class="fas fa-calendar-alt"></i> <?php echo $task['date']; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="p-3">
                                <div class="alert alert-info mb-0">
                                    <?php echo t('no_upcoming_tasks'); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- الرسم البياني للنشاط -->
            <div class="col-lg-8 mb-4">
                <div class="dashboard-card">
                    <div class="dashboard-card-header">
                        <h5 class="dashboard-card-title"><?php echo t('student_activity'); ?></h5>
                        <div class="btn-group">
                            <button type="button" class="btn btn-sm btn-outline-primary active" data-period="week"><?php echo t('week'); ?></button>
                            <button type="button" class="btn btn-sm btn-outline-primary" data-period="month"><?php echo t('month'); ?></button>
                            <button type="button" class="btn btn-sm btn-outline-primary" data-period="semester"><?php echo t('semester'); ?></button>
                        </div>
                    </div>
                    <div class="dashboard-card-body">
                        <canvas id="activityChart" height="300"></canvas>
                    </div>
                </div>
            </div>
            
            <!-- آخر الإشعارات -->
            <div class="col-lg-4 mb-4">
                <div class="dashboard-card">
                    <div class="dashboard-card-header">
                        <h5 class="dashboard-card-title"><?php echo t('recent_notifications'); ?></h5>
                        <a href="teacher_notifications.php" class="btn btn-sm btn-outline-primary"><?php echo t('view_all'); ?></a>
                    </div>
                    <div class="dashboard-card-body p-0">
                        <?php if (count($notifications) > 0): ?>
                            <?php foreach ($notifications as $notification): ?>
                                <div class="notification-item">
                                    <div class="notification-icon <?php echo $notification['type']; ?>">
                                        <?php if ($notification['type'] === 'message'): ?>
                                            <i class="fas fa-envelope"></i>
                                        <?php elseif ($notification['type'] === 'assignment'): ?>
                                            <i class="fas fa-tasks"></i>
                                        <?php elseif ($notification['type'] === 'grade'): ?>
                                            <i class="fas fa-chart-line"></i>
                                        <?php elseif ($notification['type'] === 'announcement'): ?>
                                            <i class="fas fa-bullhorn"></i>
                                        <?php elseif ($notification['type'] === 'warning'): ?>
                                            <i class="fas fa-exclamation-triangle"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="notification-content">
                                        <div class="notification-text"><?php echo $notification['text']; ?></div>
                                        <div class="notification-time"><?php echo $notification['time']; ?></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="p-3">
                                <div class="alert alert-info mb-0">
                                    <?php echo t('no_notifications'); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // زر تبديل المظهر
            document.getElementById('themeToggle').addEventListener('click', function() {
                const currentTheme = document.body.className.includes('theme-dark') ? 'dark' : 'light';
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                
                document.cookie = `theme=${newTheme}; path=/; max-age=31536000`;
                document.body.className = `theme-${newTheme}`;
                
                this.innerHTML = `<i class="fas fa-${newTheme === 'dark' ? 'sun' : 'moon'}"></i>`;
            });
            
            // رسم بياني للنشاط
            const ctx = document.getElementById('activityChart').getContext('2d');
            const activityChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
                    datasets: [
                        {
                            label: 'تسليم الواجبات',
                            data: [12, 19, 8, 15, 20, 14, 10],
                            backgroundColor: 'rgba(0, 48, 73, 0.1)',
                            borderColor: 'rgba(0, 48, 73, 1)',
                            borderWidth: 2,
                            tension: 0.4,
                            fill: true
                        },
                        {
                            label: 'المشاركة في المنتدى',
                            data: [7, 11, 5, 8, 12, 9, 6],
                            backgroundColor: 'rgba(102, 155, 188, 0.1)',
                            borderColor: 'rgba(102, 155, 188, 1)',
                            borderWidth: 2,
                            tension: 0.4,
                            fill: true
                        },
                        {
                            label: 'مشاهدة المحتوى',
                            data: [25, 32, 18, 29, 35, 27, 22],
                            backgroundColor: 'rgba(255, 193, 7, 0.1)',
                            borderColor: 'rgba(255, 193, 7, 1)',
                            borderWidth: 2,
                            tension: 0.4,
                            fill: true
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
            
            // تبديل فترة الرسم البياني
            document.querySelectorAll('[data-period]').forEach(button => {
                button.addEventListener('click', function() {
                    // إزالة الفئة النشطة من جميع الأزرار
                    document.querySelectorAll('[data-period]').forEach(btn => {
                        btn.classList.remove('active');
                    });
                    
                    // إضافة الفئة النشطة إلى الزر المحدد
                    this.classList.add('active');
                    
                    // تحديث البيانات بناءً على الفترة المحددة
                    const period = this.getAttribute('data-period');
                    
                    if (period === 'week') {
                        activityChart.data.labels = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
                        activityChart.data.datasets[0].data = [12, 19, 8, 15, 20, 14, 10];
                        activityChart.data.datasets[1].data = [7, 11, 5, 8, 12, 9, 6];
                        activityChart.data.datasets[2].data = [25, 32, 18, 29, 35, 27, 22];
                    } else if (period === 'month') {
                        activityChart.data.labels = ['الأسبوع 1', 'الأسبوع 2', 'الأسبوع 3', 'الأسبوع 4'];
                        activityChart.data.datasets[0].data = [45, 65, 55, 70];
                        activityChart.data.datasets[1].data = [30, 40, 35, 45];
                        activityChart.data.datasets[2].data = [90, 110, 100, 120];
                    } else if (period === 'semester') {
                        activityChart.data.labels = ['سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر', 'يناير'];
                        activityChart.data.datasets[0].data = [150, 200, 180, 220, 190];
                        activityChart.data.datasets[1].data = [100, 130, 120, 140, 110];
                        activityChart.data.datasets[2].data = [300, 350, 320, 380, 340];
                    }
                    
                    activityChart.update();
                });
            });
        });
    </script>
</body>
</html>
