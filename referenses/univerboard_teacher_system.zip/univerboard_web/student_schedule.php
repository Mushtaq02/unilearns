<?php
/**
 * صفحة الجدول الدراسي للطالب في نظام UniverBoard
 * تعرض جدول المحاضرات والمواعيد الأسبوعية
 */

// استيراد ملفات الإعدادات والدوال
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// التحقق من تسجيل دخول الطالب
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'student') {
    // إعادة توجيه المستخدم إلى صفحة تسجيل الدخول إذا لم يكن مسجل الدخول
    header('Location: login.php');
    exit;
}

// الحصول على معلومات الطالب
$student_id = $_SESSION['user_id'];
$db = get_db_connection();
$student = get_student_info($db, $student_id);

// تعيين اللغة الافتراضية
$lang = isset($_COOKIE['lang']) ? $_COOKIE['lang'] : SITE_LANG;

// تعيين المظهر الافتراضي
$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : SITE_THEME;

// تحميل ملفات اللغة
$translations = [];
if ($lang === 'ar') {
    include 'includes/lang/ar.php';
} else {
    include 'includes/lang/en.php';
}

// دالة ترجمة النصوص
function t($key) {
    global $translations;
    return isset($translations[$key]) ? $translations[$key] : $key;
}

// الحصول على الجدول الدراسي للطالب
$schedule = get_student_schedule($db, $student_id);

// الحصول على الفصل الدراسي الحالي
$current_semester = get_current_semester($db);

// الحصول على المواعيد المهمة
$important_dates = get_important_dates($db, $current_semester['id']);

// إغلاق اتصال قاعدة البيانات
$db->close();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $lang === 'ar' ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - <?php echo t('schedule'); ?></title>
    
    <!-- Bootstrap RTL إذا كانت اللغة العربية -->
    <?php if ($lang === 'ar'): ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <?php else: ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <?php endif; ?>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- خط Cairo -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&display=swap">
    
    <!-- ملف CSS الرئيسي -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- ملف CSS للمظهر -->
    <link rel="stylesheet" href="assets/css/theme-<?php echo $theme; ?>.css">
    
    <style>
        .schedule-container {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .theme-dark .schedule-container {
            background-color: #212529;
        }
        
        .schedule-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .schedule-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .schedule-title {
            margin-bottom: 0.5rem;
        }
        
        .schedule-subtitle {
            color: var(--gray-color);
        }
        
        .schedule-body {
            padding: 1.5rem;
        }
        
        .schedule-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }
        
        .schedule-table th,
        .schedule-table td {
            padding: 1rem;
            text-align: center;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .schedule-table th,
        .theme-dark .schedule-table td {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .schedule-table th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
        }
        
        .schedule-table th:first-child {
            border-top-right-radius: 0.5rem;
            border-top-left-radius: 0.5rem;
        }
        
        .schedule-table th:last-child {
            border-top-right-radius: 0.5rem;
            border-top-left-radius: 0.5rem;
        }
        
        .schedule-table td:first-child {
            font-weight: 600;
            background-color: rgba(0, 48, 73, 0.1);
        }
        
        .theme-dark .schedule-table td:first-child {
            background-color: rgba(102, 155, 188, 0.1);
        }
        
        .schedule-item {
            padding: 0.5rem;
            border-radius: 0.25rem;
            margin-bottom: 0.5rem;
            position: relative;
        }
        
        .schedule-item:last-child {
            margin-bottom: 0;
        }
        
        .schedule-item.lecture {
            background-color: rgba(0, 48, 73, 0.1);
        }
        
        .theme-dark .schedule-item.lecture {
            background-color: rgba(102, 155, 188, 0.1);
        }
        
        .schedule-item.lab {
            background-color: rgba(102, 155, 188, 0.1);
        }
        
        .theme-dark .schedule-item.lab {
            background-color: rgba(0, 48, 73, 0.1);
        }
        
        .schedule-item.exam {
            background-color: rgba(220, 53, 69, 0.1);
        }
        
        .schedule-item.tutorial {
            background-color: rgba(40, 167, 69, 0.1);
        }
        
        .schedule-item-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .schedule-item-time {
            font-size: 0.8rem;
            color: var(--gray-color);
            margin-bottom: 0.25rem;
        }
        
        .schedule-item-location {
            font-size: 0.8rem;
            color: var(--gray-color);
        }
        
        .schedule-item-instructor {
            font-size: 0.8rem;
            color: var(--gray-color);
        }
        
        .schedule-item-badge {
            position: absolute;
            top: 0.25rem;
            right: 0.25rem;
            font-size: 0.7rem;
            padding: 0.1rem 0.5rem;
            border-radius: 1rem;
        }
        
        [dir="rtl"] .schedule-item-badge {
            right: auto;
            left: 0.25rem;
        }
        
        .schedule-item-badge.lecture {
            background-color: var(--primary-color);
            color: white;
        }
        
        .schedule-item-badge.lab {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .schedule-item-badge.exam {
            background-color: #dc3545;
            color: white;
        }
        
        .schedule-item-badge.tutorial {
            background-color: #28a745;
            color: white;
        }
        
        .schedule-filter {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }
        
        .schedule-filter .btn {
            border-radius: 2rem;
            padding: 0.5rem 1.5rem;
        }
        
        .schedule-filter .btn.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .schedule-actions {
            display: flex;
            justify-content: space-between;
            margin-bottom: 1.5rem;
        }
        
        .schedule-view-toggle {
            display: flex;
            gap: 0.5rem;
        }
        
        .schedule-view-toggle .btn {
            border-radius: 0.25rem;
            padding: 0.5rem 1rem;
        }
        
        .schedule-view-toggle .btn.active {
            background-color: var(--primary-color);
            color: white;
        }
        
        .schedule-export {
            display: flex;
            gap: 0.5rem;
        }
        
        .schedule-export .btn {
            border-radius: 0.25rem;
            padding: 0.5rem 1rem;
        }
        
        .important-dates-container {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .theme-dark .important-dates-container {
            background-color: #212529;
        }
        
        .important-dates-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .important-dates-header {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .important-dates-title {
            margin-bottom: 0.5rem;
        }
        
        .important-dates-subtitle {
            color: var(--gray-color);
        }
        
        .important-dates-body {
            padding: 1.5rem;
        }
        
        .important-date-item {
            display: flex;
            align-items: flex-start;
            padding: 1rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .theme-dark .important-date-item {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .important-date-item:last-child {
            border-bottom: none;
        }
        
        .important-date-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            flex-shrink: 0;
        }
        
        [dir="rtl"] .important-date-icon {
            margin-right: 0;
            margin-left: 1rem;
        }
        
        .important-date-content {
            flex: 1;
        }
        
        .important-date-title {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .important-date-date {
            font-size: 0.9rem;
            color: var(--gray-color);
            margin-bottom: 0.5rem;
        }
        
        .important-date-description {
            color: var(--text-color);
        }
        
        .important-date-badge {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.8rem;
            margin-left: 0.5rem;
        }
        
        [dir="rtl"] .important-date-badge {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .important-date-badge.upcoming {
            background-color: #ffc107;
            color: #212529;
        }
        
        .important-date-badge.today {
            background-color: #28a745;
            color: white;
        }
        
        .important-date-badge.past {
            background-color: #6c757d;
            color: white;
        }
        
        .calendar-view {
            display: none;
        }
        
        .calendar-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .calendar-title {
            font-size: 1.5rem;
            font-weight: 600;
        }
        
        .calendar-navigation {
            display: flex;
            gap: 0.5rem;
        }
        
        .calendar-navigation button {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: rgba(0, 0, 0, 0.05);
            border: none;
            color: var(--text-color);
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .theme-dark .calendar-navigation button {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .calendar-navigation button:hover {
            background-color: var(--primary-color);
            color: white;
        }
        
        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 0.5rem;
        }
        
        .calendar-day-header {
            text-align: center;
            font-weight: 600;
            padding: 0.5rem;
            background-color: var(--primary-color);
            color: white;
            border-radius: 0.25rem;
        }
        
        .calendar-day {
            min-height: 100px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 0.25rem;
            padding: 0.5rem;
            position: relative;
        }
        
        .theme-dark .calendar-day {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        .calendar-day.today {
            background-color: rgba(0, 48, 73, 0.05);
            border-color: var(--primary-color);
        }
        
        .calendar-day.other-month {
            opacity: 0.5;
        }
        
        .calendar-day-number {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .calendar-day.today .calendar-day-number {
            color: var(--primary-color);
        }
        
        .calendar-event {
            font-size: 0.8rem;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            margin-bottom: 0.25rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            cursor: pointer;
        }
        
        .calendar-event.lecture {
            background-color: rgba(0, 48, 73, 0.1);
        }
        
        .theme-dark .calendar-event.lecture {
            background-color: rgba(102, 155, 188, 0.1);
        }
        
        .calendar-event.lab {
            background-color: rgba(102, 155, 188, 0.1);
        }
        
        .theme-dark .calendar-event.lab {
            background-color: rgba(0, 48, 73, 0.1);
        }
        
        .calendar-event.exam {
            background-color: rgba(220, 53, 69, 0.1);
        }
        
        .calendar-event.tutorial {
            background-color: rgba(40, 167, 69, 0.1);
        }
        
        .calendar-event.important-date {
            background-color: rgba(255, 193, 7, 0.1);
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            z-index: 100;
            padding: 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s;
        }
        
        [dir="rtl"] .sidebar {
            left: auto;
            right: 0;
        }
        
        .sidebar-sticky {
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar .nav-link {
            font-weight: 500;
            padding: 0.75rem 1.5rem;
            color: var(--text-color);
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .sidebar .nav-link i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
        
        .sidebar .nav-link.active {
            color: var(--primary-color);
            background-color: rgba(0, 48, 73, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        [dir="rtl"] .sidebar .nav-link.active {
            border-left: none;
            border-right: 4px solid var(--primary-color);
        }
        
        .sidebar-heading {
            font-size: 0.8rem;
            text-transform: uppercase;
            padding: 1rem 1.5rem 0.5rem;
            color: var(--gray-color);
        }
        
        .sidebar-logo {
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-logo img {
            height: 40px;
        }
        
        .sidebar-logo span {
            font-size: 1.2rem;
            font-weight: 700;
            margin-left: 0.5rem;
            color: var(--primary-color);
        }
        
        [dir="rtl"] .sidebar-logo span {
            margin-left: 0;
            margin-right: 0.5rem;
        }
        
        .content {
            margin-left: 250px;
            padding: 2rem;
            transition: all 0.3s;
        }
        
        [dir="rtl"] .content {
            margin-left: 0;
            margin-right: 250px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            [dir="rtl"] .content {
                margin-left: 0;
                margin-right: 0;
            }
            
            .sidebar-sticky {
                height: auto;
            }
            
            .schedule-table {
                display: block;
                overflow-x: auto;
            }
        }
        
        .navbar-top {
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 0.5rem 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        
        .theme-dark .navbar-top {
            background-color: var(--dark-bg);
        }
        
        .navbar-top .navbar-nav {
            display: flex;
            align-items: center;
        }
        
        .navbar-top .nav-item {
            margin-left: 1rem;
        }
        
        [dir="rtl"] .navbar-top .nav-item {
            margin-left: 0;
            margin-right: 1rem;
        }
        
        .navbar-top .nav-link {
            color: var(--text-color);
            padding: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            position: relative;
        }
        
        .navbar-top .nav-link:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }
        
        .navbar-top .nav-link .badge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 0.6rem;
        }
        
        [dir="rtl"] .navbar-top .nav-link .badge {
            right: auto;
            left: 0;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .toggle-sidebar {
                display: block;
            }
        }
        
        .user-dropdown .dropdown-toggle::after {
            display: none;
        }
        
        .user-dropdown .dropdown-toggle img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .user-dropdown .dropdown-menu {
            min-width: 200px;
            padding: 0;
        }
        
        .user-dropdown .dropdown-header {
            padding: 1rem;
            background-color: var(--primary-color);
            color: white;
        }
        
        .user-dropdown .dropdown-item {
            padding: 0.75rem 1rem;
        }
        
        .user-dropdown .dropdown-item i {
            margin-right: 0.5rem;
            width: 20px;
            text-align: center;
        }
        
        [dir="rtl"] .user-dropdown .dropdown-item i {
            margin-right: 0;
            margin-left: 0.5rem;
        }
    </style>
</head>
<body class="theme-<?php echo $theme; ?>">
    <!-- القائمة الجانبية -->
    <nav class="sidebar bg-white">
        <div class="sidebar-sticky">
            <div class="sidebar-logo">
                <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>">
                <span><?php echo SITE_NAME; ?></span>
            </div>
            
            <ul class="nav flex-column mt-3">
                <li class="nav-item">
                    <a class="nav-link" href="student_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> <?php echo t('dashboard'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_courses.php">
                        <i class="fas fa-book"></i> <?php echo t('my_courses'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_assignments.php">
                        <i class="fas fa-tasks"></i> <?php echo t('assignments'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_exams.php">
                        <i class="fas fa-file-alt"></i> <?php echo t('exams'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_grades.php">
                        <i class="fas fa-chart-line"></i> <?php echo t('grades'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="student_schedule.php">
                        <i class="fas fa-calendar-alt"></i> <?php echo t('schedule'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('communication'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_messages.php">
                        <i class="fas fa-envelope"></i> <?php echo t('messages'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_notifications.php">
                        <i class="fas fa-bell"></i> <?php echo t('notifications'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_forums.php">
                        <i class="fas fa-comments"></i> <?php echo t('forums'); ?>
                    </a>
                </li>
                
                <li class="sidebar-heading"><?php echo t('account'); ?></li>
                
                <li class="nav-item">
                    <a class="nav-link" href="student_profile.php">
                        <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="student_settings.php">
                        <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">
                        <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
    
    <!-- المحتوى الرئيسي -->
    <div class="content">
        <!-- شريط التنقل العلوي -->
        <nav class="navbar-top">
            <button class="toggle-sidebar">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="notificationsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="badge bg-danger">3</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationsDropdown">
                        <div class="dropdown-header"><?php echo t('notifications'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-primary text-white rounded-circle">
                                        <i class="fas fa-book"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم إضافة محتوى جديد في مقرر برمجة الويب</p>
                                    <small class="text-muted">منذ 10 دقائق</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-warning text-white rounded-circle">
                                        <i class="fas fa-tasks"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تذكير: موعد تسليم واجب قواعد البيانات غداً</p>
                                    <small class="text-muted">منذ 30 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0 me-2">
                                    <div class="avatar avatar-sm bg-success text-white rounded-circle">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <p class="mb-0">تم تصحيح واجب البرمجة المتقدمة</p>
                                    <small class="text-muted">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_notifications.php"><?php echo t('view_all_notifications'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link" href="#" id="messagesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-envelope"></i>
                        <span class="badge bg-success">2</span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="messagesDropdown">
                        <div class="dropdown-header"><?php echo t('messages'); ?></div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user1.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">د. محمد أحمد</p>
                                    <small class="text-muted">هل لديك استفسارات حول المشروع النهائي؟</small>
                                    <small class="text-muted d-block">منذ 15 دقيقة</small>
                                </div>
                            </div>
                        </a>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex align-items-center">
                                <img src="assets/images/user2.jpg" alt="User" class="rounded-circle me-2" width="40" height="40">
                                <div>
                                    <p class="mb-1">أ. سارة خالد</p>
                                    <small class="text-muted">تم تحديد موعد المراجعة النهائية للاختبار</small>
                                    <small class="text-muted d-block">منذ ساعة</small>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center" href="student_messages.php"><?php echo t('view_all_messages'); ?></a>
                    </div>
                </li>
                
                <li class="nav-item dropdown user-dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo $student['profile_image'] ?: 'assets/images/default-user.png'; ?>" alt="<?php echo $student['name']; ?>">
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <div class="dropdown-header">
                            <h6 class="mb-0"><?php echo $student['name']; ?></h6>
                            <small><?php echo $student['student_id']; ?></small>
                        </div>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="student_profile.php">
                            <i class="fas fa-user"></i> <?php echo t('profile'); ?>
                        </a>
                        <a class="dropdown-item" href="student_settings.php">
                            <i class="fas fa-cog"></i> <?php echo t('settings'); ?>
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">
                            <i class="fas fa-sign-out-alt"></i> <?php echo t('logout'); ?>
                        </a>
                    </div>
                </li>
                
                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn btn-link nav-link dropdown-toggle" type="button" id="languageDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-globe"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        </ul>
                    </div>
                </li>
                
                <li class="nav-item">
                    <button class="btn btn-link nav-link" id="themeToggle">
                        <i class="fas <?php echo $theme === 'light' ? 'fa-moon' : 'fa-sun'; ?>"></i>
                    </button>
                </li>
            </ul>
        </nav>
        
        <!-- عنوان الصفحة -->
        <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
            <div>
                <h1 class="h3"><?php echo t('schedule'); ?></h1>
                <p class="text-muted"><?php echo t('schedule_subtitle'); ?></p>
            </div>
            <div>
                <div class="dropdown">
                    <button class="btn btn-outline-primary dropdown-toggle" type="button" id="semesterDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo $current_semester['name']; ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="semesterDropdown">
                        <li><a class="dropdown-item active" href="#"><?php echo $current_semester['name']; ?></a></li>
                        <li><a class="dropdown-item" href="#">الفصل الدراسي الأول 2024-2025</a></li>
                        <li><a class="dropdown-item" href="#">الفصل الدراسي الثاني 2023-2024</a></li>
                        <li><a class="dropdown-item" href="#">الفصل الدراسي الأول 2023-2024</a></li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- أدوات الجدول -->
        <div class="schedule-actions">
            <div class="schedule-filter">
                <button class="btn btn-outline-primary active" data-filter="all"><?php echo t('all'); ?></button>
                <button class="btn btn-outline-primary" data-filter="lecture"><?php echo t('lectures'); ?></button>
                <button class="btn btn-outline-primary" data-filter="lab"><?php echo t('labs'); ?></button>
                <button class="btn btn-outline-primary" data-filter="exam"><?php echo t('exams'); ?></button>
                <button class="btn btn-outline-primary" data-filter="tutorial"><?php echo t('tutorials'); ?></button>
            </div>
            <div class="d-flex gap-2">
                <div class="schedule-view-toggle">
                    <button class="btn btn-outline-secondary active" id="weeklyViewBtn">
                        <i class="fas fa-calendar-week me-1"></i> <?php echo t('weekly_view'); ?>
                    </button>
                    <button class="btn btn-outline-secondary" id="monthlyViewBtn">
                        <i class="fas fa-calendar-alt me-1"></i> <?php echo t('monthly_view'); ?>
                    </button>
                </div>
                <div class="schedule-export">
                    <button class="btn btn-outline-secondary" id="exportCalendar">
                        <i class="fas fa-download me-1"></i> <?php echo t('export'); ?>
                    </button>
                    <button class="btn btn-outline-secondary" id="printSchedule">
                        <i class="fas fa-print me-1"></i> <?php echo t('print'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- عرض الجدول الأسبوعي -->
        <div class="schedule-container" id="weeklyView">
            <div class="schedule-header">
                <h2 class="schedule-title"><?php echo t('weekly_schedule'); ?></h2>
                <p class="schedule-subtitle"><?php echo $current_semester['name']; ?></p>
            </div>
            <div class="schedule-body">
                <table class="schedule-table">
                    <thead>
                        <tr>
                            <th><?php echo t('time'); ?></th>
                            <th><?php echo t('sunday'); ?></th>
                            <th><?php echo t('monday'); ?></th>
                            <th><?php echo t('tuesday'); ?></th>
                            <th><?php echo t('wednesday'); ?></th>
                            <th><?php echo t('thursday'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>8:00 - 9:00</td>
                            <td>
                                <div class="schedule-item lecture" data-type="lecture">
                                    <div class="schedule-item-title">برمجة الويب</div>
                                    <div class="schedule-item-time">8:00 - 9:30</div>
                                    <div class="schedule-item-location">قاعة 305</div>
                                    <div class="schedule-item-instructor">د. محمد أحمد</div>
                                    <span class="schedule-item-badge lecture"><?php echo t('lecture'); ?></span>
                                </div>
                            </td>
                            <td></td>
                            <td>
                                <div class="schedule-item lecture" data-type="lecture">
                                    <div class="schedule-item-title">قواعد البيانات</div>
                                    <div class="schedule-item-time">8:00 - 9:30</div>
                                    <div class="schedule-item-location">قاعة 201</div>
                                    <div class="schedule-item-instructor">د. سارة خالد</div>
                                    <span class="schedule-item-badge lecture"><?php echo t('lecture'); ?></span>
                                </div>
                            </td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>9:00 - 10:00</td>
                            <td>
                                <div class="schedule-item lecture" data-type="lecture">
                                    <div class="schedule-item-title">برمجة الويب</div>
                                    <div class="schedule-item-time">8:00 - 9:30</div>
                                    <div class="schedule-item-location">قاعة 305</div>
                                    <div class="schedule-item-instructor">د. محمد أحمد</div>
                                    <span class="schedule-item-badge lecture"><?php echo t('lecture'); ?></span>
                                </div>
                            </td>
                            <td></td>
                            <td>
                                <div class="schedule-item lecture" data-type="lecture">
                                    <div class="schedule-item-title">قواعد البيانات</div>
                                    <div class="schedule-item-time">8:00 - 9:30</div>
                                    <div class="schedule-item-location">قاعة 201</div>
                                    <div class="schedule-item-instructor">د. سارة خالد</div>
                                    <span class="schedule-item-badge lecture"><?php echo t('lecture'); ?></span>
                                </div>
                            </td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>10:00 - 11:00</td>
                            <td></td>
                            <td>
                                <div class="schedule-item lab" data-type="lab">
                                    <div class="schedule-item-title">معمل برمجة الويب</div>
                                    <div class="schedule-item-time">10:00 - 12:00</div>
                                    <div class="schedule-item-location">معمل 102</div>
                                    <div class="schedule-item-instructor">م. أحمد محمود</div>
                                    <span class="schedule-item-badge lab"><?php echo t('lab'); ?></span>
                                </div>
                            </td>
                            <td></td>
                            <td>
                                <div class="schedule-item tutorial" data-type="tutorial">
                                    <div class="schedule-item-title">تمارين قواعد البيانات</div>
                                    <div class="schedule-item-time">10:00 - 11:30</div>
                                    <div class="schedule-item-location">قاعة 105</div>
                                    <div class="schedule-item-instructor">م. فاطمة علي</div>
                                    <span class="schedule-item-badge tutorial"><?php echo t('tutorial'); ?></span>
                                </div>
                            </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>11:00 - 12:00</td>
                            <td></td>
                            <td>
                                <div class="schedule-item lab" data-type="lab">
                                    <div class="schedule-item-title">معمل برمجة الويب</div>
                                    <div class="schedule-item-time">10:00 - 12:00</div>
                                    <div class="schedule-item-location">معمل 102</div>
                                    <div class="schedule-item-instructor">م. أحمد محمود</div>
                                    <span class="schedule-item-badge lab"><?php echo t('lab'); ?></span>
                                </div>
                            </td>
                            <td></td>
                            <td>
                                <div class="schedule-item tutorial" data-type="tutorial">
                                    <div class="schedule-item-title">تمارين قواعد البيانات</div>
                                    <div class="schedule-item-time">10:00 - 11:30</div>
                                    <div class="schedule-item-location">قاعة 105</div>
                                    <div class="schedule-item-instructor">م. فاطمة علي</div>
                                    <span class="schedule-item-badge tutorial"><?php echo t('tutorial'); ?></span>
                                </div>
                            </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>12:00 - 13:00</td>
                            <td></td>
                            <td></td>
                            <td>
                                <div class="schedule-item lecture" data-type="lecture">
                                    <div class="schedule-item-title">هندسة البرمجيات</div>
                                    <div class="schedule-item-time">12:00 - 13:30</div>
                                    <div class="schedule-item-location">قاعة 401</div>
                                    <div class="schedule-item-instructor">د. خالد محمود</div>
                                    <span class="schedule-item-badge lecture"><?php echo t('lecture'); ?></span>
                                </div>
                            </td>
                            <td></td>
                            <td>
                                <div class="schedule-item exam" data-type="exam">
                                    <div class="schedule-item-title">اختبار نصفي - برمجة الويب</div>
                                    <div class="schedule-item-time">12:00 - 14:00</div>
                                    <div class="schedule-item-location">قاعة 305</div>
                                    <div class="schedule-item-instructor">د. محمد أحمد</div>
                                    <span class="schedule-item-badge exam"><?php echo t('exam'); ?></span>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>13:00 - 14:00</td>
                            <td></td>
                            <td></td>
                            <td>
                                <div class="schedule-item lecture" data-type="lecture">
                                    <div class="schedule-item-title">هندسة البرمجيات</div>
                                    <div class="schedule-item-time">12:00 - 13:30</div>
                                    <div class="schedule-item-location">قاعة 401</div>
                                    <div class="schedule-item-instructor">د. خالد محمود</div>
                                    <span class="schedule-item-badge lecture"><?php echo t('lecture'); ?></span>
                                </div>
                            </td>
                            <td></td>
                            <td>
                                <div class="schedule-item exam" data-type="exam">
                                    <div class="schedule-item-title">اختبار نصفي - برمجة الويب</div>
                                    <div class="schedule-item-time">12:00 - 14:00</div>
                                    <div class="schedule-item-location">قاعة 305</div>
                                    <div class="schedule-item-instructor">د. محمد أحمد</div>
                                    <span class="schedule-item-badge exam"><?php echo t('exam'); ?></span>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>14:00 - 15:00</td>
                            <td>
                                <div class="schedule-item lecture" data-type="lecture">
                                    <div class="schedule-item-title">أمن المعلومات</div>
                                    <div class="schedule-item-time">14:00 - 15:30</div>
                                    <div class="schedule-item-location">قاعة 205</div>
                                    <div class="schedule-item-instructor">د. عمر سعيد</div>
                                    <span class="schedule-item-badge lecture"><?php echo t('lecture'); ?></span>
                                </div>
                            </td>
                            <td></td>
                            <td></td>
                            <td>
                                <div class="schedule-item lab" data-type="lab">
                                    <div class="schedule-item-title">معمل هندسة البرمجيات</div>
                                    <div class="schedule-item-time">14:00 - 16:00</div>
                                    <div class="schedule-item-location">معمل 103</div>
                                    <div class="schedule-item-instructor">م. نورا أحمد</div>
                                    <span class="schedule-item-badge lab"><?php echo t('lab'); ?></span>
                                </div>
                            </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>15:00 - 16:00</td>
                            <td>
                                <div class="schedule-item lecture" data-type="lecture">
                                    <div class="schedule-item-title">أمن المعلومات</div>
                                    <div class="schedule-item-time">14:00 - 15:30</div>
                                    <div class="schedule-item-location">قاعة 205</div>
                                    <div class="schedule-item-instructor">د. عمر سعيد</div>
                                    <span class="schedule-item-badge lecture"><?php echo t('lecture'); ?></span>
                                </div>
                            </td>
                            <td></td>
                            <td></td>
                            <td>
                                <div class="schedule-item lab" data-type="lab">
                                    <div class="schedule-item-title">معمل هندسة البرمجيات</div>
                                    <div class="schedule-item-time">14:00 - 16:00</div>
                                    <div class="schedule-item-location">معمل 103</div>
                                    <div class="schedule-item-instructor">م. نورا أحمد</div>
                                    <span class="schedule-item-badge lab"><?php echo t('lab'); ?></span>
                                </div>
                            </td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- عرض التقويم الشهري -->
        <div class="schedule-container calendar-view" id="monthlyView">
            <div class="schedule-header">
                <div class="calendar-header">
                    <div class="calendar-title">مايو 2025</div>
                    <div class="calendar-navigation">
                        <button id="prevMonth"><i class="fas fa-chevron-left"></i></button>
                        <button id="nextMonth"><i class="fas fa-chevron-right"></i></button>
                    </div>
                </div>
            </div>
            <div class="schedule-body">
                <div class="calendar-grid">
                    <div class="calendar-day-header"><?php echo t('sunday'); ?></div>
                    <div class="calendar-day-header"><?php echo t('monday'); ?></div>
                    <div class="calendar-day-header"><?php echo t('tuesday'); ?></div>
                    <div class="calendar-day-header"><?php echo t('wednesday'); ?></div>
                    <div class="calendar-day-header"><?php echo t('thursday'); ?></div>
                    <div class="calendar-day-header"><?php echo t('friday'); ?></div>
                    <div class="calendar-day-header"><?php echo t('saturday'); ?></div>
                    
                    <!-- الأسبوع الأول -->
                    <div class="calendar-day other-month">
                        <div class="calendar-day-number">27</div>
                    </div>
                    <div class="calendar-day other-month">
                        <div class="calendar-day-number">28</div>
                    </div>
                    <div class="calendar-day other-month">
                        <div class="calendar-day-number">29</div>
                    </div>
                    <div class="calendar-day other-month">
                        <div class="calendar-day-number">30</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">1</div>
                        <div class="calendar-event lecture">برمجة الويب</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">2</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">3</div>
                    </div>
                    
                    <!-- الأسبوع الثاني -->
                    <div class="calendar-day">
                        <div class="calendar-day-number">4</div>
                        <div class="calendar-event lecture">برمجة الويب</div>
                        <div class="calendar-event lecture">أمن المعلومات</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">5</div>
                        <div class="calendar-event lab">معمل برمجة الويب</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">6</div>
                        <div class="calendar-event lecture">قواعد البيانات</div>
                        <div class="calendar-event lecture">هندسة البرمجيات</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">7</div>
                        <div class="calendar-event tutorial">تمارين قواعد البيانات</div>
                        <div class="calendar-event lab">معمل هندسة البرمجيات</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">8</div>
                        <div class="calendar-event exam">اختبار نصفي - برمجة الويب</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">9</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">10</div>
                    </div>
                    
                    <!-- الأسبوع الثالث -->
                    <div class="calendar-day">
                        <div class="calendar-day-number">11</div>
                        <div class="calendar-event lecture">برمجة الويب</div>
                        <div class="calendar-event lecture">أمن المعلومات</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">12</div>
                        <div class="calendar-event lab">معمل برمجة الويب</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">13</div>
                        <div class="calendar-event lecture">قواعد البيانات</div>
                        <div class="calendar-event lecture">هندسة البرمجيات</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">14</div>
                        <div class="calendar-event tutorial">تمارين قواعد البيانات</div>
                        <div class="calendar-event lab">معمل هندسة البرمجيات</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">15</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">16</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">17</div>
                    </div>
                    
                    <!-- الأسبوع الرابع -->
                    <div class="calendar-day">
                        <div class="calendar-day-number">18</div>
                        <div class="calendar-event lecture">برمجة الويب</div>
                        <div class="calendar-event lecture">أمن المعلومات</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">19</div>
                        <div class="calendar-event lab">معمل برمجة الويب</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">20</div>
                        <div class="calendar-event lecture">قواعد البيانات</div>
                        <div class="calendar-event lecture">هندسة البرمجيات</div>
                    </div>
                    <div class="calendar-day today">
                        <div class="calendar-day-number">21</div>
                        <div class="calendar-event tutorial">تمارين قواعد البيانات</div>
                        <div class="calendar-event lab">معمل هندسة البرمجيات</div>
                        <div class="calendar-event important-date">موعد تسليم مشروع</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">22</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">23</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">24</div>
                    </div>
                    
                    <!-- الأسبوع الخامس -->
                    <div class="calendar-day">
                        <div class="calendar-day-number">25</div>
                        <div class="calendar-event lecture">برمجة الويب</div>
                        <div class="calendar-event lecture">أمن المعلومات</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">26</div>
                        <div class="calendar-event lab">معمل برمجة الويب</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">27</div>
                        <div class="calendar-event lecture">قواعد البيانات</div>
                        <div class="calendar-event lecture">هندسة البرمجيات</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">28</div>
                        <div class="calendar-event tutorial">تمارين قواعد البيانات</div>
                        <div class="calendar-event lab">معمل هندسة البرمجيات</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">29</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">30</div>
                    </div>
                    <div class="calendar-day">
                        <div class="calendar-day-number">31</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- المواعيد المهمة -->
        <div class="important-dates-container">
            <div class="important-dates-header">
                <h2 class="important-dates-title"><?php echo t('important_dates'); ?></h2>
                <p class="important-dates-subtitle"><?php echo $current_semester['name']; ?></p>
            </div>
            <div class="important-dates-body">
                <div class="important-date-item">
                    <div class="important-date-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div class="important-date-content">
                        <h5 class="important-date-title">
                            موعد تسليم مشروع برمجة الويب
                            <span class="important-date-badge today"><?php echo t('today'); ?></span>
                        </h5>
                        <div class="important-date-date">21 مايو 2025</div>
                        <p class="important-date-description">
                            يجب تسليم المشروع النهائي لمقرر برمجة الويب قبل الساعة 11:59 مساءً.
                        </p>
                    </div>
                </div>
                <div class="important-date-item">
                    <div class="important-date-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="important-date-content">
                        <h5 class="important-date-title">
                            الاختبار النهائي - قواعد البيانات
                            <span class="important-date-badge upcoming"><?php echo t('upcoming'); ?></span>
                        </h5>
                        <div class="important-date-date">5 يونيو 2025</div>
                        <p class="important-date-description">
                            سيعقد الاختبار النهائي لمقرر قواعد البيانات في قاعة 201 من الساعة 9:00 صباحاً حتى 11:00 صباحاً.
                        </p>
                    </div>
                </div>
                <div class="important-date-item">
                    <div class="important-date-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="important-date-content">
                        <h5 class="important-date-title">
                            الاختبار النهائي - برمجة الويب
                            <span class="important-date-badge upcoming"><?php echo t('upcoming'); ?></span>
                        </h5>
                        <div class="important-date-date">8 يونيو 2025</div>
                        <p class="important-date-description">
                            سيعقد الاختبار النهائي لمقرر برمجة الويب في قاعة 305 من الساعة 9:00 صباحاً حتى 11:00 صباحاً.
                        </p>
                    </div>
                </div>
                <div class="important-date-item">
                    <div class="important-date-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="important-date-content">
                        <h5 class="important-date-title">
                            الاختبار النهائي - هندسة البرمجيات
                            <span class="important-date-badge upcoming"><?php echo t('upcoming'); ?></span>
                        </h5>
                        <div class="important-date-date">12 يونيو 2025</div>
                        <p class="important-date-description">
                            سيعقد الاختبار النهائي لمقرر هندسة البرمجيات في قاعة 401 من الساعة 9:00 صباحاً حتى 11:00 صباحاً.
                        </p>
                    </div>
                </div>
                <div class="important-date-item">
                    <div class="important-date-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="important-date-content">
                        <h5 class="important-date-title">
                            الاختبار النهائي - أمن المعلومات
                            <span class="important-date-badge upcoming"><?php echo t('upcoming'); ?></span>
                        </h5>
                        <div class="important-date-date">15 يونيو 2025</div>
                        <p class="important-date-description">
                            سيعقد الاختبار النهائي لمقرر أمن المعلومات في قاعة 205 من الساعة 9:00 صباحاً حتى 11:00 صباحاً.
                        </p>
                    </div>
                </div>
                <div class="important-date-item">
                    <div class="important-date-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="important-date-content">
                        <h5 class="important-date-title">
                            نهاية الفصل الدراسي
                            <span class="important-date-badge upcoming"><?php echo t('upcoming'); ?></span>
                        </h5>
                        <div class="important-date-date">20 يونيو 2025</div>
                        <p class="important-date-description">
                            آخر يوم في الفصل الدراسي الثاني للعام الجامعي 2024-2025.
                        </p>
                    </div>
                </div>
                <div class="important-date-item">
                    <div class="important-date-icon">
                        <i class="fas fa-calendar-plus"></i>
                    </div>
                    <div class="important-date-content">
                        <h5 class="important-date-title">
                            بداية التسجيل للفصل الصيفي
                            <span class="important-date-badge upcoming"><?php echo t('upcoming'); ?></span>
                        </h5>
                        <div class="important-date-date">25 يونيو 2025</div>
                        <p class="important-date-description">
                            بداية فترة التسجيل للفصل الصيفي للعام الجامعي 2024-2025.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- مودال تفاصيل الحدث -->
    <div class="modal fade" id="eventDetailsModal" tabindex="-1" aria-labelledby="eventDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="eventDetailsModalLabel">تفاصيل الحدث</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="eventDetails">
                        <h4 id="eventTitle">برمجة الويب</h4>
                        <p id="eventType" class="badge bg-primary">محاضرة</p>
                        <p id="eventDate">الأحد، 4 مايو 2025</p>
                        <p id="eventTime"><i class="fas fa-clock me-2"></i> 8:00 - 9:30</p>
                        <p id="eventLocation"><i class="fas fa-map-marker-alt me-2"></i> قاعة 305</p>
                        <p id="eventInstructor"><i class="fas fa-user me-2"></i> د. محمد أحمد</p>
                        <hr>
                        <h5>وصف المقرر</h5>
                        <p id="eventDescription">
                            يهدف هذا المقرر إلى تعريف الطلاب بأساسيات برمجة الويب، بما في ذلك HTML، CSS، JavaScript، وتطوير تطبيقات الويب باستخدام إطار العمل PHP.
                        </p>
                        <h5>المهام القادمة</h5>
                        <ul id="eventTasks">
                            <li>تسليم المشروع النهائي (21 مايو 2025)</li>
                            <li>الاختبار النهائي (8 يونيو 2025)</li>
                        </ul>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo t('close'); ?></button>
                    <a href="student_courses.php" class="btn btn-primary"><?php echo t('view_course'); ?></a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- ملف JavaScript الرئيسي -->
    <script src="assets/js/main.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // تبديل القائمة الجانبية في الشاشات الصغيرة
            document.querySelector('.toggle-sidebar').addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('d-none');
            });
            
            // تبديل بين عرض الجدول الأسبوعي والشهري
            const weeklyViewBtn = document.getElementById('weeklyViewBtn');
            const monthlyViewBtn = document.getElementById('monthlyViewBtn');
            const weeklyView = document.getElementById('weeklyView');
            const monthlyView = document.getElementById('monthlyView');
            
            weeklyViewBtn.addEventListener('click', function() {
                weeklyView.style.display = 'block';
                monthlyView.style.display = 'none';
                weeklyViewBtn.classList.add('active');
                monthlyViewBtn.classList.remove('active');
            });
            
            monthlyViewBtn.addEventListener('click', function() {
                weeklyView.style.display = 'none';
                monthlyView.style.display = 'block';
                weeklyViewBtn.classList.remove('active');
                monthlyViewBtn.classList.add('active');
            });
            
            // تصفية عناصر الجدول
            const filterButtons = document.querySelectorAll('.schedule-filter button');
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    // إزالة الفئة النشطة من جميع الأزرار
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    
                    // إضافة الفئة النشطة إلى الزر المحدد
                    this.classList.add('active');
                    
                    const filter = this.getAttribute('data-filter');
                    const scheduleItems = document.querySelectorAll('.schedule-item');
                    const calendarEvents = document.querySelectorAll('.calendar-event');
                    
                    // تصفية عناصر الجدول الأسبوعي
                    scheduleItems.forEach(item => {
                        if (filter === 'all' || item.getAttribute('data-type') === filter) {
                            item.style.display = 'block';
                        } else {
                            item.style.display = 'none';
                        }
                    });
                    
                    // تصفية أحداث التقويم الشهري
                    calendarEvents.forEach(event => {
                        if (filter === 'all' || event.classList.contains(filter)) {
                            event.style.display = 'block';
                        } else {
                            event.style.display = 'none';
                        }
                    });
                });
            });
            
            // عرض تفاصيل الحدث عند النقر على عنصر في الجدول
            const scheduleItems = document.querySelectorAll('.schedule-item');
            scheduleItems.forEach(item => {
                item.addEventListener('click', function() {
                    const title = this.querySelector('.schedule-item-title').textContent;
                    const type = this.getAttribute('data-type');
                    const time = this.querySelector('.schedule-item-time').textContent;
                    const location = this.querySelector('.schedule-item-location').textContent;
                    const instructor = this.querySelector('.schedule-item-instructor').textContent;
                    
                    // تحديث محتوى المودال
                    document.getElementById('eventTitle').textContent = title;
                    document.getElementById('eventType').textContent = getEventTypeText(type);
                    document.getElementById('eventType').className = `badge bg-${getEventTypeClass(type)}`;
                    document.getElementById('eventTime').innerHTML = `<i class="fas fa-clock me-2"></i> ${time}`;
                    document.getElementById('eventLocation').innerHTML = `<i class="fas fa-map-marker-alt me-2"></i> ${location}`;
                    document.getElementById('eventInstructor').innerHTML = `<i class="fas fa-user me-2"></i> ${instructor}`;
                    
                    // عرض المودال
                    const modal = new bootstrap.Modal(document.getElementById('eventDetailsModal'));
                    modal.show();
                });
            });
            
            // عرض تفاصيل الحدث عند النقر على حدث في التقويم الشهري
            const calendarEvents = document.querySelectorAll('.calendar-event');
            calendarEvents.forEach(event => {
                event.addEventListener('click', function() {
                    const title = this.textContent;
                    const type = this.classList[1]; // lecture, lab, exam, tutorial, important-date
                    
                    // تحديث محتوى المودال
                    document.getElementById('eventTitle').textContent = title;
                    document.getElementById('eventType').textContent = getEventTypeText(type);
                    document.getElementById('eventType').className = `badge bg-${getEventTypeClass(type)}`;
                    
                    // عرض المودال
                    const modal = new bootstrap.Modal(document.getElementById('eventDetailsModal'));
                    modal.show();
                });
            });
            
            // تصدير التقويم
            document.getElementById('exportCalendar').addEventListener('click', function() {
                alert('سيتم تنزيل ملف التقويم بتنسيق iCalendar (.ics)');
                // هنا يمكن إضافة كود لإنشاء وتنزيل ملف iCalendar
            });
            
            // طباعة الجدول
            document.getElementById('printSchedule').addEventListener('click', function() {
                window.print();
            });
            
            // التنقل بين الأشهر في عرض التقويم الشهري
            document.getElementById('prevMonth').addEventListener('click', function() {
                alert('سيتم الانتقال إلى الشهر السابق');
                // هنا يمكن إضافة كود للانتقال إلى الشهر السابق
            });
            
            document.getElementById('nextMonth').addEventListener('click', function() {
                alert('سيتم الانتقال إلى الشهر التالي');
                // هنا يمكن إضافة كود للانتقال إلى الشهر التالي
            });
            
            // دالة للحصول على نص نوع الحدث
            function getEventTypeText(type) {
                switch (type) {
                    case 'lecture':
                        return 'محاضرة';
                    case 'lab':
                        return 'معمل';
                    case 'exam':
                        return 'اختبار';
                    case 'tutorial':
                        return 'تمارين';
                    case 'important-date':
                        return 'موعد مهم';
                    default:
                        return 'حدث';
                }
            }
            
            // دالة للحصول على فئة نوع الحدث
            function getEventTypeClass(type) {
                switch (type) {
                    case 'lecture':
                        return 'primary';
                    case 'lab':
                        return 'secondary';
                    case 'exam':
                        return 'danger';
                    case 'tutorial':
                        return 'success';
                    case 'important-date':
                        return 'warning';
                    default:
                        return 'info';
                }
            }
        });
    </script>
</body>
</html>
